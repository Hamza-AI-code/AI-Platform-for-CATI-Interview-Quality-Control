# Immersion AI — Contrôle Qualité des Enquêteurs CATI (IA 100 % locale)

Application web complète pour évaluer automatiquement la qualité des
**enquêteurs CATI** (Computer-Assisted Telephone Interviewing) : l'IA compare
le questionnaire de référence (.LSS LimeSurvey), les réponses enregistrées
(Excel) et les transcriptions d'appels (Excel, liées par Session Code) pour
détecter les contradictions, les anomalies de routage, les comportements
d'enquêteur suspects et les entretiens fabriqués.

**Toute l'IA tourne EN LOCAL via [Ollama](https://ollama.com) : aucune clé
API, aucun crédit, aucune facturation, aucun cloud. Une fois Ollama et un
modèle installés, l'application fonctionne entièrement HORS LIGNE.**

## Fonctionnalités

- Import guidé des 3 fichiers (questionnaire .LSS, entretiens Excel,
  transcriptions Excel) avec détection automatique des colonnes.
- Évaluation de chaque entretien :
  - contrôles déterministes : routage/logique de saut (équations de pertinence
    LimeSurvey évaluées), questions sautées, durées anormales, verbatims
    dupliqués entre entretiens ;
  - vérification sémantique IA locale : chaque réponse enregistrée est classée
    « vérifiée », « contredite » ou « preuve insuffisante » (raisonnement
    sémantique, français et darija marocaine, citation de la transcription à
    l'appui) — jamais « correcte par défaut » ;
  - cohérence entre réponses : combinaisons impossibles détectées ;
  - anomalies de conduite étayées : questions orientées, influence de
    l'enquêteur, relances insuffisantes, réponses saisies jamais données,
    suspicion de fabrication ;
  - pour chaque anomalie : question (code + texte), gravité, citation de la
    transcription, explication, recommandation pour l'enquêteur ET
    recommandations pour la direction (y compris quand une question du
    questionnaire doit être revue ou réécrite) ;
  - score qualité 0-100 calculé uniquement sur les réponses réellement
    évaluables, verdict (conforme / à contrôler / non conforme), risque de
    fraude — un entretien sans réponse vérifiable ne peut pas être « conforme ».
- Les entretiens **déjà évalués ne sont JAMAIS ré-analysés** par l'IA : leurs
  résultats stockés sont réaffichés. La ré-évaluation est un bouton explicite
  par entretien ; un bouton Supprimer (avec confirmation) retire un entretien
  et tout ce qui lui est lié (évaluations, transcriptions, rapports).
- Tableaux de bord par poste et direction, agrégation des questions
  récurrentes en anomalie, rapports PDF & Excel, authentification JWT.

## Installation

### 1. Installer Ollama

Téléchargez et installez Ollama depuis **https://ollama.com** (Windows, macOS
ou Linux).

### 2. Télécharger un modèle

```bash
ollama pull qwen3:8b
```

ou, selon votre machine :

```bash
ollama pull deepseek-r1:14b     # meilleur raisonnement (16 Go de RAM recommandés)
ollama pull llama3.1:8b         # bon équilibre général
ollama pull mistral             # léger
ollama pull llama3.1:70b        # qualité maximale (GPU/beaucoup de RAM)
```

### 3. Vérifier les modèles installés

```bash
ollama list
```

### 4. Démarrer Ollama

```bash
ollama serve
```

(Sous Windows/macOS, l'application Ollama démarre le serveur automatiquement —
`ollama serve` n'est nécessaire que s'il ne tourne pas déjà.)

### 5. Démarrer le backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows : .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

API : http://localhost:8000 · docs interactives : http://localhost:8000/docs
Compte initial : `admin@immerssion.ai` / `Admin123!` (à changer).

### 6. Démarrer le frontend

```bash
cd frontend
npm install
npm run dev
```

Interface : http://localhost:3000

## Choix du modèle

Le modèle est lu depuis `backend/.env` — **changer de modèle = modifier UNE
ligne, aucun changement de code** :

```bash
# backend/.env
OLLAMA_MODEL=qwen3:8b
```

Si `OLLAMA_MODEL` est **vide**, l'application choisit automatiquement le
meilleur modèle installé, par priorité :

1. **deepseek-r1** — meilleur raisonnement local (contradictions subtiles) ;
2. **qwen3** — excellent multilingue (français/arabe), bon raisonnement ;
3. **llama3.1** ;
4. **mistral** ;
5. à défaut, le premier modèle installé.

L'application fonctionne avec n'importe quel modèle Ollama. Autres réglages
(`backend/.env.example`) : `OLLAMA_BASE_URL` (défaut http://localhost:11434),
`OLLAMA_NUM_CTX` (fenêtre de contexte, défaut 16384),
`AI_QUESTIONS_PER_CALL` (40 ; baissez à 20 avec un petit modèle si les
verdicts se dégradent sur les gros questionnaires).

## Détection automatique au démarrage

À chaque démarrage, le backend vérifie la disponibilité réelle de l'IA et
l'écrit dans les logs — jamais de repli silencieux :

- Ollama arrêté →
  `IA locale INDISPONIBLE : Ollama n'est pas lancé. Démarrez Ollama (commande
  « ollama serve », ou l'application Ollama) avant de lancer l'analyse…`
- Modèle non installé →
  `IA locale INDISPONIBLE : Le modèle configuré « qwen3:8b » n'est pas installé
  dans Ollama. Installez-le avec :  ollama pull qwen3:8b …`
- Tout est prêt →
  `IA locale OPÉRATIONNELLE — Ollama actif, modèle qwen3:8b installé.`

## Jamais de faux résultats

Si Ollama est arrêté (ou le modèle absent) pendant une évaluation,
l'entretien n'obtient **ni score, ni verdict, ni « 0 anomalie »** : il est
marqué **« Analyse incomplète »** avec le message exact (« Analyse sémantique
impossible : Ollama n'est pas lancé — démarrez Ollama puis relancez
l'évaluation »), visible sur la fiche entretien, dans les rapports, le journal
d'activité et les logs. Les analyses incomplètes sont exclues des statistiques
du tableau de bord ; il suffit de relancer l'évaluation une fois Ollama
démarré.

## Économie de ressources (tokens / temps)

- **Un seul appel IA par entretien** dans le cas courant : toutes les
  questions + l'analyse de conduite dans le même prompt, transcription
  partagée et dédupliquée (envoyée UNE fois), questionnaire jamais renvoyé
  en entier.
- **Entretiens déjà évalués : zéro appel IA** — « Évaluer tout » ne traite
  que les entretiens jamais évalués.
- Instruction système statique d'un appel à l'autre (préfixe réutilisable),
  données du questionnaire parsées une seule fois et mises en cache.
- Transcriptions exceptionnellement longues : sélection locale des extraits
  pertinents (recouvrement lexical + MMR), sans aucun appel réseau.
- Réponses tronquées récupérées (préfixe JSON valide) puis re-tentées en
  demi-lots — pas de tokens jetés.

## Vérifier que l'IA locale est bien utilisée

- `GET /api/admin/system` retourne `"ai_engine": "ollama"` et le modèle actif ;
- sur la fiche d'un entretien évalué : « Moteur : IA locale (Ollama) », avec
  statuts Vérifiée / Contredite et citations ;
- mode debug (`AI_DEBUG=true` dans backend/.env) : chaque question analysée
  est tracée (extraits, prompt, réponse JSON du modèle, résultat final) dans
  les logs et `backend/data/ai_debug.jsonl`.

## Flux d'analyse

1. Le questionnaire .LSS est parsé (questions, options, équations de routage).
2. Les entretiens Excel sont importés et liés aux transcriptions par Session
   Code ; les enquêteurs sont identifiés par leur numéro de poste.
3. « Évaluer tout » lance, pour chaque entretien jamais évalué : les contrôles
   déterministes (routage, durées, doublons), puis l'analyse sémantique locale
   (vérification de chaque réponse + conduite + cohérence inter-réponses) en
   un appel Ollama, puis le calcul du score et des recommandations.
4. Les tableaux de bord agrègent les anomalies par poste et par question ;
   les rapports PDF/Excel reprennent le détail avec citations.

## Structure du projet

```
backend/
  app/
    main.py            # FastAPI, démarrage, healthcheck IA locale
    config.py          # Configuration (.env) — OLLAMA_MODEL, etc.
    models.py          # SQLAlchemy (questionnaires, entretiens, évaluations…)
    routers/           # API REST (auth, upload, entretiens, rapports, admin)
    services/
      ai_service.py    # Service Ollama : REST local, JSON structuré, erreurs claires
      evaluation.py    # Moteur d'évaluation (règles + IA) & scoring
      lss_parser.py    # Parseur .LSS (LimeSurvey)
      importer.py      # Import Excel entretiens & transcriptions
      report_generator.py  # Rapports PDF & Excel
frontend/              # Next.js 14 + TypeScript + Tailwind
```
