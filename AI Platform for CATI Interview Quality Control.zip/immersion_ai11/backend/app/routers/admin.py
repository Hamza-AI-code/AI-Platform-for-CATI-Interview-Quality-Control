"""Centre d'administration : utilisateurs, rôles, paramètres IA."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..config import settings as app_settings
from ..services import ai_service
from ..database import get_db
from ..deps import require_roles
from ..security import hash_password

router = APIRouter(prefix="/api/admin", tags=["admin"])

# Seuls super_admin et admin gèrent les utilisateurs et les rôles.
ManageUsers = Depends(require_roles("super_admin", "admin"))

# « model » vide = auto : le modèle effectif est résolu au moment de
# l'affichage (GET /system), pas à l'import — Ollama peut ne pas encore tourner.
DEFAULT_AI_SETTINGS = {
    "engine": "auto",
    "quality_threshold": 60,
    "fraud_threshold": 45,
    "auto_alert": True,
    "model": app_settings.ollama_model or "auto",
}

ROLE_PERMISSIONS = {
    "super_admin": ["all"],
    "admin": ["view", "create", "edit", "delete", "reports", "analyses", "users"],
    "quality_manager": ["view", "create", "edit", "analyses", "reports"],
    "supervisor": ["view", "create", "analyses", "reports"],
    "viewer": ["view"],
}

ROLE_LABELS = {
    "super_admin": "Super Admin",
    "admin": "Admin",
    "quality_manager": "Quality Manager",
    "supervisor": "Supervisor",
    "viewer": "Lecteur",
}


# ----------------------------- Utilisateurs ------------------------------- #
@router.get("/users", response_model=list[schemas.UserOut])
def list_users(db: Session = Depends(get_db), _: models.User = ManageUsers):
    return db.query(models.User).order_by(models.User.created_at.desc()).all()


@router.post("/users", response_model=schemas.UserOut, status_code=201)
def create_user(
    payload: schemas.UserCreate, db: Session = Depends(get_db), _: models.User = ManageUsers
):
    if payload.role not in ROLE_PERMISSIONS:
        raise HTTPException(400, "Rôle invalide.")
    if db.query(models.User).filter(models.User.email == payload.email).first():
        raise HTTPException(409, "Un utilisateur avec cet email existe déjà.")
    perms = payload.permissions or ROLE_PERMISSIONS.get(payload.role, ["view"])
    user = models.User(
        name=payload.name,
        email=payload.email,
        role=payload.role,
        permissions=perms,
        password_hash=hash_password(payload.password) if payload.password else None,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.patch("/users/{user_id}", response_model=schemas.UserOut)
def update_user(
    user_id: int,
    payload: schemas.UserUpdate,
    db: Session = Depends(get_db),
    _: models.User = ManageUsers,
):
    user = db.get(models.User, user_id)
    if not user:
        raise HTTPException(404, "Utilisateur introuvable")
    data = payload.model_dump(exclude_unset=True)
    if data.get("role") and data["role"] not in ROLE_PERMISSIONS:
        raise HTTPException(400, "Rôle invalide.")
    if "role" in data and "permissions" not in data:
        data["permissions"] = ROLE_PERMISSIONS.get(data["role"], user.permissions)
    for key, value in data.items():
        setattr(user, key, value)
    db.commit()
    db.refresh(user)
    return user


@router.post("/users/{user_id}/reset-password", response_model=schemas.UserOut)
def reset_password(
    user_id: int,
    payload: schemas.PasswordReset,
    db: Session = Depends(get_db),
    _: models.User = ManageUsers,
):
    user = db.get(models.User, user_id)
    if not user:
        raise HTTPException(404, "Utilisateur introuvable")
    user.password_hash = hash_password(payload.password)
    db.commit()
    db.refresh(user)
    return user


@router.post("/users/{user_id}/disable", response_model=schemas.UserOut)
def disable_user(
    user_id: int, db: Session = Depends(get_db), current: models.User = ManageUsers
):
    user = db.get(models.User, user_id)
    if not user:
        raise HTTPException(404, "Utilisateur introuvable")
    if user.id == current.id:
        raise HTTPException(400, "Vous ne pouvez pas désactiver votre propre compte.")
    user.status = "disabled"
    db.commit()
    db.refresh(user)
    return user


@router.post("/users/{user_id}/enable", response_model=schemas.UserOut)
def enable_user(
    user_id: int, db: Session = Depends(get_db), _: models.User = ManageUsers
):
    user = db.get(models.User, user_id)
    if not user:
        raise HTTPException(404, "Utilisateur introuvable")
    user.status = "active"
    db.commit()
    db.refresh(user)
    return user


@router.delete("/users/{user_id}", status_code=204)
def delete_user(
    user_id: int, db: Session = Depends(get_db), current: models.User = ManageUsers
):
    user = db.get(models.User, user_id)
    if not user:
        raise HTTPException(404, "Utilisateur introuvable")
    if user.id == current.id:
        raise HTTPException(400, "Vous ne pouvez pas supprimer votre propre compte.")
    db.delete(user)
    db.commit()


@router.get("/roles")
def list_roles(_: models.User = Depends(require_roles("super_admin", "admin"))):
    return [
        {"role": r, "label": ROLE_LABELS.get(r, r), "permissions": p}
        for r, p in ROLE_PERMISSIONS.items()
    ]


# ----------------------------- Paramètres IA ------------------------------ #
@router.get("/settings", response_model=schemas.SettingOut)
def get_ai_settings(db: Session = Depends(get_db)):
    setting = db.get(models.AppSetting, "ai")
    if not setting:
        return schemas.SettingOut(key="ai", value=DEFAULT_AI_SETTINGS)
    return schemas.SettingOut(key="ai", value={**DEFAULT_AI_SETTINGS, **setting.value})


@router.put("/settings", response_model=schemas.SettingOut)
def update_ai_settings(
    payload: schemas.SettingUpdate, db: Session = Depends(get_db), _: models.User = ManageUsers
):
    setting = db.get(models.AppSetting, "ai")
    merged = {**DEFAULT_AI_SETTINGS, **(setting.value if setting else {}), **payload.value}
    if not setting:
        setting = models.AppSetting(key="ai", value=merged)
        db.add(setting)
    else:
        setting.value = merged
    db.commit()
    db.refresh(setting)
    return schemas.SettingOut(key="ai", value=setting.value)


@router.get("/system")
def system_info():
    return {
        "ai_engine": "ollama" if ai_service.is_configured() else "heuristic",
        "model": ai_service.active_model(),
        "version": app_settings.api_version,
    }
