"""Endpoints entretiens : liste, détail, suppression, lancement des évaluations."""
from __future__ import annotations

import threading
from pathlib import Path

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from sqlalchemy.orm import Session, joinedload

from .. import models, schemas
from ..database import SessionLocal, get_db
from ..services.activity import log_activity
from ..services.evaluation import evaluate_batch, evaluate_interview

router = APIRouter(prefix="/api/interviews", tags=["interviews"])


def _latest_eval(interview: models.Interview) -> models.Evaluation | None:
    return max(interview.evaluations, key=lambda e: e.id) if interview.evaluations else None


def _to_list_item(interview: models.Interview) -> dict:
    ev = _latest_eval(interview)
    return {
        "id": interview.id,
        "external_id": interview.external_id,
        "session_code": interview.session_code,
        "post_number": interview.interviewer.post_number if interview.interviewer else None,
        "duration_sec": interview.duration_sec,
        "submitted_at": interview.submitted_at,
        "transcript_count": len(interview.transcripts),
        "quality_score": ev.quality_score if ev else None,
        "verdict": ev.verdict if ev else None,
        "fraud_risk": ev.fraud_risk if ev else None,
        "evaluation_status": ev.status.value if ev else None,
    }


@router.get("", response_model=list[schemas.InterviewListItem])
def list_interviews(
    questionnaire_id: int | None = None,
    post_number: str | None = None,
    verdict: str | None = None,
    search: str | None = None,
    limit: int = Query(500, le=2000),
    db: Session = Depends(get_db),
):
    query = db.query(models.Interview).options(
        joinedload(models.Interview.interviewer),
        joinedload(models.Interview.transcripts),
        joinedload(models.Interview.evaluations),
    )
    if questionnaire_id:
        query = query.filter(models.Interview.questionnaire_id == questionnaire_id)
    if post_number:
        query = query.join(models.Interviewer).filter(
            models.Interviewer.post_number == post_number
        )
    if search:
        like = f"%{search.strip()}%"
        query = query.filter(
            models.Interview.external_id.like(like)
            | models.Interview.session_code.like(like)
        )
    interviews = query.order_by(models.Interview.id.asc()).limit(limit).all()
    items = [_to_list_item(i) for i in interviews]
    if verdict:
        items = [i for i in items if i["verdict"] == verdict]
    return items


@router.get("/{interview_id}", response_model=schemas.InterviewDetail)
def get_interview(interview_id: int, db: Session = Depends(get_db)):
    interview = (
        db.query(models.Interview)
        .options(
            joinedload(models.Interview.interviewer),
            joinedload(models.Interview.transcripts),
            joinedload(models.Interview.evaluations).joinedload(models.Evaluation.findings),
        )
        .filter(models.Interview.id == interview_id)
        .one_or_none()
    )
    if not interview:
        raise HTTPException(404, "Entretien introuvable")
    ev = _latest_eval(interview)
    return {
        "id": interview.id,
        "external_id": interview.external_id,
        "session_code": interview.session_code,
        "post_number": interview.interviewer.post_number if interview.interviewer else None,
        "questionnaire_id": interview.questionnaire_id,
        "respondent_meta": interview.respondent_meta or {},
        "answers": interview.answers or {},
        "started_at": interview.started_at,
        "submitted_at": interview.submitted_at,
        "duration_sec": interview.duration_sec,
        "transcripts": interview.transcripts,
        "evaluation": ev,
    }


@router.post("/{interview_id}/evaluate", response_model=schemas.EvaluationDetail)
def evaluate_one(interview_id: int, db: Session = Depends(get_db)):
    """RÉ-évalue un entretien immédiatement (synchrone).

    C'est le SEUL chemin qui relance l'IA sur un entretien déjà évalué :
    il n'est emprunté que sur action explicite (bouton « Ré-évaluer »).
    """
    interview = db.get(models.Interview, interview_id)
    if not interview:
        raise HTTPException(404, "Entretien introuvable")
    evaluation = evaluate_interview(db, interview)
    db.refresh(evaluation)
    return evaluation


@router.delete("/{interview_id}", status_code=204)
def delete_interview(interview_id: int, db: Session = Depends(get_db)):
    """Supprime un entretien et TOUT ce qui lui est lié.

    Cascade : évaluations + anomalies + transcriptions (delete-orphan ORM),
    rapports générés pour cet entretien (lignes ET fichiers sur disque).
    """
    interview = db.get(models.Interview, interview_id)
    if not interview:
        raise HTTPException(404, "Entretien introuvable")
    reports = (
        db.query(models.Report).filter(models.Report.interview_id == interview_id).all()
    )
    for report in reports:
        try:
            Path(report.file_path).unlink(missing_ok=True)
        except OSError:
            pass  # le fichier a pu être déplacé/supprimé manuellement
        db.delete(report)
    external_id = interview.external_id
    db.delete(interview)  # transcriptions + évaluations + anomalies en cascade
    log_activity(
        db, "interview",
        f"Entretien #{external_id} supprimé (évaluations, transcriptions et "
        f"{len(reports)} rapport(s) liés inclus).",
    )
    db.commit()
    return None


# Un seul lot d'évaluation à la fois : recliquer sur « Évaluer tout » pendant
# qu'un lot tourne ne doit ni empiler des lots concurrents (gaspillage de
# tokens) ni entrer en conflit d'écriture avec le lot en cours.
_batch_lock = threading.Lock()


def _run_batch(questionnaire_id: int, interview_ids: list[int] | None) -> None:
    db = SessionLocal()
    try:
        result = evaluate_batch(db, questionnaire_id, interview_ids)
        message = (
            f"Évaluation terminée : {result['evaluated']} nouvel(aux) entretien(s) "
            f"analysé(s), {result.get('skipped', 0)} déjà évalué(s) conservé(s) "
            f"({result['failed']} échec(s))"
        )
        if result.get("quota_exceeded"):
            message += (
                " — OLLAMA INDISPONIBLE : les entretiens en échec sont "
                "marqués « analyse incomplète » (aucun score produit). Démarrez "
                "Ollama puis relancez l'évaluation."
            )
        log_activity(db, "evaluation", message, entity_id=questionnaire_id)
    finally:
        db.close()
        _batch_lock.release()


@router.post("/evaluate-all", status_code=202)
def evaluate_all(
    payload: schemas.EvaluateRequest,
    background: BackgroundTasks,
    questionnaire_id: int | None = None,
    db: Session = Depends(get_db),
):
    """Lance l'évaluation de tous les entretiens (tâche d'arrière-plan)."""
    if questionnaire_id is None:
        latest = (
            db.query(models.Questionnaire)
            .order_by(models.Questionnaire.created_at.desc())
            .first()
        )
        if not latest:
            raise HTTPException(404, "Aucun questionnaire importé")
        questionnaire_id = latest.id
    count = (
        db.query(models.Interview)
        .filter(models.Interview.questionnaire_id == questionnaire_id)
        .count()
    )
    if count == 0:
        raise HTTPException(400, "Aucun entretien importé pour ce questionnaire")
    if not _batch_lock.acquire(blocking=False):
        # Un lot est déjà en cours : on ne le double pas.
        return {"status": "already_running", "interviews": count}
    try:
        log_activity(
            db, "evaluation",
            f"Évaluation lancée sur {count} entretien(s) — seuls les entretiens "
            "jamais évalués seront envoyés à l'IA.",
        )
        background.add_task(_run_batch, questionnaire_id, payload.interview_ids)
    except BaseException:
        _batch_lock.release()
        raise
    return {"status": "queued", "interviews": count}


@router.get("/evaluations/progress")
def evaluation_progress(db: Session = Depends(get_db)):
    """Progression globale des évaluations (pour la barre de progression UI)."""
    total = db.query(models.Interview).count()
    evaluated = (
        db.query(models.Evaluation)
        .filter(models.Evaluation.status == models.EvaluationStatus.completed)
        .count()
    )
    running = (
        db.query(models.Evaluation)
        .filter(models.Evaluation.status == models.EvaluationStatus.running)
        .count()
    )
    return {"total": total, "evaluated": evaluated, "running": running}
