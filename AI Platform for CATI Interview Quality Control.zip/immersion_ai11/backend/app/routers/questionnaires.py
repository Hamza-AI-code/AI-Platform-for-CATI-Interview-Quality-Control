"""Import des données : questionnaire .LSS, entretiens Excel, transcriptions Excel."""
from __future__ import annotations

import hashlib

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..services import importer
from ..services.activity import log_activity
from ..services.lss_parser import parse_lss

router = APIRouter(prefix="/api/questionnaires", tags=["questionnaires"])


@router.get("", response_model=list[schemas.QuestionnaireOut])
def list_questionnaires(db: Session = Depends(get_db)):
    return db.query(models.Questionnaire).order_by(models.Questionnaire.created_at.desc()).all()


@router.get("/{questionnaire_id}", response_model=schemas.QuestionnaireDetail)
def get_questionnaire(questionnaire_id: int, db: Session = Depends(get_db)):
    questionnaire = db.get(models.Questionnaire, questionnaire_id)
    if not questionnaire:
        raise HTTPException(404, "Questionnaire introuvable")
    return questionnaire


@router.post("/import-lss", response_model=schemas.QuestionnaireDetail, status_code=201)
async def import_lss(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Importe le questionnaire de référence (.lss LimeSurvey)."""
    if not (file.filename or "").lower().endswith(".lss"):
        raise HTTPException(400, "Le questionnaire doit être un fichier .lss (export LimeSurvey).")
    content = await file.read()
    digest = hashlib.sha256(content).hexdigest()

    existing = db.query(models.Questionnaire).filter_by(lss_sha256=digest).one_or_none()
    if existing:
        return existing

    try:
        definition = parse_lss(content)
    except Exception as exc:
        raise HTTPException(400, f"Fichier .lss illisible : {exc}")

    questionnaire = models.Questionnaire(
        title=definition["title"],
        original_filename=file.filename,
        survey_id=str(definition.get("survey_id") or ""),
        language=definition.get("language", "fr"),
        lss_sha256=digest,
        definition=definition,
    )
    db.add(questionnaire)
    db.commit()
    db.refresh(questionnaire)
    log_activity(
        db, "import",
        f"Questionnaire « {questionnaire.title} » importé "
        f"({questionnaire.question_count} questions)",
        entity_id=questionnaire.id,
    )
    return questionnaire


@router.post("/{questionnaire_id}/import-interviews", response_model=schemas.ImportResult)
async def import_interviews(
    questionnaire_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)
):
    """Importe le fichier Excel des entretiens (réponses enregistrées).

    Les enquêteurs CATI sont détectés automatiquement depuis la colonne
    « Num Poste » — aucune création manuelle.
    """
    questionnaire = db.get(models.Questionnaire, questionnaire_id)
    if not questionnaire:
        raise HTTPException(404, "Importez d'abord le questionnaire .lss")
    if not (file.filename or "").lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Les entretiens doivent être un fichier Excel (.xlsx).")
    content = await file.read()
    try:
        result = importer.import_interviews(db, questionnaire, content)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    log_activity(
        db, "import",
        f"{result['created'] + result['updated']} entretien(s) importé(s) — "
        f"postes détectés : {', '.join(result['posts']) or 'aucun'}",
        entity_id=questionnaire.id,
    )
    return {"questionnaire_id": questionnaire.id, **result}


@router.post("/{questionnaire_id}/import-transcripts", response_model=schemas.ImportResult)
async def import_transcripts(
    questionnaire_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)
):
    """Importe le fichier Excel des transcriptions (liaison par Session Code)."""
    questionnaire = db.get(models.Questionnaire, questionnaire_id)
    if not questionnaire:
        raise HTTPException(404, "Importez d'abord le questionnaire .lss")
    if not (file.filename or "").lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Les transcriptions doivent être un fichier Excel (.xlsx).")
    content = await file.read()
    try:
        result = importer.import_transcripts(db, questionnaire, content)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    log_activity(
        db, "import",
        f"{result['linked']} transcription(s) liée(s) par Session Code "
        f"({result['orphaned']} orpheline(s))",
        entity_id=questionnaire.id,
    )
    return {"questionnaire_id": questionnaire.id, **result}


@router.delete("/{questionnaire_id}", status_code=204)
def delete_questionnaire(questionnaire_id: int, db: Session = Depends(get_db)):
    questionnaire = db.get(models.Questionnaire, questionnaire_id)
    if not questionnaire:
        raise HTTPException(404, "Questionnaire introuvable")
    db.delete(questionnaire)
    db.commit()
