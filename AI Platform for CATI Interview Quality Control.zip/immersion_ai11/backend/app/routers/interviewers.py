"""Endpoints enquêteurs CATI (lecture seule).

Les enquêteurs sont identifiés UNIQUEMENT par leur numéro de poste et créés
automatiquement lors de l'import du fichier Excel — il n'existe volontairement
aucun endpoint de création/modification manuelle.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload

from .. import models, schemas
from ..database import get_db

router = APIRouter(prefix="/api/interviewers", tags=["interviewers"])


def interviewer_summary(interviewer: models.Interviewer) -> dict:
    """Statistiques agrégées d'un poste, calculées depuis les évaluations."""
    interviews = interviewer.interviews
    latest_evals = []
    for interview in interviews:
        completed = [
            e for e in interview.evaluations
            if e.status == models.EvaluationStatus.completed
        ]
        if completed:
            latest_evals.append(max(completed, key=lambda e: e.id))
    findings = [f for e in latest_evals for f in e.findings]
    scores = [e.quality_score for e in latest_evals if e.quality_score is not None]
    frauds = [e.fraud_risk for e in latest_evals if e.fraud_risk is not None]
    critical = sum(
        1 for f in findings
        if f.severity in (models.Severity.high, models.Severity.critical)
    )
    minor = sum(
        1 for f in findings
        if f.severity in (models.Severity.low, models.Severity.medium)
    )
    pass_count = sum(1 for e in latest_evals if e.verdict == "pass")
    return {
        "post_number": interviewer.post_number,
        "interviews": len(interviews),
        "evaluated": len(latest_evals),
        "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
        "critical_errors": critical,
        "minor_errors": minor,
        "accuracy_pct": round(100 * pass_count / len(latest_evals), 1) if latest_evals else None,
        "fraud_risk": round(sum(frauds) / len(frauds), 1) if frauds else None,
        "fail_count": sum(1 for e in latest_evals if e.verdict == "fail"),
        "needs_review_count": sum(1 for e in latest_evals if e.verdict == "needs_review"),
    }


def ranked_summaries(db: Session) -> list[dict]:
    interviewers = (
        db.query(models.Interviewer)
        .options(
            joinedload(models.Interviewer.interviews)
            .joinedload(models.Interview.evaluations)
            .joinedload(models.Evaluation.findings)
        )
        .all()
    )
    summaries = [interviewer_summary(i) for i in interviewers]
    summaries.sort(key=lambda s: -(s["avg_score"] if s["avg_score"] is not None else -1))
    for rank, s in enumerate(summaries, start=1):
        s["rank"] = rank if s["avg_score"] is not None else None
    return summaries


@router.get("", response_model=list[schemas.InterviewerSummary])
def list_interviewers(db: Session = Depends(get_db)):
    """Tous les postes détectés dans les données importées, classés par score."""
    return ranked_summaries(db)


@router.get("/{post_number}", response_model=schemas.InterviewerDetail)
def get_interviewer(post_number: str, db: Session = Depends(get_db)):
    interviewer = (
        db.query(models.Interviewer)
        .options(
            joinedload(models.Interviewer.interviews)
            .joinedload(models.Interview.evaluations)
            .joinedload(models.Evaluation.findings)
        )
        .filter(models.Interviewer.post_number == post_number)
        .one_or_none()
    )
    if not interviewer:
        raise HTTPException(404, f"Poste {post_number} introuvable dans les données importées")

    summaries = ranked_summaries(db)
    summary = next(s for s in summaries if s["post_number"] == post_number)

    # Distribution des anomalies par catégorie.
    by_cat: dict[str, dict] = {}
    latest_evals: list[models.Evaluation] = []
    for interview in interviewer.interviews:
        completed = [
            e for e in interview.evaluations
            if e.status == models.EvaluationStatus.completed
        ]
        if completed:
            latest_evals.append(max(completed, key=lambda e: e.id))
    for e in latest_evals:
        for f in e.findings:
            slot = by_cat.setdefault(f.category, {"category": f.category, "count": 0, "grave": 0})
            slot["count"] += 1
            if f.severity in (models.Severity.high, models.Severity.critical):
                slot["grave"] += 1
    error_distribution = sorted(by_cat.values(), key=lambda d: -d["count"])

    # Tendance : score moyen par date de soumission.
    by_day: dict[str, list[float]] = {}
    for e in latest_evals:
        if e.quality_score is None or not e.interview.submitted_at:
            continue
        day = e.interview.submitted_at.strftime("%Y-%m-%d")
        by_day.setdefault(day, []).append(e.quality_score)
    trend = [
        {"date": day, "score": round(sum(v) / len(v), 1), "interviews": len(v)}
        for day, v in sorted(by_day.items())
    ]

    # Entretiens les plus problématiques.
    worst = sorted(
        (e for e in latest_evals if e.quality_score is not None),
        key=lambda e: e.quality_score,
    )[:8]
    worst_items = [
        {
            "id": e.interview.id,
            "external_id": e.interview.external_id,
            "session_code": e.interview.session_code,
            "post_number": post_number,
            "duration_sec": e.interview.duration_sec,
            "submitted_at": e.interview.submitted_at,
            "transcript_count": len(e.interview.transcripts),
            "quality_score": e.quality_score,
            "verdict": e.verdict,
            "fraud_risk": e.fraud_risk,
            "evaluation_status": e.status.value,
        }
        for e in worst
    ]

    return {
        **summary,
        "recommendations": interviewer.recommendations or [],
        "recommendations_at": interviewer.recommendations_at,
        "error_distribution": error_distribution,
        "trend": trend,
        "worst_interviews": worst_items,
    }
