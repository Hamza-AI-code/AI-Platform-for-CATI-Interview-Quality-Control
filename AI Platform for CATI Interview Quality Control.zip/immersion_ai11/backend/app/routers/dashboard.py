"""Tableau de bord direction : statistiques globales de la qualité CATI."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..services.evaluation import manager_recommendations
from ..services.report_generator import CATEGORY_LABEL
from .interviewers import ranked_summaries

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("", response_model=schemas.DashboardData)
def dashboard(db: Session = Depends(get_db)):
    total_interviews = db.query(models.Interview).count()
    completed = (
        db.query(models.Evaluation)
        .filter(models.Evaluation.status == models.EvaluationStatus.completed)
        .all()
    )
    # Ne garde que la dernière évaluation par entretien.
    latest_by_interview: dict[int, models.Evaluation] = {}
    for e in completed:
        current = latest_by_interview.get(e.interview_id)
        if current is None or e.id > current.id:
            latest_by_interview[e.interview_id] = e
    evals = list(latest_by_interview.values())

    scores = [e.quality_score for e in evals if e.quality_score is not None]
    pass_count = sum(1 for e in evals if e.verdict == "pass")

    findings = (
        db.query(models.Finding)
        .filter(models.Finding.evaluation_id.in_([e.id for e in evals]))
        .all()
        if evals
        else []
    )
    critical = sum(
        1 for f in findings
        if f.severity in (models.Severity.high, models.Severity.critical)
    )

    # Distribution des anomalies par catégorie.
    by_cat: dict[str, int] = {}
    for f in findings:
        by_cat[f.category] = by_cat.get(f.category, 0) + 1
    error_distribution = [
        {"category": cat, "count": count}
        for cat, count in sorted(by_cat.items(), key=lambda kv: -kv[1])
    ]

    # Questions les plus problématiques (agrégation multi-entretiens).
    eval_interview = {e.id: e.interview_id for e in evals}
    by_question: dict[str, dict] = {}
    for f in findings:
        if not f.question_code:
            continue
        d = by_question.setdefault(
            f.question_code,
            {"count": 0, "grave": 0, "cats": {}, "itvs": set()},
        )
        d["count"] += 1
        if f.severity in (models.Severity.high, models.Severity.critical):
            d["grave"] += 1
        d["cats"][f.category] = d["cats"].get(f.category, 0) + 1
        d["itvs"].add(eval_interview.get(f.evaluation_id))
    ranked_questions = sorted(by_question.items(), key=lambda kv: -kv[1]["count"])
    problem_questions = [
        {
            "question_code": code,
            "count": d["count"],
            "interviews": len(d["itvs"]),
            "grave": d["grave"],
            "top_category": max(d["cats"], key=d["cats"].get),
        }
        for code, d in ranked_questions[:12]
    ]

    # Histogramme des scores (tranches de 10).
    buckets = {i: 0 for i in range(0, 100, 10)}
    for s in scores:
        buckets[min(int(s // 10) * 10, 90)] += 1
    score_histogram = [
        {"bucket": f"{b}–{b + 10}", "count": count} for b, count in sorted(buckets.items())
    ]

    transcripts_linked = db.query(models.Transcript).count()
    transcripts_orphaned = db.query(models.UnlinkedTranscript).count()

    questionnaire = (
        db.query(models.Questionnaire)
        .order_by(models.Questionnaire.created_at.desc())
        .first()
    )

    # Recommandations pour la direction : pour chaque question récurrente,
    # ce qu'il faut revoir (formulation, options, routage, formation).
    question_texts = {
        q.get("code"): q.get("text", "")
        for q in ((questionnaire.definition or {}).get("questions", []) if questionnaire else [])
    }
    management_recommendations = []
    for code, d in ranked_questions[:6]:
        top_cat = max(d["cats"], key=d["cats"].get)
        recos: list[str] = []
        for cat, _n in sorted(d["cats"].items(), key=lambda kv: -kv[1]):
            for r in manager_recommendations(cat, code):
                if r not in recos:
                    recos.append(r)
        management_recommendations.append({
            "question_code": code,
            "question_text": (question_texts.get(code) or "")[:300],
            "occurrences": d["count"],
            "interviews": len(d["itvs"]),
            "grave": d["grave"],
            "common_issue": CATEGORY_LABEL.get(top_cat, top_cat),
            "recommendations": recos[:5],
        })

    activity = (
        db.query(models.Activity)
        .order_by(models.Activity.created_at.desc())
        .limit(12)
        .all()
    )

    return {
        "total_interviews": total_interviews,
        "evaluated_interviews": len(evals),
        "total_interviewers": db.query(models.Interviewer).count(),
        "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
        "pass_rate": round(100 * pass_count / len(evals), 1) if evals else None,
        "critical_findings": critical,
        "transcripts_linked": transcripts_linked,
        "transcripts_orphaned": transcripts_orphaned,
        "interviewers": ranked_summaries(db),
        "error_distribution": error_distribution,
        "problem_questions": problem_questions,
        "management_recommendations": management_recommendations,
        "score_histogram": score_histogram,
        "recent_activity": activity,
        "questionnaire": questionnaire,
    }
