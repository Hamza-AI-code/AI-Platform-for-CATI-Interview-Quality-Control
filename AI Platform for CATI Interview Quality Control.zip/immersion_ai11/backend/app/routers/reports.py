"""Génération et téléchargement de rapports (entretien / poste / global)."""
from __future__ import annotations

import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from .. import models, schemas
from ..config import UPLOAD_DIR
from ..database import get_db
from ..deps import get_current_user
from ..services import report_generator
from ..services.activity import log_activity

router = APIRouter(prefix="/api/reports", tags=["reports"])

# Auth requise sauf pour le téléchargement (utilisé comme href).
Auth = Depends(get_current_user)

REPORT_DIR = UPLOAD_DIR / "reports"

_MEDIA = {
    "pdf": "application/pdf",
    "excel": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}
_EXT = {"pdf": "pdf", "excel": "xlsx"}


@router.get("", response_model=list[schemas.ReportOut])
def list_reports(db: Session = Depends(get_db), _: models.User = Auth):
    return db.query(models.Report).order_by(models.Report.created_at.desc()).all()


@router.post("", response_model=schemas.ReportOut, status_code=201)
def create_report(
    payload: schemas.ReportCreate, db: Session = Depends(get_db), _: models.User = Auth
):
    fmt = payload.format if payload.format in _MEDIA else "pdf"
    scope = payload.scope

    if scope == "interview":
        interview = db.get(models.Interview, payload.interview_id or 0)
        if not interview:
            raise HTTPException(404, "Entretien introuvable")
        data = (
            report_generator.interview_pdf(interview)
            if fmt == "pdf"
            else report_generator.interview_excel(interview)
        )
        title = f"Rapport entretien #{interview.external_id}"
    elif scope == "interviewer":
        interviewer = (
            db.query(models.Interviewer)
            .filter_by(post_number=str(payload.post_number or ""))
            .one_or_none()
        )
        if not interviewer:
            raise HTTPException(404, "Poste introuvable")
        data = (
            report_generator.interviewer_pdf(db, interviewer)
            if fmt == "pdf"
            else report_generator.interviewer_excel(db, interviewer)
        )
        title = f"Rapport enquêteur — Poste {interviewer.post_number}"
    elif scope == "global":
        data = (
            report_generator.global_pdf(db)
            if fmt == "pdf"
            else report_generator.global_excel(db)
        )
        title = "Rapport de direction — qualité CATI"
    else:
        raise HTTPException(400, "scope doit être interview, interviewer ou global")

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    stored_name = f"rapport-{scope}-{uuid.uuid4().hex[:8]}.{_EXT[fmt]}"
    dest = REPORT_DIR / stored_name
    dest.write_bytes(data)

    report = models.Report(
        title=title,
        scope=scope,
        format=fmt,
        interview_id=payload.interview_id,
        post_number=payload.post_number,
        stored_name=stored_name,
        file_path=str(dest),
        size=len(data),
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    log_activity(
        db, type="report",
        message=f"Rapport {fmt.upper()} généré : {title}", entity_id=report.id,
    )
    return report


@router.get("/{report_id}/download")
def download_report(report_id: int, db: Session = Depends(get_db)):
    report = db.get(models.Report, report_id)
    if not report or not Path(report.file_path).exists():
        raise HTTPException(404, "Rapport introuvable")
    return FileResponse(
        report.file_path,
        media_type=_MEDIA.get(report.format, "application/octet-stream"),
        filename=report.stored_name,
    )


@router.delete("/{report_id}", status_code=204)
def delete_report(report_id: int, db: Session = Depends(get_db), _: models.User = Auth):
    report = db.get(models.Report, report_id)
    if not report:
        raise HTTPException(404, "Rapport introuvable")
    Path(report.file_path).unlink(missing_ok=True)
    db.delete(report)
    db.commit()
