"""Journal d'activité applicatif."""
from __future__ import annotations

from sqlalchemy.orm import Session

from .. import models


def log_activity(
    db: Session,
    type: str,
    message: str,
    severity: str = "low",
    entity_id: int | None = None,
) -> models.Activity:
    entry = models.Activity(
        type=type,
        message=message,
        severity=models.Severity(severity),
        entity_id=entity_id,
    )
    db.add(entry)
    db.commit()
    return entry
