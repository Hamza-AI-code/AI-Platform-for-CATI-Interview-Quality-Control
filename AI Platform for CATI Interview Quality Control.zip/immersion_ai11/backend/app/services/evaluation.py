"""Moteur d'évaluation qualité des entretiens CATI.

Principe central (v3) : la transcription est PARTIELLE. Elle ne couvre en
général que quelques questions ouvertes enregistrées — jamais l'entretien
complet. L'évaluation ne suppose donc JAMAIS qu'une réponse enregistrée est
correcte simplement parce que rien ne la contredit : « absence de preuve »
n'est pas « preuve de conformité ».

Pipeline par entretien :
    1. Contrôles déterministes (sans IA) : routage/skip logic, réponses
       obligatoires, anomalies de durée, doublons de verbatims.
    2. Vérification sémantique par LLM 100 % LOCAL (Ollama, via
       `ai_service`) — aucun cloud, aucune clé API : CHAQUE réponse
       enregistrée est confrontée aux extraits de transcription pertinents
       (recherche sémantique par embeddings) et classée :
         - verified            : la transcription confirme la réponse ;
         - contradicted        : la transcription contredit la réponse ;
         - not_enough_evidence : la transcription ne permet pas de trancher.
       Le LLM détecte aussi les problèmes de conduite (questions orientées,
       influence, relance insuffisante, fabrication…) étayés par citation.
    3. Score déterministe : la composante sémantique n'est calculée QUE sur
       les réponses évaluables (verified + contradicted) ; les questions sans
       preuve n'apportent ni bonus ni malus. Les anomalies déterministes et de
       conduite pénalisent en plus. Un entretien sans aucune réponse vérifiable
       ne peut jamais être « conforme » : il est au mieux « à contrôler ».
    4. Couverture : chaque évaluation expose combien de réponses ont pu être
       vérifiées / contredites / laissées sans preuve, et le pourcentage de
       couverture de la transcription.
"""
from __future__ import annotations

import hashlib
import json
import logging
import re
import statistics
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any

from sqlalchemy.orm import Session

from .. import models
from ..config import settings
from . import ai_service
from .lss_parser import evaluate_relevance

ENGINE_VERSION = "cati-eval-6.0-ollama"

# Pondération du score : score = base_sémantique - somme(poids_sévérité * confiance).
SEVERITY_WEIGHTS = {"low": 2.0, "medium": 5.0, "high": 12.0, "critical": 25.0}
PASS_THRESHOLD = 80.0
FAIL_THRESHOLD = 60.0

FRAUD_CATEGORIES = {
    "suspected_fabrication",
    "duplicate_verbatim",
    "timing_anomaly",
    "inconsistent_answers",
}

VALID_CATEGORIES = {
    "question_skipped",
    "question_not_asked_but_answered",
    "wrong_recording",
    "answer_mismatch",
    "missing_mandatory",
    "routing_violation",
    "wording_deviation",
    "leading_question",
    "respondent_influence",
    "misinterpretation",
    "inconsistent_answers",
    "data_entry_error",
    "timing_anomaly",
    "suspected_fabrication",
    "duplicate_verbatim",
    "unprofessional_conduct",
    "transcript_missing",
    "inadequate_probing",
}

# Catégories informatives : affichées mais JAMAIS comptées dans le score
# (l'absence de transcription n'est pas une faute de l'enquêteur — elle est
# gérée par le plafonnement du verdict, pas par une pénalité).
INFO_CATEGORIES = {"transcript_missing"}

# Catégories « désaccord réponse/transcription » : quand une réponse est déjà
# marquée contradicted par la vérification, on ignore les anomalies LLM
# redondantes de ces catégories sur la même question (pas de double comptage).
MISMATCH_CATEGORIES = {
    "answer_mismatch",
    "inconsistent_answers",
    "wrong_recording",
    "misinterpretation",
    "data_entry_error",
    "question_not_asked_but_answered",
}

VERIF_STATUSES = {"verified", "contradicted", "not_enough_evidence"}
_STATUS_RANK = {"not_enough_evidence": 0, "verified": 1, "contradicted": 2}

# Questions techniques à exclure des contrôles (métadonnées CATI).
TECH_CODES = {"poste", "client", "tel", "code", "sessioncode", "sessiongenerator", "duree"}


_YESNO = {"oui": "Y", "yes": "Y", "y": "Y", "non": "N", "no": "N", "n": "N"}


def _coerce_value(raw):
    """Convertit une valeur brute en valeur comparable, sinon lève.

    Principe de prudence : si la valeur enregistrée n'a pas pu être résolue en
    code d'option, on refuse de trancher le routage (RelevanceError → contrôle
    « inconnu ») plutôt que de produire de fausses anomalies.
    """
    from .lss_parser import RelevanceError

    if raw is None:
        return None
    s = str(raw).strip()
    low = s.lower()
    if low in _YESNO:
        return _YESNO[low]
    try:
        return float(s)
    except ValueError:
        pass
    if re.fullmatch(r"[A-Z]{1,4}\d{0,4}", s):  # ressemble à un code (AO01, A1, Y…)
        return s
    raise RelevanceError(f"valeur non résolue : {s[:40]!r}")


def _resolver(answers: dict):
    """resolve(code) pour l'évaluateur de pertinence."""
    from .lss_parser import RelevanceError

    def resolve(code: str):
        entry = answers.get(code)
        if entry is None:
            # Références SGQA brutes « 686916X4869X155632SQ002 » : non résolubles
            # de façon fiable → routage inconnu (jamais de fausse anomalie).
            if re.match(r"^\d+X\d+X\d+", code):
                raise RelevanceError(f"référence SGQA non résolue : {code}")
            # Sous-question « NomBanque_SQ010 ».
            if "_" in code:
                parent, _, sub = code.rpartition("_")
                p_entry = answers.get(parent)
                if p_entry is not None:
                    if not p_entry.get("shown"):
                        return None
                    return _coerce_value((p_entry.get("subs") or {}).get(sub))
            raise RelevanceError(f"code inconnu : {code}")
        if not entry.get("shown"):
            return None
        if entry.get("code"):
            return entry["code"]
        return _coerce_value(entry.get("raw"))

    return resolve


def _substantive_questions(definition: dict) -> list[dict]:
    """Questions du questionnaire hors affichage/calcul/métadonnées techniques."""
    return [
        q
        for q in definition.get("questions", [])
        if q.get("type") not in ("display_only", "computed")
        and str(q.get("code", "")).lower() not in TECH_CODES
    ]


def _answered_codes(interview: models.Interview, definition: dict) -> list[str]:
    """Codes des questions avec une réponse enregistrée (dans l'ordre du questionnaire)."""
    answers = interview.answers or {}
    return [
        q["code"]
        for q in _substantive_questions(definition)
        if (answers.get(q["code"]) or {}).get("shown")
    ]


# --------------------------------------------------------------------------- #
# 1. Contrôles déterministes
# --------------------------------------------------------------------------- #


def deterministic_findings(
    interview: models.Interview,
    definition: dict,
    duration_stats: tuple[float, float] | None,
    verbatim_index: dict[str, list[int]],
) -> tuple[list[dict], dict]:
    findings: list[dict] = []
    answers = interview.answers or {}
    resolve = _resolver(answers)
    questions = definition.get("questions", [])

    expected, skipped_ok, unknown = [], [], []
    for q in questions:
        code = q["code"]
        if q["type"] in ("display_only", "computed") or code.lower() in TECH_CODES:
            continue
        entry = answers.get(code) or {}
        if entry.get("unmapped"):
            # Colonne absente du fichier importé : impossible de vérifier.
            unknown.append(code)
            continue
        relevant = evaluate_relevance(q.get("relevance"), resolve)
        shown = bool(entry.get("shown"))
        if relevant is None:
            unknown.append(code)
            continue
        if relevant:
            expected.append(code)
            if not shown:
                findings.append({
                    "question_code": code,
                    "category": "question_skipped",
                    "severity": "high" if q.get("mandatory") else "medium",
                    "confidence": 1.0,
                    "source": "deterministic",
                    "recorded_value": None,
                    "expected_value": "Une réponse était attendue (routage satisfait)",
                    "explanation": (
                        "D'après le routage du questionnaire, cette question devait être "
                        "posée à ce répondant, mais aucune réponse n'est enregistrée."
                    ),
                    "recommendation": "Vérifier que l'enquêteur suit l'intégralité du parcours du questionnaire.",
                })
        else:
            skipped_ok.append(code)
            if shown:
                findings.append({
                    "question_code": code,
                    "category": "routing_violation",
                    "severity": "medium",
                    "confidence": 1.0,
                    "source": "deterministic",
                    "recorded_value": entry.get("raw"),
                    "expected_value": "Aucune réponse (question non applicable selon le routage)",
                    "explanation": (
                        "Une réponse est enregistrée alors que la logique de saut du "
                        "questionnaire indiquait de ne pas poser cette question."
                    ),
                    "recommendation": "Respecter la logique de routage du questionnaire.",
                })

    # Anomalies de durée (fabrication probable si trop court).
    if duration_stats and interview.duration_sec:
        median, p5 = duration_stats
        if interview.duration_sec < max(p5, 60):
            findings.append({
                "question_code": None,
                "category": "timing_anomaly",
                "severity": "high",
                "confidence": 0.9,
                "source": "deterministic",
                "recorded_value": f"{interview.duration_sec}s",
                "expected_value": f"médiane du projet ≈ {int(median)}s",
                "explanation": (
                    f"Durée d'entretien anormalement courte ({interview.duration_sec}s) "
                    f"par rapport aux autres entretiens du projet — signal de fabrication possible."
                ),
                "recommendation": "Contrôler manuellement cet entretien (durée suspecte).",
            })
        elif interview.duration_sec > median * 4:
            findings.append({
                "question_code": None,
                "category": "timing_anomaly",
                "severity": "low",
                "confidence": 0.7,
                "source": "deterministic",
                "recorded_value": f"{interview.duration_sec}s",
                "expected_value": f"médiane du projet ≈ {int(median)}s",
                "explanation": "Durée d'entretien anormalement longue par rapport au projet.",
                "recommendation": "Vérifier les conditions de passation de cet entretien.",
            })

    # Verbatims dupliqués entre entretiens (copier-coller / fabrication).
    for t in interview.transcripts:
        text_norm = re.sub(r"\s+", " ", (t.raw_text or "").strip().lower())
        if len(text_norm) < 40:
            continue
        digest = hashlib.sha1(text_norm.encode()).hexdigest()
        others = [i for i in verbatim_index.get(digest, []) if i != interview.id]
        if others:
            findings.append({
                "question_code": t.question_code,
                "category": "duplicate_verbatim",
                "severity": "critical",
                "confidence": 1.0,
                "source": "deterministic",
                "recorded_value": (t.raw_text or "")[:200],
                "expected_value": None,
                "explanation": (
                    "Cette transcription est identique à celle d'un autre entretien "
                    f"(IDs internes : {others[:5]}) — fort signal de fabrication."
                ),
                "recommendation": "Escalader au superviseur : entretiens potentiellement fabriqués.",
            })

    coverage = {
        "expected_questions": len(expected),
        "correctly_skipped": len(skipped_ok),
        "routing_unknown": len(unknown),
        "transcribed_segments": len(interview.transcripts),
        "transcribed_questions": sorted(
            {t.question_code for t in interview.transcripts if t.question_code}
        ),
    }
    return findings, coverage


# --------------------------------------------------------------------------- #
# 2. Vérification sémantique LLM (Ollama, local)
# --------------------------------------------------------------------------- #
# Toute la mécanique d'appel (clé API, retries, timeouts, rate limits, sorties
# JSON structurées) vit dans `ai_service`. Ce module ne fait
# qu'assembler les prompts et orchestrer les appels.
#
# Optimisation des tokens :
#   - UN appel IA par entretien (cas courant) : toutes les questions,
#     leurs réponses et la transcription partagée (dédupliquée par id de
#     contexte) partent dans le même prompt ;
#   - l'instruction système est STATIQUE (identique pour tous les appels) →
#     cache de prompt des fournisseurs ;
#   - les embeddings des questions sont calculés UNE fois par questionnaire
#     (cache mémoire) et réutilisés pour tous les entretiens ;
#   - les transcriptions ordinaires (< SMALL_TRANSCRIPT_CHARS) sont envoyées
#     complètes, sans appel d'embedding — comme un contrôleur humain, le
#     modèle lit tout l'entretien ; la recherche sémantique ne sert qu'aux
#     transcriptions exceptionnellement longues.

_logger = logging.getLogger("immerssion.evaluation")

# Découpage de la transcription en morceaux pour la recherche sémantique.
CHUNK_MAX_CHARS = 700
# Un contrôleur humain lit TOUTE la transcription — le modèle aussi : en
# dessous de ce seuil (où tient la quasi-totalité des entretiens CATI), la
# transcription complète est envoyée telle quelle. La recherche par
# embeddings, avec perte, ne sert qu'aux transcriptions exceptionnellement
# longues. Comme l'entretien part en UN seul appel avec contexte partagé
# (dédupliqué), le coût reste celui d'une seule copie du texte.
SMALL_TRANSCRIPT_CHARS = 20000  # en dessous : tout envoyer, pas d'embeddings
TOP_K_CHUNKS = 8               # extraits les plus pertinents par question
MMR_LAMBDA = 0.7               # pertinence vs diversité (anti-redondance)

_ANALYSIS_SYSTEM = """\
Tu es un AUDITEUR QUALITÉ SENIOR des enquêtes téléphoniques CATI pour un \
institut d'études de marché. Ton niveau d'exigence est celui d'un contrôleur \
humain expérimenté qui relit l'entretien mot à mot : si une erreur est \
évidente pour un relecteur humain, tu DOIS la détecter. Tu évalues le travail \
de l'ENQUÊTEUR (SPEAKER A), pas du répondant (SPEAKER B). Les conversations \
sont en français et/ou en darija marocaine (arabe dialectal, écrit en \
caractères arabes ou latins) : tu comprends parfaitement les deux, y compris \
les expressions idiomatiques, l'ironie et le sentiment implicite.

CONTEXTE — TRANSCRIPTION PARTIELLE :
La transcription peut ne pas couvrir l'entretien complet. L'absence TOTALE \
d'un sujet dans le texte ne prouve rien : ni que la réponse est correcte, ni \
qu'elle est fausse. En revanche, tout ce qui EST transcrit doit être exploité \
à fond.

ENTRÉE (JSON) — UN SEUL message couvre tout l'entretien :
- "contextes" : dictionnaire {id -> texte de transcription}. Un même texte \
est partagé par plusieurs questions (déduplication) ; ne le relis qu'une fois.
- "verifications_demandees" : liste d'éléments {question_code, question, \
options, reponse_enregistree, contexte}, où "contexte" référence un id de \
"contextes".
- "analyse_conduite" : true si les MISSIONS 2 et 3 doivent aussi être \
effectuées.
- "transcriptions_completes" : fourni uniquement quand les contextes ne \
couvrent pas toute la transcription (sers-t'en alors pour les MISSIONS 2-3).

MISSION 1 — VÉRIFICATION de chaque réponse enregistrée.
Pour CHAQUE élément de `verifications_demandees`, procède en DEUX temps :
1. RECHERCHE : parcours TOUTE la transcription disponible (son contexte, et \
les autres contextes s'ils diffèrent) et relève chaque passage \
sémantiquement lié au sujet de la question — confirmation directe, \
paraphrase, synonyme, récit, exemple concret, sentiment exprimé, sens \
implicite, intention, réponse indirecte, expression darija. Un passage dit \
pendant une AUTRE question compte autant (un récit de problèmes contredit \
une note de satisfaction, où qu'il apparaisse dans l'appel).
2. VERDICT : confronte la réponse enregistrée à ces passages.
- "verified" : les passages confirment la réponse (mêmes mots OU sens \
équivalent OU sentiment cohérent OU implication claire).
- "contradicted" : les passages disent ou impliquent autre chose que la \
réponse enregistrée — même exprimé avec des mots totalement différents, par \
le ton, par un récit, ou en darija. Une contradiction PARTIELLE compte : \
« Très satisfait » enregistré alors que le répondant est mitigé ou nuancé \
→ contradicted (confidence moyenne).
- "not_enough_evidence" : RIEN dans toute la transcription ne se rapporte \
au sujet de la question. Ce statut est RÉSERVÉ à ce cas : si un passage lié \
existe, tu dois trancher verified ou contradicted (ajuste la confiance, ne \
fuis pas la décision). Ne t'en sers JAMAIS pour éviter de trancher un cas \
difficile.

Règles de vérification :
- Ne JAMAIS répondre "verified" parce que rien ne contredit la réponse : il \
faut une preuve positive.
- Raisonne sur le SENS, jamais sur les mots-clés. « Makayn la service la \
walou » (il n'y a aucun service), « 3yit » (j'en ai marre), « khassni \
nbeddel » (je dois changer) expriment l'insatisfaction même sans le mot \
« insatisfait ».
- L'intention et l'implicite comptent : « je la conseille déjà à mes amis » \
implique « recommanderait : Oui » ; « je dois changer de banque » implique \
une insatisfaction globale.
- Attention aux négations, aux tournures concessives (« c'est bien mais... ») \
et aux réponses corrigées en cours d'appel (la DERNIÈRE position du \
répondant fait foi).
- confidence : 0.8-1.0 = confirmation/contradiction directe et explicite ; \
0.5-0.8 = inférence solide ; < 0.5 = inférence faible ou formulation ambiguë. \
Pour "not_enough_evidence", confidence exprime ta certitude qu'aucune preuve \
n'existe dans la transcription.
- evidence : citation exacte et courte de la transcription (langue d'origine) \
pour "verified" et "contradicted" ; null pour "not_enough_evidence".
- explanation : justification courte et claire en français.
- Retourne EXACTEMENT un objet par élément demandé, avec le même question_code.

EXEMPLES (MISSION 1) :
- « Satisfait » enregistré ; « Franchement ça s'est très bien passé » → \
verified (paraphrase, sentiment positif).
- « Très satisfait » enregistré ; « Le service était catastrophique » → \
contradicted (sentiment opposé, formulation différente).
- « Très satisfait » enregistré ; « wallah makayn la service la walou, 3yit » \
→ contradicted (insatisfaction claire en darija).
- « Non » à « Avez-vous contacté le service client ? » ; « j'ai appelé trois \
fois le mois dernier » (dit pendant une autre question) → contradicted \
(preuve trouvée ailleurs dans l'appel).
- « Oui » à « Recommanderiez-vous la banque ? » ; « je la conseille déjà à \
mes amis » → verified (implication).
- « Oui » à « Recommanderiez-vous la banque ? » ; transcription ne parlant \
que des horaires d'agence → not_enough_evidence (aucun passage lié).

MISSION 2 — CONDUITE DE L'ENQUÊTEUR (uniquement si "analyse_conduite" est \
true ; sinon retourne findings = [], conduct_notes = "" et \
fabrication_suspicion = 0). Analyse l'ensemble des transcriptions \
("transcriptions_completes" si fourni, sinon tous les "contextes") et signale \
uniquement les anomalies étayées par une citation :
- leading_question : l'enquêteur suggère la réponse ou oriente le répondant \
(« donc plutôt satisfait ? », proposer une seule option, insister).
- respondent_influence : l'enquêteur commente, juge, corrige ou influence \
les réponses du répondant.
- inadequate_probing : relance insuffisante sur une question ouverte \
(réponse vague non explorée).
- wording_deviation : l'enquêteur reformule ou abrège la question au lieu de \
la lire telle quelle (quand la lecture attendue est reconnaissable).
- unprofessional_conduct : ton inapproprié, impatience, impolitesse.
- question_not_asked_but_answered : une réponse est enregistrée alors que la \
transcription montre que la question n'a jamais été posée au répondant, ou \
que le répondant n'a jamais donné cette réponse alors que le passage \
correspondant de l'appel est transcrit.
- suspected_fabrication : la transcription ne ressemble pas à un vrai \
échange (vide, monologue, hors sujet, réponses récitées sans question).

MISSION 3 — COHÉRENCE ENTRE RÉPONSES (uniquement si "analyse_conduite" est \
true). Examine l'ENSEMBLE des couples question/réponse de \
`verifications_demandees` et signale (catégorie "inconsistent_answers") les \
combinaisons logiquement impossibles ou hautement improbables entre réponses \
ENREGISTRÉES. Exemples : « n'a jamais contacté le service client » + « très \
satisfait du traitement de sa dernière réclamation » ; « ne possède aucun \
produit » + « utilise l'application tous les jours » ; une note globale \
extrême incohérente avec toutes les sous-notes. Pour ces anomalies, \
question_code = la question la plus concernée, explanation cite LES DEUX \
réponses en conflit, evidence peut rester null si la contradiction vient des \
réponses elles-mêmes.

Règles STRICTES (missions 2-3) :
- Chaque anomalie de conduite (mission 2) DOIT citer la transcription \
(champ evidence, citation courte dans la langue d'origine).
- Ne signale PAS ici les désaccords réponse/transcription : ils sont \
couverts par les statuts "contradicted" de la MISSION 1.
- Si la transcription est ambiguë, baisse confidence au lieu de deviner.
- N'invente jamais d'anomalie sur des passages non transcrits.
- recommendation : conseil concret et actionnable pour l'enquêteur, en \
français.
- conduct_notes : appréciation globale en français.
- fabrication_suspicion : probabilité (0-1) que l'entretien soit fabriqué.

SORTIE : réponds UNIQUEMENT avec un objet JSON valide conforme au schéma."""

_ANALYSIS_SCHEMA = {
    "type": "object",
    "properties": {
        "verifications": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question_code": {"type": "string"},
                    "status": {
                        "type": "string",
                        "enum": ["verified", "contradicted", "not_enough_evidence"],
                    },
                    "confidence": {"type": "number"},
                    "evidence": {"type": ["string", "null"]},
                    "explanation": {"type": "string"},
                },
                "required": ["question_code", "status", "confidence", "explanation"],
            },
        },
        "findings": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question_code": {"type": ["string", "null"]},
                    "category": {
                        "type": "string",
                        "enum": [
                            "leading_question",
                            "respondent_influence",
                            "inadequate_probing",
                            "wording_deviation",
                            "unprofessional_conduct",
                            "question_not_asked_but_answered",
                            "inconsistent_answers",
                            "suspected_fabrication",
                        ],
                    },
                    "severity": {
                        "type": "string",
                        "enum": ["low", "medium", "high", "critical"],
                    },
                    "confidence": {"type": "number"},
                    "evidence": {"type": ["string", "null"]},
                    "explanation": {"type": "string"},
                    "recommendation": {"type": ["string", "null"]},
                },
                "required": ["category", "severity", "confidence", "explanation"],
            },
        },
        "conduct_notes": {"type": "string"},
        "fabrication_suspicion": {"type": "number"},
    },
    "required": ["verifications", "findings", "conduct_notes", "fabrication_suspicion"],
}


def _chunk_transcripts(interview: models.Interview) -> list[dict]:
    """Découpe les transcriptions en morceaux (~CHUNK_MAX_CHARS) par tours de parole.

    Chevauchement d'un tour de parole entre morceaux consécutifs pour ne pas
    couper une idée en deux.
    """
    chunks: list[dict] = []
    for t in interview.transcripts:
        label = t.question_code or t.original_name or "segment"
        turns = t.turns or []
        if turns:
            lines = [
                f"{turn.get('speaker', '?')}: {turn.get('text', '')}".strip()
                for turn in turns
                if turn.get("text")
            ]
        else:
            lines = [l.strip() for l in (t.raw_text or "").splitlines() if l.strip()]
        buf: list[str] = []
        size = 0
        for line in lines:
            if buf and size + len(line) > CHUNK_MAX_CHARS:
                chunks.append({"label": label, "text": "\n".join(buf)})
                buf = buf[-1:]  # chevauchement : dernier tour repris
                size = sum(len(x) + 1 for x in buf)
            buf.append(line)
            size += len(line) + 1
        if buf:
            chunks.append({"label": label, "text": "\n".join(buf)})
    return chunks


def _format_chunks(chunks: list[dict]) -> str:
    return "\n\n".join(f"[segment {c['label']}]\n{c['text']}" for c in chunks)


# Mots-outils français ignorés par la recherche lexicale (les mots porteurs
# de sens — y compris en darija translittérée — sont conservés tels quels).
_STOPWORDS = {
    "le", "la", "les", "un", "une", "des", "de", "du", "au", "aux", "et", "ou",
    "que", "qui", "quoi", "dans", "sur", "pour", "par", "pas", "ne", "est",
    "vous", "votre", "vos", "avec", "ce", "cette", "ces", "il", "elle", "je",
    "tu", "nous", "ils", "elles", "son", "sa", "ses", "en", "y", "a", "à",
    "être", "avoir", "plus", "moins", "très", "bien", "donc", "mais", "si",
}


def _tokens(text: str) -> set[str]:
    """Jetons significatifs d'un texte (minuscules, sans ponctuation)."""
    words = re.findall(r"[\w']+", text.lower(), re.UNICODE)
    return {w.strip("'") for w in words if len(w) > 2 and w not in _STOPWORDS}


def _question_query_tokens(q: dict) -> set[str]:
    opts = " ".join(o.get("label", "") for o in (q.get("options") or [])[:15])
    return _tokens(f"{q.get('text', '')} {opts}")


def _overlap_score(query: set[str], chunk: set[str]) -> float:
    """Similarité lexicale question/extrait (recouvrement normalisé)."""
    if not query or not chunk:
        return 0.0
    return len(query & chunk) / (len(query) ** 0.5 * (len(chunk) ** 0.5) + 1e-9)


def _build_contexts(
    interview: models.Interview, questions: list[dict]
) -> tuple[dict[str, str], bool]:
    """(question_code -> extraits pertinents, contextes_couvrent_tout).

    Transcription ordinaire (< SMALL_TRANSCRIPT_CHARS, la quasi-totalité des
    entretiens CATI) : la transcription COMPLÈTE est envoyée telle quelle —
    le modèle lit tout, comme un contrôleur humain — et le second élément
    vaut True. Comme le texte est partagé par toutes les questions via un
    seul id de contexte, il n'est transmis qu'UNE fois : aucun gaspillage.

    Transcription exceptionnellement longue : sélection LOCALE des extraits
    les plus pertinents par question (recouvrement lexical + MMR
    anti-redondance) — aucun appel réseau, aucun coût en tokens.
    """
    chunks = _chunk_transcripts(interview)
    if not chunks:
        return {q["code"]: "" for q in questions}, False
    total_chars = sum(len(c["text"]) for c in chunks)
    if total_chars <= SMALL_TRANSCRIPT_CHARS or len(chunks) <= TOP_K_CHUNKS:
        full = _format_chunks(chunks)
        return {q["code"]: full for q in questions}, True

    chunk_tokens = [_tokens(c["text"]) for c in chunks]
    contexts: dict[str, str] = {}
    for q in questions:
        qt = _question_query_tokens(q)
        if not qt:
            selected = list(range(min(TOP_K_CHUNKS, len(chunks))))
        else:
            selected = _mmr_select(qt, chunk_tokens, TOP_K_CHUNKS)
        contexts[q["code"]] = _format_chunks([chunks[i] for i in selected])
    return contexts, False


def _mmr_select(
    query_tokens: set[str], chunk_tokens: list[set[str]], k: int
) -> list[int]:
    """Sélection MMR : extraits pertinents ET diversifiés (100 % local).

    Un simple top-k par similarité se fait envahir par des passages
    quasi-identiques ; le critère « maximal marginal relevance » pénalise la
    redondance avec les extraits déjà retenus, pour qu'un passage porteur
    d'information nouvelle (ex. un récit négatif ailleurs dans l'appel) entre
    dans le contexte. Retourne les indices dans l'ordre chronologique.
    """
    relevance = [_overlap_score(query_tokens, ct) for ct in chunk_tokens]
    candidates = list(range(len(chunk_tokens)))
    selected: list[int] = []
    while candidates and len(selected) < k:
        best_i, best_score = candidates[0], float("-inf")
        for i in candidates:
            redundancy = max(
                (_overlap_score(chunk_tokens[i], chunk_tokens[j]) for j in selected),
                default=0.0,
            )
            score = MMR_LAMBDA * relevance[i] - (1.0 - MMR_LAMBDA) * redundancy
            if score > best_score:
                best_i, best_score = i, score
        selected.append(best_i)
        candidates.remove(best_i)
    return sorted(selected)  # ordre chronologique conservé


def _analyze_items(
    items: list[dict],
    include_conduct: bool,
    transcripts_block: list[dict] | None,
) -> tuple[dict[str, dict], dict | None]:
    """Analyse un LOT de questions — et la conduite — en UN SEUL appel IA.

    `items` : [{code, question, options, reponse, extraits, ctx_id}]. Les
    extraits identiques sont mutualisés dans un dictionnaire "contextes"
    (référencés par id) au lieu d'être répétés pour chaque question : le
    prompt ne contient chaque passage de transcription qu'UNE fois.

    `include_conduct` : greffe la mission « conduite de l'enquêteur »
    (anomalies + fabrication) sur ce même appel — plus d'appel séparé.
    `transcripts_block` : transcription complète, jointe uniquement quand les
    contextes ne la couvrent pas déjà.

    Retourne ({question_code: verification}, conduite | None).
    """
    context_map: dict[str, str] = {}
    for it in items:
        context_map.setdefault(it["ctx_id"], it["extraits"] or "(aucun extrait disponible)")
    payload: dict[str, Any] = {
        "contextes": context_map,
        "verifications_demandees": [
            {
                "question_code": it["code"],
                "question": it["question"],
                "options": it["options"],
                "reponse_enregistree": it["reponse"],
                "contexte": it["ctx_id"],
            }
            for it in items
        ],
        "analyse_conduite": include_conduct,
    }
    if include_conduct and transcripts_block:
        payload["transcriptions_completes"] = transcripts_block
    prompt = json.dumps(payload, ensure_ascii=False)
    # 32k tokens de sortie : assez pour ~40 vérifications détaillées même
    # dans le pire cas (le « thinking » est désactivé côté service, mais les
    # modèles de secours peuvent en consommer une partie).
    out = ai_service.generate_json(
        prompt,
        system=_ANALYSIS_SYSTEM,
        schema=_ANALYSIS_SCHEMA,
        max_output_tokens=32768,
    )

    wanted = {it["code"] for it in items}
    extraits_by_code = {it["code"]: it["extraits"] for it in items}
    results: dict[str, dict] = {}
    for v in out.get("verifications", []) or []:
        if not isinstance(v, dict):
            continue
        code = str(v.get("question_code") or "").strip()
        status = str(v.get("status") or "").strip()
        if code not in wanted or status not in VERIF_STATUSES:
            continue
        try:
            confidence = max(0.0, min(1.0, float(v.get("confidence", 0.5))))
        except (TypeError, ValueError):
            confidence = 0.5
        evidence = v.get("evidence")
        result = {
            "question_code": code,
            "status": status,
            "confidence": confidence,
            "evidence": (str(evidence)[:500] if evidence else None),
            "explanation": str(v.get("explanation") or "")[:1000],
        }
        results[code] = result
        _ai_debug({
            "question_code": code,
            "extraits_transcription": (extraits_by_code.get(code) or "")[:1500],
            "prompt": prompt[:1500],
            "reponse_ia": v,
            "resultat_final": result,
        })

    conduct: dict | None = None
    truncated = bool(out.get("_ai_truncated"))
    if include_conduct and truncated and "conduct_notes" not in out:
        # Réponse tronquée avant la section conduite : ne pas la considérer
        # comme faite — l'appelant la retentera.
        include_conduct = False
    if include_conduct:
        conduct = {
            "findings": out.get("findings") or [],
            "conduct_notes": str(out.get("conduct_notes") or ""),
            "fabrication_suspicion": out.get("fabrication_suspicion") or 0.0,
        }
        _ai_debug({
            "question_code": None,
            "mission": "conduite",
            "reponse_ia": {
                "findings": conduct["findings"],
                "conduct_notes": conduct["conduct_notes"][:500],
                "fabrication_suspicion": conduct["fabrication_suspicion"],
            },
        })
    return results, conduct


def _unverifiable(code: str, reason: str | None = None) -> dict:
    """Statut de repli quand l'appel IA échoue : jamais « correct par défaut »."""
    detail = f" Erreur : {reason[:200]}" if reason else ""
    return {
        "question_code": code,
        "status": "not_enough_evidence",
        "confidence": 0.0,
        "evidence": None,
        "explanation": (
            "Vérification indisponible (IA locale en erreur) : la réponse n'a pas "
            "pu être confrontée à la transcription." + detail
        ),
    }


def _ai_debug(record: dict) -> None:
    """Mode debug (AI_DEBUG=true) : trace par question dans les logs et
    dans data/ai_debug.jsonl — extraits sélectionnés, prompt envoyé,
    réponse JSON du modèle, résultat final."""
    if not settings.ai_debug:
        return
    record = {"ts": datetime.now(timezone.utc).isoformat(), **record}
    _logger.info("AI_DEBUG %s", json.dumps(record, ensure_ascii=False)[:4000])
    try:
        from ..config import DATA_DIR
        with open(DATA_DIR / "ai_debug.jsonl", "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError:  # trace fichier best-effort, jamais bloquante
        _logger.warning("Écriture de data/ai_debug.jsonl impossible.", exc_info=True)


def run_llm_analysis(interview: models.Interview, definition: dict) -> dict | None:
    """Analyse sémantique via Ollama (local). Retourne None si indisponible.

    - UN SEUL appel IA par entretien dans le cas courant : toutes les
      questions (chacune avec ses extraits de transcription pertinents,
      dédupliqués dans le prompt) ET l'analyse de conduite sont traitées dans
      le même prompt, avec une réponse JSON structurée par question.
    - Au-delà de ai_questions_per_call questions, l'entretien est découpé
      en un minimum de lots (conduite greffée sur le premier) — le temps GPU/CPU
      est consommé par requête, pas par question.
    - Un échec d'appel ne fait jamais échouer l'évaluation : la question passe
      en « not_enough_evidence », l'erreur est journalisée, et on continue.
    """
    if not ai_service.is_configured():
        _logger.error(
            "IA locale non configurée (OLLAMA_BASE_URL vide) : vérification sémantique "
            "impossible pour l'entretien %s — repli déterministe.", interview.id,
        )
        return None
    if not interview.transcripts:
        return None
    answers = interview.answers or {}
    questions = [
        q
        for q in _substantive_questions(definition)
        if (answers.get(q["code"]) or {}).get("shown")
    ]

    try:
        contexts, contexts_cover_all = _build_contexts(interview, questions)
    except Exception:  # défense en profondeur : jamais de crash d'évaluation
        _logger.exception("Préparation du contexte IA échouée (entretien %s).", interview.id)
        contexts, contexts_cover_all = {}, False

    # Éléments à vérifier — les extraits identiques partagent un même id de
    # contexte pour n'apparaître qu'une seule fois dans le prompt.
    ctx_ids: dict[str, str] = {}
    items: list[dict] = []
    for q in questions:
        entry = answers.get(q["code"]) or {}
        # Troncatures LARGES : couper un libellé d'option ou une question en
        # plein milieu fait perdre le sens exact — précisément ce dont
        # l'analyse sémantique a besoin pour détecter une contradiction fine.
        opts = "; ".join(
            f"{o['code']}={str(o.get('label') or '')[:120]}"
            for o in (q.get("options") or [])[:25]
        )
        extraits = contexts.get(q["code"], "")
        ctx_id = ctx_ids.setdefault(extraits, f"C{len(ctx_ids) + 1}")
        items.append({
            "code": q["code"],
            "question": q.get("text", "")[:700],
            "options": opts or None,
            "reponse": str(entry.get("label") or entry.get("raw") or "")[:500],
            "extraits": extraits,
            "ctx_id": ctx_id,
        })

    # Transcription complète : jointe UNIQUEMENT si les contextes ne la
    # couvrent pas déjà (mission conduite sur transcription longue).
    transcripts_block = None
    if not contexts_cover_all:
        transcripts_block = [
            {
                "question_code": t.question_code or t.original_name,
                "texte": t.raw_text[:4000],
            }
            for t in interview.transcripts
        ]

    # UN SEUL appel IA par entretien dans le cas courant : toutes les
    # questions + l'analyse de conduite dans le même prompt. Au-delà de
    # ai_questions_per_call questions, l'entretien est découpé en aussi
    # peu de lots que possible (la conduite reste greffée sur le premier).
    per_call = max(1, settings.ai_questions_per_call)
    batches = [items[i : i + per_call] for i in range(0, len(items), per_call)] or [[]]
    results: dict[str, dict] = {}
    conduct: dict | None = None
    errors: list[str] = []
    failed_batches: list[tuple[list[dict], bool]] = []

    def _work(args: tuple[list[dict], bool]) -> tuple[dict[str, dict], dict | None, tuple | None]:
        batch, with_conduct = args
        try:
            r, c = _analyze_items(batch, with_conduct, transcripts_block if with_conduct else None)
            return r, c, None
        except ai_service.AIUnavailable as exc:
            _logger.error(
                "Ollama arrêté (entretien %s) : arrêt immédiat, aucune "
                "nouvelle tentative. %s", interview.id, exc,
            )
            errors.append(f"OLLAMA_ARRETE: {exc}")
            return {}, None, None  # inutile de retenter tant qu'Ollama est arrêté
        except ai_service.AIModelUnavailable as exc:
            _logger.error(
                "Modèle Ollama non installé (entretien %s) : arrêt immédiat "
                "— installez-le (ollama pull) ou corrigez OLLAMA_MODEL dans backend/.env. %s",
                interview.id, exc,
            )
            errors.append(f"MODELE: {exc}")
            return {}, None, None  # retenter le même modèle absent est inutile
        except Exception as exc:
            _logger.exception(
                "Appel d'analyse IA échoué (%d question(s), conduite=%s, entretien %s).",
                len(batch), with_conduct, interview.id,
            )
            errors.append(str(exc))
            return {}, None, (batch, with_conduct)

    jobs = [(batch, i == 0) for i, batch in enumerate(batches) if batch or i == 0]
    if jobs:
        if len(jobs) == 1:
            outcomes = [_work(jobs[0])]
        else:
            workers = max(1, min(settings.ai_max_concurrency, len(jobs)))
            with ThreadPoolExecutor(max_workers=workers) as pool:
                outcomes = list(pool.map(_work, jobs))
        for r, c, failed in outcomes:
            results.update(r)
            if c is not None:
                conduct = c
            if failed:
                failed_batches.append(failed)

        # Seconde chance : erreurs transitoires (503, réponse tronquée…) —
        # toutes les questions restées sans verdict sont retentées UNE fois,
        # découpées en DEUX lots plus petits pour tenir largement dans le
        # budget de tokens de sortie. Jamais de nouvelle tentative sur un
        # service arrêté ou modèle absent.
        missing = [it for it in items if it["code"] not in results]
        quota_hit = any(
            e.startswith(("OLLAMA_ARRETE", "MODELE")) for e in errors
        ) or bool(ai_service.quota_blocked())
        need_conduct = conduct is None
        if (missing or need_conduct) and not quota_hit and (failed_batches or missing):
            time.sleep(3)
            retry_items = missing or items
            half = max(1, (len(retry_items) + 1) // 2)
            sub_batches = [
                retry_items[i : i + half] for i in range(0, len(retry_items), half)
            ]
            for j, sub in enumerate(sub_batches):
                with_conduct = j == 0 and conduct is None
                try:
                    r, c = _analyze_items(
                        sub,
                        with_conduct,
                        transcripts_block if with_conduct else None,
                    )
                    results.update(r)
                    if c is not None:
                        conduct = c
                    _logger.info(
                        "Seconde tentative réussie (%d question(s), entretien %s).",
                        len(sub), interview.id,
                    )
                except ai_service.AIUnavailable as exc:
                    errors.append(f"OLLAMA_ARRETE: {exc}")
                    break
                except Exception as exc:
                    _logger.exception(
                        "Seconde tentative échouée (entretien %s).", interview.id
                    )
                    errors.append(f"2e tentative : {exc}")

    verifications: list[dict] = []
    for q in questions:
        v = results.get(q["code"])
        if v is None:
            reason = errors[-1][:200] if errors else "aucun verdict retourné par le modèle pour cette question"
            v = _unverifiable(q["code"], reason)
        verifications.append(v)
    successes = len(results)

    any_success = successes > 0 or conduct is not None
    if not any_success:
        _logger.error(
            "L'IA n'a fourni AUCUNE réponse exploitable pour l'entretien %s "
            "(%d question(s)). Première erreur : %s",
            interview.id, len(questions), errors[0] if errors else "inconnue",
        )
    conduct = conduct or {}
    result = {
        "verifications": verifications,
        "findings": conduct.get("findings") or [],
        "conduct_notes": conduct.get("conduct_notes") or "",
        "fabrication_suspicion": conduct.get("fabrication_suspicion") or 0.0,
        "any_success": any_success,
    }
    if errors:
        result["semantic_error"] = errors[0][:300]
        if any(e.startswith("OLLAMA_ARRETE:") for e in errors):
            result["quota_exceeded"] = True
    return result


def _merge_verifications(llm: dict | None, answered: list[str]) -> list[dict]:
    """Normalise les statuts de vérification : un statut pour CHAQUE réponse.

    Toute question sans verdict exploitable du LLM (absente, code inconnu,
    statut invalide, LLM indisponible) est explicitement marquée
    not_enough_evidence — jamais implicitement « correcte ».
    """
    answered_set = set(answered)
    by_code: dict[str, dict] = {}
    for v in (llm or {}).get("verifications", []) or []:
        if not isinstance(v, dict):
            continue
        code = str(v.get("question_code") or "").strip()
        status = str(v.get("status") or "").strip()
        if code not in answered_set or status not in VERIF_STATUSES:
            continue
        try:
            conf = max(0.0, min(1.0, float(v.get("confidence", 0.5))))
        except (TypeError, ValueError):
            conf = 0.5
        entry = {
            "question_code": code,
            "status": status,
            "confidence": conf,
            "evidence": (str(v["evidence"])[:500] if v.get("evidence") else None),
            "explanation": str(v.get("explanation") or "")[:1000],
        }
        prev = by_code.get(code)
        # Doublons : on garde le statut le plus grave, puis la meilleure confiance.
        if prev is None or (_STATUS_RANK[status], conf) > (
            _STATUS_RANK[prev["status"]],
            prev["confidence"],
        ):
            by_code[code] = entry

    merged = []
    for code in answered:
        merged.append(
            by_code.get(code)
            or {
                "question_code": code,
                "status": "not_enough_evidence",
                "confidence": 1.0,
                "evidence": None,
                "explanation": (
                    "La transcription (partielle) ne contient aucun élément permettant "
                    "de vérifier ou d'infirmer cette réponse."
                ),
            }
        )
    return merged


# --------------------------------------------------------------------------- #
# 3. Score & verdict
# --------------------------------------------------------------------------- #


def compute_score(
    findings: list[dict], verifications: list[dict] | None = None
) -> tuple[float, float, str]:
    """Score fondé sur les preuves.

    - Base sémantique = 100 × Σconf(verified) / (Σconf(verified) + Σconf(contradicted)),
      calculée UNIQUEMENT sur les réponses évaluables. Les réponses sans preuve
      n'apportent ni bonus ni malus.
    - Les anomalies déterministes et de conduite retranchent ensuite des points
      (les contradictions ne sont pas re-pénalisées : déjà dans la base).
    - Sans AUCUNE réponse évaluable, le verdict ne peut pas être « pass » :
      l'absence de preuve n'est pas une preuve de conformité.
    """
    verifications = verifications or []
    penalty = 0.0
    fraud = 0.0
    for f in findings:
        weight = SEVERITY_WEIGHTS.get(f.get("severity", "medium"), 5.0)
        conf = max(0.0, min(1.0, float(f.get("confidence", 1.0))))
        if f.get("category") in FRAUD_CATEGORIES:
            fraud += weight * conf * 2.5
        if f.get("category") in INFO_CATEGORIES or f.get("_from_verification"):
            continue
        penalty += weight * conf

    verified_w = sum(v["confidence"] for v in verifications if v["status"] == "verified")
    contradicted_w = sum(
        v["confidence"] for v in verifications if v["status"] == "contradicted"
    )
    evaluable = sum(1 for v in verifications if v["status"] in ("verified", "contradicted"))
    if verified_w + contradicted_w > 0:
        base = 100.0 * verified_w / (verified_w + contradicted_w)
    else:
        base = 100.0

    score = max(0.0, min(100.0, base - penalty))
    fraud_risk = max(0.0, min(100.0, fraud))
    if any(f.get("severity") == "critical" for f in findings) or score < FAIL_THRESHOLD:
        verdict = "fail"
    elif score < PASS_THRESHOLD:
        verdict = "needs_review"
    elif evaluable == 0:
        # Rien n'a pu être vérifié : impossible de certifier la conformité.
        verdict = "needs_review"
    else:
        verdict = "pass"
    return round(score, 1), round(fraud_risk, 1), verdict


# --------------------------------------------------------------------------- #
# Orchestration
# --------------------------------------------------------------------------- #


def _project_context(db: Session, questionnaire_id: int):
    """Statistiques de durée + index de verbatims pour tout le projet."""
    interviews = (
        db.query(models.Interview)
        .filter(models.Interview.questionnaire_id == questionnaire_id)
        .all()
    )
    durations = [i.duration_sec for i in interviews if i.duration_sec]
    duration_stats = None
    if len(durations) >= 10:
        durations.sort()
        median = statistics.median(durations)
        p5 = durations[max(0, int(len(durations) * 0.05) - 1)]
        duration_stats = (median, p5)

    verbatim_index: dict[str, list[int]] = {}
    transcripts = (
        db.query(models.Transcript)
        .join(models.Interview)
        .filter(models.Interview.questionnaire_id == questionnaire_id)
        .all()
    )
    for t in transcripts:
        text_norm = re.sub(r"\s+", " ", (t.raw_text or "").strip().lower())
        if len(text_norm) < 40:
            continue
        digest = hashlib.sha1(text_norm.encode()).hexdigest()
        verbatim_index.setdefault(digest, []).append(t.interview_id)
    return duration_stats, verbatim_index


def evaluate_interview(
    db: Session,
    interview: models.Interview,
    duration_stats=None,
    verbatim_index=None,
) -> models.Evaluation:
    """Évalue un entretien et persiste le résultat (remplace l'évaluation précédente)."""
    definition = interview.questionnaire.definition or {}
    if duration_stats is None or verbatim_index is None:
        duration_stats, verbatim_index = _project_context(db, interview.questionnaire_id)

    # Remplace les évaluations précédentes de cet entretien.
    for old in list(interview.evaluations):
        db.delete(old)
    db.flush()

    evaluation = models.Evaluation(
        interview_id=interview.id,
        status=models.EvaluationStatus.running,
        mode="segment",
        engine="heuristic",
    )
    db.add(evaluation)
    # COMMIT immédiat (et non un simple flush) : l'analyse IA qui suit
    # peut durer plusieurs minutes (appels réseau, retries). Garder la
    # transaction d'écriture ouverte pendant ce temps verrouillerait SQLite
    # et ferait échouer toutes les autres écritures de l'API
    # (« database is locked »).
    db.commit()

    try:
        findings, coverage = deterministic_findings(
            interview, definition, duration_stats, verbatim_index
        )
        answers = interview.answers or {}
        answered = _answered_codes(interview, definition)

        if not interview.transcripts:
            findings.append({
                "question_code": None,
                "category": "transcript_missing",
                "severity": "low",
                "confidence": 1.0,
                "source": "deterministic",
                "recorded_value": None,
                "expected_value": None,
                "explanation": (
                    "Aucune transcription liée à cet entretien (Session Code absent du "
                    "fichier de transcriptions) : aucune réponse n'a pu être vérifiée "
                    "sémantiquement."
                ),
                "recommendation": "Vérifier l'export des transcriptions pour ce Session Code.",
            })

        llm = run_llm_analysis(interview, definition)
        # llm_ok = le modèle a réellement répondu au moins une fois ; sinon on
        # reste sur le moteur heuristique et l'erreur exacte est affichée.
        llm_ok = bool(llm) and llm.get("any_success", True)
        semantic_error = (llm or {}).get("semantic_error")
        verifications = _merge_verifications(llm, answered)
        contradicted_codes = {
            v["question_code"] for v in verifications if v["status"] == "contradicted"
        }

        summary_extra = ""
        if llm:
            if llm_ok:
                evaluation.engine = "ollama"
            for f in llm.get("findings", []):
                cat = str(f.get("category", "")).strip()
                if cat not in VALID_CATEGORIES:
                    continue
                # Déjà couvert par un statut « contradicted » : pas de double comptage.
                if cat in MISMATCH_CATEGORIES and f.get("question_code") in contradicted_codes:
                    continue
                findings.append({
                    "question_code": f.get("question_code"),
                    "category": cat,
                    "severity": f.get("severity", "medium"),
                    "confidence": float(f.get("confidence", 0.6)),
                    "source": "llm",
                    "recorded_value": f.get("recorded_value"),
                    "expected_value": f.get("expected_value"),
                    "evidence": f.get("evidence"),
                    "explanation": f.get("explanation", ""),
                    "recommendation": f.get("recommendation"),
                })
            suspicion = float(llm.get("fabrication_suspicion", 0) or 0)
            if suspicion >= 0.7:
                findings.append({
                    "question_code": None,
                    "category": "suspected_fabrication",
                    "severity": "critical" if suspicion >= 0.85 else "high",
                    "confidence": suspicion,
                    "source": "llm",
                    "explanation": "L'analyse sémantique suspecte un entretien fabriqué ou non conforme.",
                    "recommendation": "Contrôle manuel prioritaire de cet entretien.",
                })
            summary_extra = (llm.get("conduct_notes") or "").strip()

        # Les contradictions deviennent des anomalies visibles (avec preuve).
        # Marquées _from_verification : le score les compte via la base
        # sémantique, pas via la pénalité (pas de double comptage).
        for v in verifications:
            if v["status"] != "contradicted":
                continue
            entry = answers.get(v["question_code"]) or {}
            findings.append({
                "question_code": v["question_code"],
                "category": "answer_mismatch",
                "severity": "high" if v["confidence"] >= 0.75 else "medium",
                "confidence": v["confidence"],
                "source": "llm",
                "recorded_value": entry.get("label") or entry.get("raw"),
                "expected_value": None,
                "evidence": v.get("evidence"),
                "explanation": v.get("explanation")
                or "La transcription contredit la réponse enregistrée.",
                "recommendation": "Enregistrer exactement la réponse donnée par le répondant.",
                "_from_verification": True,
            })

        n_verified = sum(1 for v in verifications if v["status"] == "verified")
        n_contradicted = len(contradicted_codes)
        n_insufficient = sum(
            1 for v in verifications if v["status"] == "not_enough_evidence"
        )
        evaluable = n_verified + n_contradicted
        coverage_pct = round(100.0 * evaluable / len(answered), 1) if answered else 0.0
        coverage.update({
            "answered_questions": len(answered),
            "verified": n_verified,
            "contradicted": n_contradicted,
            "insufficient_evidence": n_insufficient,
            "evaluable_questions": evaluable,
            "coverage_pct": coverage_pct,
            "verifications": verifications,
        })
        if semantic_error:
            coverage["semantic_error"] = semantic_error
        if llm_ok:
            coverage["ai_model"] = ai_service.active_model()

        # Analyse sémantique requise (clé + transcriptions) mais totalement
        # impossible (quota, panne) : AUCUN score ne doit être produit — un
        # « 100/100 · 0 anomalie » sans analyse serait un faux rapport.
        semantic_required = ai_service.is_configured() and bool(interview.transcripts)
        semantic_failed = semantic_required and not llm_ok
        quota_exceeded = bool((llm or {}).get("quota_exceeded"))

        score, fraud_risk, verdict = compute_score(findings, verifications)

        for f in findings:
            db.add(
                models.Finding(
                    evaluation_id=evaluation.id,
                    question_code=f.get("question_code"),
                    category=f["category"],
                    severity=models.Severity(f.get("severity", "medium")),
                    confidence=float(f.get("confidence", 1.0)),
                    source=f.get("source", "deterministic"),
                    recorded_value=f.get("recorded_value"),
                    expected_value=f.get("expected_value"),
                    evidence=f.get("evidence"),
                    explanation=f.get("explanation", ""),
                    recommendation=f.get("recommendation"),
                )
            )

        n_high = sum(1 for f in findings if f.get("severity") in ("high", "critical"))
        semantic_note = ""
        if not interview.transcripts:
            semantic_note = " Aucune transcription liée : vérification sémantique impossible."
        elif llm is None:
            semantic_note = (
                " IA locale non configurée (OLLAMA_BASE_URL vide) : vérification "
                "sémantique désactivée — aucune réponse n'a pu être vérifiée."
            )
        elif not llm_ok:
            semantic_note = (
                " Analyse sémantique IA EN ÉCHEC — aucune réponse vérifiée. "
                f"Erreur : {(semantic_error or 'inconnue')[:200]} (voir les logs)."
            )
        elif evaluable == 0:
            semantic_note = (
                " La transcription partielle ne permet de vérifier aucune réponse : "
                "conformité non certifiable."
            )
        evaluation.coverage = coverage
        if semantic_failed:
            # ANALYSE INCOMPLÈTE : pas de score, pas de verdict, cause exacte.
            reason = (
                "Ollama n'est pas lancé — démarrez Ollama puis relancez l'évaluation"
                if quota_exceeded
                else f"l'IA locale (Ollama) est en échec ({(semantic_error or 'erreur inconnue')[:200]})"
            )
            evaluation.quality_score = None
            evaluation.fraud_risk = None
            evaluation.verdict = None
            evaluation.error = (
                f"Analyse sémantique impossible : {reason}. "
                "Aucun score n'a été calculé — relancez l'évaluation une fois "
                "le service rétabli."
            )[:2000]
            evaluation.summary = (
                f"ANALYSE INCOMPLÈTE — {reason}. Aucune réponse n'a été "
                f"confrontée à la transcription : aucun score n'est produit. "
                f"Contrôles déterministes seuls : {len(findings)} anomalie(s) "
                f"dont {n_high} grave(s)."
            )
            evaluation.status = models.EvaluationStatus.failed
            _logger.error(
                "Entretien %s : %s", interview.id, evaluation.error,
            )
        else:
            evaluation.quality_score = score
            evaluation.fraud_risk = fraud_risk
            evaluation.verdict = verdict
            # Résumé centré sur les PROBLÈMES (la direction ne veut voir que ce
            # qui ne va pas — les confirmations restent internes au score).
            evaluation.summary = (
                f"{len(findings)} anomalie(s) dont {n_high} grave(s) · "
                f"{n_contradicted} contradiction(s) réponse/transcription. "
                f"Couverture transcription {coverage_pct:.0f}% "
                f"({evaluable}/{len(answered)} réponses évaluables). "
                f"Score {score:.0f}/100 · Risque fraude {fraud_risk:.0f}/100."
                + semantic_note
                + (f" {summary_extra}" if summary_extra else "")
            )
            evaluation.status = models.EvaluationStatus.completed
            evaluation.completed_at = datetime.now(timezone.utc).replace(tzinfo=None)
    except Exception as exc:  # pragma: no cover — robustesse du lot
        evaluation.status = models.EvaluationStatus.failed
        evaluation.error = str(exc)[:2000]
    db.commit()
    return evaluation


def _already_evaluated(interview: models.Interview) -> bool:
    """True si l'entretien possède déjà une évaluation TERMINÉE.

    Une évaluation en échec (« analyse incomplète ») ne compte pas : elle n'a
    produit aucun résultat et doit pouvoir être relancée.
    """
    return any(
        e.status == models.EvaluationStatus.completed for e in interview.evaluations
    )


def evaluate_batch(
    db: Session,
    questionnaire_id: int,
    interview_ids: list[int] | None = None,
    skip_evaluated: bool = True,
) -> dict:
    """Évalue les entretiens d'un questionnaire (ou une sélection).

    `skip_evaluated=True` (défaut) : les entretiens qui possèdent déjà une
    évaluation terminée sont IGNORÉS — leurs résultats stockés restent
    affichés et AUCUN appel IA n'est fait pour eux. Seul le bouton
    « Ré-évaluer » d'un entretien force un nouveau calcul.
    """
    query = db.query(models.Interview).filter(
        models.Interview.questionnaire_id == questionnaire_id
    )
    if interview_ids:
        query = query.filter(models.Interview.id.in_(interview_ids))
    interviews = query.all()
    skipped = 0
    if skip_evaluated:
        todo = [i for i in interviews if not _already_evaluated(i)]
        skipped = len(interviews) - len(todo)
        if skipped:
            _logger.info(
                "%d entretien(s) déjà évalué(s) : résultats existants conservés, "
                "aucun appel IA pour eux.", skipped,
            )
        interviews = todo
    done = failed = 0
    if interviews:
        duration_stats, verbatim_index = _project_context(db, questionnaire_id)
        for interview in interviews:
            ev = evaluate_interview(db, interview, duration_stats, verbatim_index)
            if ev.status == models.EvaluationStatus.completed:
                done += 1
            else:
                failed += 1
        _refresh_recommendations(db)
    result = {
        "evaluated": done,
        "failed": failed,
        "skipped": skipped,
        "total": len(interviews) + skipped,
    }
    quota = ai_service.quota_blocked()
    if quota:
        result["quota_exceeded"] = True
        _logger.error(
            "Lot d'évaluation terminé avec Ollama indisponible : %d analyse(s) "
            "incomplète(s). %s", failed, quota,
        )
    return result


# --------------------------------------------------------------------------- #
# Recommandations par enquêteur (Post)
# --------------------------------------------------------------------------- #

# Recommandations pour la DIRECTION (chef de projet) : pour chaque type
# d'anomalie, ce qui doit être revu dans le questionnaire, le routage ou la
# formation. Paramétrées par le code de la question concernée.
MANAGER_ADVICE: dict[str, list[str]] = {
    "answer_mismatch": [
        "Réexaminer la formulation de la question {code} : des réponses enregistrées contredisent les propos réels des répondants.",
        "Vérifier que les options de réponse de {code} représentent correctement les opinions exprimées par les répondants.",
        "Renforcer la formation des enquêteurs sur la saisie fidèle des réponses à cette question.",
        "Si les écarts persistent, envisager de réécrire la question ou ses modalités de réponse.",
    ],
    "inconsistent_answers": [
        "Contrôler la cohérence des questions liées à {code} (filtres, échelles, questions miroirs).",
        "Vérifier si l'ordre ou la formulation des questions induit une confusion chez les répondants.",
    ],
    "wrong_recording": [
        "Vérifier la clarté des options de la question {code} : les enquêteurs saisissent des réponses déformées.",
        "Ajouter une consigne enquêteur expliquant comment enregistrer les réponses ambiguës.",
    ],
    "misinterpretation": [
        "Les répondants ou enquêteurs interprètent la question {code} différemment de l'intention : envisager de simplifier la formulation.",
        "Ajouter une consigne enquêteur expliquant comment poser et coder cette question.",
    ],
    "data_entry_error": [
        "Contrôler le masque de saisie de la question {code} et prévoir un contrôle de cohérence à l'enregistrement.",
    ],
    "routing_violation": [
        "Vérifier la condition de routage de la question {code} dans le questionnaire .LSS.",
        "Des répondants atteignent cette question sans satisfaire les critères prévus : revoir la logique de saut.",
        "Contrôler les équations de pertinence associées à cette question.",
    ],
    "question_skipped": [
        "Vérifier pourquoi la question {code} n'est pas posée : routage trop restrictif, consigne manquante ou question difficile à administrer.",
        "Revoir la logique de saut qui précède cette question dans le .LSS.",
        "Rappeler aux enquêteurs que le parcours du questionnaire doit être suivi intégralement.",
    ],
    "missing_mandatory": [
        "La question obligatoire {code} reste sans réponse : vérifier sa formulation et sa position dans le parcours.",
        "Prévoir un rappel de consigne : aucune question obligatoire ne doit être laissée vide.",
    ],
    "leading_question": [
        "Revoir la formulation de la question {code} : les enquêteurs tendent à suggérer la réponse.",
        "Ajouter une consigne enquêteur expliquant comment poser cette question de façon neutre.",
        "Prévoir un module de formation sur la lecture neutre des questions.",
    ],
    "wording_deviation": [
        "Les enquêteurs reformulent la question {code} au lieu de la lire : envisager de simplifier sa formulation.",
        "Vérifier que la question est adaptée à une passation téléphonique (longueur, vocabulaire).",
        "Ajouter une consigne de lecture exacte pour cette question.",
    ],
    "respondent_influence": [
        "Renforcer la formation à la neutralité des enquêteurs concernés (question {code}).",
        "Ajouter une consigne interdisant les commentaires personnels pendant la passation.",
    ],
    "inadequate_probing": [
        "Ajouter des consignes de relance standardisées pour la question ouverte {code}.",
        "Former les enquêteurs aux techniques de relance non directives.",
    ],
    "unprofessional_conduct": [
        "Prévoir un coaching du poste concerné : le ton employé pendant la passation n'est pas professionnel.",
    ],
    "timing_anomaly": [
        "Contrôler les entretiens du poste concerné : les durées de passation sont anormales.",
        "Comparer la durée cible du questionnaire à la durée réelle observée (questionnaire trop long ou passation expédiée).",
    ],
    "duplicate_verbatim": [
        "Déclencher un contrôle qualité renforcé : des verbatims identiques entre entretiens signalent une possible fabrication.",
        "Prévoir des rappels de contrôle auprès des répondants concernés avant validation des quotas.",
    ],
    "suspected_fabrication": [
        "Déclencher un contrôle qualité renforcé sur les postes concernés (entretiens potentiellement fabriqués).",
        "Réécouter les enregistrements et rappeler un échantillon de répondants avant validation.",
    ],
    "question_not_asked_but_answered": [
        "Une réponse est saisie sans que la question {code} ait été posée : contrôler la passation et le routage.",
    ],
    "transcript_missing": [
        "Vérifier l'export des enregistrements et transcriptions : sans transcription, aucune vérification sémantique n'est possible.",
    ],
}


def manager_recommendations(category: str, question_code: str | None = None) -> list[str]:
    """Recommandations pour la direction, paramétrées par la question concernée."""
    code = question_code or "concernée"
    return [t.format(code=code) for t in MANAGER_ADVICE.get(category, [])]


_CATEGORY_ADVICE = {
    "question_skipped": "Poser systématiquement toutes les questions prévues par le parcours du questionnaire.",
    "routing_violation": "Respecter strictement la logique de routage (questions filtres et sauts).",
    "answer_mismatch": "Enregistrer exactement la réponse donnée par le répondant, sans interprétation.",
    "wrong_recording": "Saisir les réponses avec plus de rigueur — relire avant validation.",
    "misinterpretation": "Reformuler la réponse au répondant pour valider la compréhension avant de saisir.",
    "leading_question": "Lire les questions exactement comme rédigées, sans suggérer de réponse.",
    "respondent_influence": "Rester neutre : ne pas commenter ni orienter les réponses du répondant.",
    "inadequate_probing": "Améliorer les techniques de relance sur les questions ouvertes.",
    "inconsistent_answers": "Vérifier la cohérence des réponses avant de clôturer l'entretien.",
    "timing_anomaly": "Respecter le rythme normal de passation — les entretiens expédiés sont signalés.",
    "duplicate_verbatim": "Chaque entretien doit être authentique : tout verbatim dupliqué est signalé comme fraude.",
    "suspected_fabrication": "Alerte intégrité : entretiens suspects détectés, un contrôle renforcé est appliqué.",
    "unprofessional_conduct": "Maintenir un ton professionnel et courtois pendant toute la passation.",
    "wording_deviation": "Éviter les paraphrases : lire le texte exact des questions.",
    "data_entry_error": "Vérifier la saisie des réponses avant validation.",
    "missing_mandatory": "Ne jamais laisser une question obligatoire sans réponse.",
}


def _refresh_recommendations(db: Session) -> None:
    """Recalcule les recommandations de chaque Post à partir des anomalies confirmées."""
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    for interviewer in db.query(models.Interviewer).all():
        rows = (
            db.query(models.Finding.category, models.Finding.severity)
            .join(models.Evaluation)
            .join(models.Interview)
            .filter(models.Interview.interviewer_id == interviewer.id)
            .all()
        )
        counts: dict[str, int] = {}
        for cat, sev in rows:
            weight = 3 if sev in (models.Severity.high, models.Severity.critical) else 1
            counts[cat] = counts.get(cat, 0) + weight
        top = sorted(counts.items(), key=lambda kv: -kv[1])[:5]
        recos = [
            _CATEGORY_ADVICE[cat]
            for cat, _ in top
            if cat in _CATEGORY_ADVICE and cat != "transcript_missing"
        ]
        if not recos:
            recos = ["Aucune anomalie récurrente : maintenir le niveau de qualité actuel."]
        interviewer.recommendations = recos
        interviewer.recommendations_at = now
    db.commit()
