"""Génération de rapports PDF et Excel (entretien, enquêteur CATI, global)."""
from __future__ import annotations

import io
from datetime import datetime
from typing import Any

from sqlalchemy.orm import Session

from .. import models
from .evaluation import manager_recommendations

BRAND = "#6366f1"

SEV_LABEL = {"low": "Mineure", "medium": "Moyenne", "high": "Grave", "critical": "Critique"}
VERDICT_LABEL = {"pass": "Conforme", "needs_review": "À contrôler", "fail": "Non conforme"}

CATEGORY_LABEL = {
    "question_skipped": "Question sautée",
    "question_not_asked_but_answered": "Réponse sans question posée",
    "wrong_recording": "Mauvais enregistrement",
    "answer_mismatch": "Réponse ≠ propos du répondant",
    "missing_mandatory": "Obligatoire manquante",
    "routing_violation": "Routage non respecté",
    "wording_deviation": "Question reformulée",
    "leading_question": "Question orientée",
    "respondent_influence": "Influence sur le répondant",
    "misinterpretation": "Mauvaise interprétation",
    "inconsistent_answers": "Réponses incohérentes",
    "data_entry_error": "Erreur de saisie",
    "timing_anomaly": "Durée anormale",
    "suspected_fabrication": "Suspicion de fabrication",
    "duplicate_verbatim": "Verbatim dupliqué",
    "unprofessional_conduct": "Conduite non professionnelle",
    "transcript_missing": "Transcription absente",
    "inadequate_probing": "Relance insuffisante",
}


def _latest_eval(interview: models.Interview) -> models.Evaluation | None:
    evals = [e for e in interview.evaluations if e.status == models.EvaluationStatus.completed]
    return max(evals, key=lambda e: e.id) if evals else None


def _pdf_doc(title: str, subtitle: str):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=1.8 * cm, bottomMargin=1.8 * cm)
    styles = getSampleStyleSheet()
    brand = ParagraphStyle("Brand", parent=styles["Title"], textColor=colors.HexColor(BRAND))
    story: list[Any] = [
        Paragraph("Immersion AI — Contrôle Qualité CATI", brand),
        Paragraph(title, styles["Heading2"]),
        Paragraph(subtitle, styles["Normal"]),
        Paragraph(f"Généré le {datetime.now().strftime('%d/%m/%Y à %H:%M')}", styles["Normal"]),
        Spacer(1, 0.5 * cm),
    ]
    return buffer, doc, styles, story


def _table(data: list[list], col_widths=None):
    from reportlab.lib import colors
    from reportlab.platypus import Table, TableStyle

    table = Table(data, colWidths=col_widths, repeatRows=1)
    table.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(BRAND)),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cbd5e1")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1f5f9")]),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ])
    )
    return table


def _para(text: str, styles, size: int = 8):
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.platypus import Paragraph

    style = ParagraphStyle("cell", parent=styles["Normal"], fontSize=size, leading=size + 2)
    return Paragraph((text or "—").replace("<", "&lt;"), style)


# --------------------------------------------------------------------------- #
# Rapport d'entretien
# --------------------------------------------------------------------------- #


def interview_pdf(interview: models.Interview) -> bytes:
    from reportlab.lib.units import cm
    from reportlab.platypus import Spacer

    evaluation = _latest_eval(interview)
    post = interview.interviewer.post_number if interview.interviewer else "?"
    buffer, doc, styles, story = _pdf_doc(
        f"Rapport d'entretien — Réponse #{interview.external_id}",
        f"Poste {post} · Session {interview.session_code or '—'}",
    )

    if evaluation:
        story.append(_table([
            ["Score qualité", "Verdict", "Risque fraude", "Anomalies"],
            [
                f"{evaluation.quality_score:.0f}/100",
                VERDICT_LABEL.get(evaluation.verdict or "", evaluation.verdict or "—"),
                f"{evaluation.fraud_risk:.0f}/100",
                str(len(evaluation.findings)),
            ],
        ]))
        story.append(Spacer(1, 0.4 * cm))
        cov = evaluation.coverage or {}
        n_grave = sum(
            1 for f in evaluation.findings
            if f.severity in (models.Severity.high, models.Severity.critical)
        )
        if "contradicted" in cov:
            answered = cov.get("answered_questions", 0)
            evaluable = cov.get("evaluable_questions", 0)
            story.append(_table([
                ["Anomalies graves", "Contradictions réponse/transcription", "Couverture transcription"],
                [
                    str(n_grave),
                    str(cov.get("contradicted", 0)),
                    f"{cov.get('coverage_pct', 0):.0f}% ({evaluable}/{answered} réponses évaluables)",
                ],
            ]))
            story.append(Spacer(1, 0.2 * cm))
            story.append(_para(
                "La transcription est partielle : seules les anomalies étayées par une "
                "preuve sont signalées. Une question absente de la transcription n'est "
                "ni validée ni pénalisée.",
                styles, 8,
            ))
            story.append(Spacer(1, 0.3 * cm))
        if evaluation.summary:
            story.append(_para(evaluation.summary, styles, 9))
            story.append(Spacer(1, 0.4 * cm))

        qtexts = {
            q.get("code"): q.get("text", "")
            for q in (interview.questionnaire.definition or {}).get("questions", [])
        }
        rows = [["Question", "Anomalie", "Gravité", "Enregistré", "Explication & recommandation enquêteur", "Preuve (transcription)"]]
        for f in evaluation.findings:
            qlabel = f.question_code or "Global"
            qtext = qtexts.get(f.question_code, "")
            explanation = f.explanation or ""
            if f.recommendation:
                explanation += f" — Recommandation enquêteur : {f.recommendation}"
            rows.append([
                _para(f"{qlabel}" + (f" — {qtext[:140]}" if qtext else ""), styles),
                _para(CATEGORY_LABEL.get(f.category, f.category), styles),
                _para(SEV_LABEL.get(f.severity.value, f.severity.value), styles),
                _para(f.recorded_value or "", styles),
                _para(explanation, styles),
                _para(f.evidence or "", styles),
            ])
        if len(rows) > 1:
            story.append(_table(rows, [3.2 * cm, 2.4 * cm, 1.5 * cm, 2.2 * cm, 4.2 * cm, 3.5 * cm]))

        # Recommandations pour la direction : quoi revoir dans le questionnaire.
        by_code: dict[str, list] = {}
        for f in evaluation.findings:
            if f.question_code:
                by_code.setdefault(f.question_code, []).append(f)
        if by_code:
            story.append(Spacer(1, 0.5 * cm))
            story.append(_para("Recommandations pour la direction", styles, 11))
            story.append(Spacer(1, 0.15 * cm))
            for code, fs in by_code.items():
                qtext = qtexts.get(code, "")
                story.append(_para(
                    f"Question {code}" + (f" — {qtext[:160]}" if qtext else "")
                    + f" ({len(fs)} anomalie(s))",
                    styles, 9,
                ))
                recos: list[str] = []
                for f in fs:
                    for r in manager_recommendations(f.category, code):
                        if r not in recos:
                            recos.append(r)
                for r in recos[:5]:
                    story.append(_para(f"• {r}", styles, 8))
                story.append(Spacer(1, 0.2 * cm))
    else:
        latest = max(interview.evaluations, key=lambda e: e.id) if interview.evaluations else None
        if latest is not None and latest.status == models.EvaluationStatus.failed:
            story.append(_para(
                "ANALYSE INCOMPLÈTE — aucun score n'a été produit. "
                + (latest.error or "L'analyse sémantique n'a pas pu être effectuée."),
                styles, 10,
            ))
        else:
            story.append(_para("Cet entretien n'a pas encore été évalué.", styles, 10))

    doc.build(story)
    return buffer.getvalue()


def interview_excel(interview: models.Interview) -> bytes:
    from openpyxl import Workbook

    evaluation = _latest_eval(interview)
    wb = Workbook()
    ws = wb.active
    ws.title = "Entretien"
    post = interview.interviewer.post_number if interview.interviewer else "?"
    ws.append(["Réponse", interview.external_id])
    ws.append(["Poste", post])
    ws.append(["Session Code", interview.session_code or ""])
    if evaluation:
        ws.append(["Score qualité", evaluation.quality_score])
        ws.append(["Verdict", VERDICT_LABEL.get(evaluation.verdict or "", "")])
        ws.append(["Risque fraude", evaluation.fraud_risk])
        cov = evaluation.coverage or {}
        if "contradicted" in cov:
            ws.append(["Contradictions réponse/transcription", cov.get("contradicted", 0)])
            ws.append([
                "Couverture transcription",
                f"{cov.get('coverage_pct', 0):.0f}% "
                f"({cov.get('evaluable_questions', 0)}/{cov.get('answered_questions', 0)} réponses évaluables)",
            ])
        qtexts = {
            q.get("code"): q.get("text", "")
            for q in (interview.questionnaire.definition or {}).get("questions", [])
        }
        ws.append([])
        ws.append([
            "Question", "Texte de la question", "Anomalie", "Gravité", "Confiance",
            "Enregistré", "Attendu", "Explication", "Preuve (transcription)",
            "Recommandation enquêteur", "Recommandations direction",
        ])
        for f in evaluation.findings:
            ws.append([
                f.question_code or "Global",
                qtexts.get(f.question_code, ""),
                CATEGORY_LABEL.get(f.category, f.category),
                SEV_LABEL.get(f.severity.value, f.severity.value),
                f.confidence,
                f.recorded_value or "",
                f.expected_value or "",
                f.explanation,
                f.evidence or "",
                f.recommendation or "",
                " · ".join(manager_recommendations(f.category, f.question_code)[:3]),
            ])
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


# --------------------------------------------------------------------------- #
# Rapport enquêteur (Post)
# --------------------------------------------------------------------------- #


def _interviewer_stats(db: Session, interviewer: models.Interviewer) -> dict:
    interviews = interviewer.interviews
    evals = [
        e
        for i in interviews
        for e in i.evaluations
        if e.status == models.EvaluationStatus.completed
    ]
    findings = [f for e in evals for f in e.findings]
    scores = [e.quality_score for e in evals if e.quality_score is not None]
    by_cat: dict[str, int] = {}
    for f in findings:
        by_cat[f.category] = by_cat.get(f.category, 0) + 1
    return {
        "interviews": len(interviews),
        "evaluated": len(evals),
        "avg_score": sum(scores) / len(scores) if scores else None,
        "critical": sum(
            1 for f in findings if f.severity in (models.Severity.high, models.Severity.critical)
        ),
        "minor": sum(
            1 for f in findings if f.severity in (models.Severity.low, models.Severity.medium)
        ),
        "by_category": sorted(by_cat.items(), key=lambda kv: -kv[1]),
        "fail": sum(1 for e in evals if e.verdict == "fail"),
    }


def interviewer_pdf(db: Session, interviewer: models.Interviewer) -> bytes:
    from reportlab.lib.units import cm
    from reportlab.platypus import Spacer

    stats = _interviewer_stats(db, interviewer)
    buffer, doc, styles, story = _pdf_doc(
        f"Rapport enquêteur CATI — Poste {interviewer.post_number}",
        f"{stats['interviews']} entretien(s), {stats['evaluated']} évalué(s)",
    )
    story.append(_table([
        ["Entretiens", "Score moyen", "Erreurs graves", "Erreurs mineures", "Non conformes"],
        [
            str(stats["interviews"]),
            f"{stats['avg_score']:.0f}/100" if stats["avg_score"] is not None else "—",
            str(stats["critical"]),
            str(stats["minor"]),
            str(stats["fail"]),
        ],
    ]))
    story.append(Spacer(1, 0.4 * cm))

    rows = [["Type d'anomalie", "Occurrences"]]
    for cat, count in stats["by_category"][:12]:
        rows.append([_para(CATEGORY_LABEL.get(cat, cat), styles), str(count)])
    if len(rows) > 1:
        story.append(_table(rows, [10 * cm, 3 * cm]))
        story.append(Spacer(1, 0.4 * cm))

    if interviewer.recommendations:
        story.append(_para("Recommandations :", styles, 10))
        for reco in interviewer.recommendations:
            story.append(_para(f"• {reco}", styles, 9))

    doc.build(story)
    return buffer.getvalue()


def interviewer_excel(db: Session, interviewer: models.Interviewer) -> bytes:
    from openpyxl import Workbook

    stats = _interviewer_stats(db, interviewer)
    wb = Workbook()
    ws = wb.active
    ws.title = f"Poste {interviewer.post_number}"
    ws.append(["Poste", interviewer.post_number])
    ws.append(["Entretiens", stats["interviews"]])
    ws.append(["Évalués", stats["evaluated"]])
    ws.append([
        "Score moyen",
        round(stats["avg_score"], 1) if stats["avg_score"] is not None else "",
    ])
    ws.append(["Erreurs graves", stats["critical"]])
    ws.append(["Erreurs mineures", stats["minor"]])
    ws.append([])
    ws.append(["Type d'anomalie", "Occurrences"])
    for cat, count in stats["by_category"]:
        ws.append([CATEGORY_LABEL.get(cat, cat), count])
    ws.append([])
    ws.append(["Recommandations"])
    for reco in interviewer.recommendations or []:
        ws.append([reco])
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


# --------------------------------------------------------------------------- #
# Rapport global (direction)
# --------------------------------------------------------------------------- #


def global_pdf(db: Session) -> bytes:
    from reportlab.lib.units import cm
    from reportlab.platypus import Spacer

    interviewers = db.query(models.Interviewer).all()
    buffer, doc, styles, story = _pdf_doc(
        "Rapport de direction — classement des enquêteurs CATI",
        f"{len(interviewers)} poste(s) détecté(s)",
    )
    rows = [["Poste", "Entretiens", "Score moyen", "Graves", "Mineures", "Non conformes"]]
    ranked = []
    for it in interviewers:
        ranked.append((it.post_number, _interviewer_stats(db, it)))
    ranked.sort(key=lambda r: -(r[1]["avg_score"] or 0))
    for post, stats in ranked:
        rows.append([
            f"Poste {post}",
            str(stats["interviews"]),
            f"{stats['avg_score']:.0f}" if stats["avg_score"] is not None else "—",
            str(stats["critical"]),
            str(stats["minor"]),
            str(stats["fail"]),
        ])
    story.append(_table(rows))
    story.append(Spacer(1, 0.4 * cm))

    by_question: dict[str, dict] = {}
    for f in db.query(models.Finding).all():
        if f.question_code:
            d = by_question.setdefault(f.question_code, {"count": 0, "cats": {}})
            d["count"] += 1
            d["cats"][f.category] = d["cats"].get(f.category, 0) + 1
    top = sorted(by_question.items(), key=lambda kv: -kv[1]["count"])[:10]
    if top:
        story.append(_para("Questions les plus problématiques :", styles, 10))
        rows = [["Question", "Anomalies", "Problème dominant"]]
        for code, d in top:
            top_cat = max(d["cats"], key=d["cats"].get)
            rows.append([
                _para(code, styles), str(d["count"]),
                _para(CATEGORY_LABEL.get(top_cat, top_cat), styles),
            ])
        story.append(_table(rows, [6 * cm, 2.5 * cm, 6 * cm]))
        story.append(Spacer(1, 0.5 * cm))

        story.append(_para("Recommandations pour la direction :", styles, 10))
        for code, d in top[:6]:
            top_cat = max(d["cats"], key=d["cats"].get)
            story.append(_para(
                f"Question {code} — {d['count']} anomalie(s), problème dominant : "
                f"{CATEGORY_LABEL.get(top_cat, top_cat)}",
                styles, 9,
            ))
            recos: list[str] = []
            for cat, _n in sorted(d["cats"].items(), key=lambda kv: -kv[1]):
                for r in manager_recommendations(cat, code):
                    if r not in recos:
                        recos.append(r)
            for r in recos[:4]:
                story.append(_para(f"• {r}", styles, 8))
            story.append(Spacer(1, 0.15 * cm))

    doc.build(story)
    return buffer.getvalue()


def global_excel(db: Session) -> bytes:
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "Classement"
    ws.append([
        "Poste", "Entretiens", "Évalués", "Score moyen",
        "Erreurs graves", "Erreurs mineures", "Non conformes",
    ])
    for it in db.query(models.Interviewer).all():
        stats = _interviewer_stats(db, it)
        ws.append([
            it.post_number,
            stats["interviews"],
            stats["evaluated"],
            round(stats["avg_score"], 1) if stats["avg_score"] is not None else "",
            stats["critical"],
            stats["minor"],
            stats["fail"],
        ])
    ws2 = wb.create_sheet("Anomalies par question")
    ws2.append(["Question", "Anomalies", "Problème dominant", "Recommandations direction"])
    by_question: dict[str, dict] = {}
    for f in db.query(models.Finding).all():
        if f.question_code:
            d = by_question.setdefault(f.question_code, {"count": 0, "cats": {}})
            d["count"] += 1
            d["cats"][f.category] = d["cats"].get(f.category, 0) + 1
    for code, d in sorted(by_question.items(), key=lambda kv: -kv[1]["count"]):
        top_cat = max(d["cats"], key=d["cats"].get)
        recos: list[str] = []
        for cat, _n in sorted(d["cats"].items(), key=lambda kv: -kv[1]):
            for r in manager_recommendations(cat, code):
                if r not in recos:
                    recos.append(r)
        ws2.append([
            code, d["count"], CATEGORY_LABEL.get(top_cat, top_cat),
            " · ".join(recos[:4]),
        ])
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()
