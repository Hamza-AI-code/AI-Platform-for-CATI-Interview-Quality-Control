"""Analyse des fichiers .LSS (LimeSurvey Survey Structure).

Le .LSS est un document XML contenant une section par table LimeSurvey.
Depuis DBVersion >= 400 les textes localisés vivent dans des sections
séparées (`question_l10ns`, `answer_l10ns`, `group_l10ns`) : on les joint
aux lignes de structure. Les exports plus anciens (texte en ligne) sont
également pris en charge.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from typing import Any

# Codes de type LimeSurvey -> type normalisé.
TYPE_MAP = {
    "L": "single_choice", "!": "single_choice", "O": "single_choice",
    "Y": "yes_no",
    "M": "multi_choice", "P": "multi_choice",
    "T": "open_text", "U": "open_text", "S": "open_text", "Q": "open_text",
    "N": "numeric", "K": "numeric",
    "F": "matrix", "A": "matrix", "B": "matrix", "E": "matrix",
    "C": "matrix", "H": "matrix", "1": "matrix", ";": "matrix", ":": "matrix",
    "D": "date",
    "R": "ranking",
    "X": "display_only",
    "*": "computed",
    "G": "single_choice", "5": "single_choice", "I": "single_choice",
}

# Options implicites des questions Oui/Non (type Y).
YES_NO_OPTIONS = [
    {"code": "Y", "label": "Oui"},
    {"code": "N", "label": "Non"},
]


def _clean_html(html: str | None) -> str:
    text = re.sub(r"<[^>]+>", " ", html or "")
    text = text.replace("&nbsp;", " ").replace("&amp;", "&")
    text = text.replace("&lt;", "<").replace("&gt;", ">").replace("&#39;", "'")
    return re.sub(r"[ \t]+", " ", text).strip()


def _rows(root: ET.Element, section: str) -> list[dict[str, str]]:
    sec = root.find(section)
    if sec is None:
        return []
    return [
        {child.tag: (child.text or "") for child in row}
        for row in sec.findall("rows/row")
    ]


def parse_lss(content: bytes) -> dict[str, Any]:
    """Analyse un .LSS et retourne la structure normalisée du questionnaire."""
    root = ET.fromstring(content)
    if (root.findtext("LimeSurveyDocType") or "").strip() != "Survey":
        raise ValueError("Ce fichier n'est pas un export de questionnaire LimeSurvey (.lss).")

    languages = [
        (lang.text or "").strip()
        for lang in root.findall("languages/language")
    ]
    base_lang = languages[0] if languages else "fr"

    # --- Textes localisés (DBVersion >= 400) --------------------------------
    q_l10ns: dict[str, str] = {}
    for row in _rows(root, "question_l10ns"):
        if not languages or row.get("language", base_lang) == base_lang or row["qid"] not in q_l10ns:
            q_l10ns[row["qid"]] = _clean_html(row.get("question", ""))
    a_l10ns: dict[str, str] = {}
    for row in _rows(root, "answer_l10ns"):
        if row["aid"] not in a_l10ns:
            a_l10ns[row["aid"]] = _clean_html(row.get("answer", ""))
    g_l10ns: dict[str, str] = {}
    for row in _rows(root, "group_l10ns"):
        if row["gid"] not in g_l10ns:
            g_l10ns[row["gid"]] = _clean_html(row.get("group_name", ""))

    # --- Groupes -------------------------------------------------------------
    groups = []
    for row in sorted(_rows(root, "groups"), key=lambda r: int(r.get("group_order", "0") or 0)):
        gid = row["gid"]
        groups.append({
            "gid": int(gid),
            "title": g_l10ns.get(gid) or _clean_html(row.get("group_name", "")) or f"Groupe {gid}",
            "order": int(row.get("group_order", "0") or 0),
        })

    # --- Réponses (options) --------------------------------------------------
    answers_by_qid: dict[str, list[dict[str, str]]] = {}
    for row in _rows(root, "answers"):
        label = a_l10ns.get(row.get("aid", "")) or _clean_html(row.get("answer", ""))
        answers_by_qid.setdefault(row["qid"], []).append({
            "code": row.get("code", ""),
            "label": label,
            "order": int(row.get("sortorder", "0") or 0),
        })
    for opts in answers_by_qid.values():
        opts.sort(key=lambda o: o["order"])

    # --- Questions & sous-questions ------------------------------------------
    q_rows = _rows(root, "questions")
    sub_rows = _rows(root, "subquestions")
    # Certains exports mettent les sous-questions dans `questions` avec parent_qid != 0.
    all_q = q_rows + sub_rows
    parents = [r for r in all_q if r.get("parent_qid", "0") in ("0", "", None)]
    subs_by_parent: dict[str, list[dict[str, str]]] = {}
    for r in all_q:
        pid = r.get("parent_qid", "0")
        if pid and pid not in ("0", ""):
            subs_by_parent.setdefault(pid, []).append(r)

    questions = []
    for row in sorted(
        parents,
        key=lambda r: (int(r.get("gid", "0") or 0), int(r.get("question_order", "0") or 0)),
    ):
        qid = row["qid"]
        lss_type = row.get("type", "T")
        norm_type = TYPE_MAP.get(lss_type, "open_text")
        options = answers_by_qid.get(qid, [])
        if norm_type == "yes_no" and not options:
            options = [dict(o, order=i) for i, o in enumerate(YES_NO_OPTIONS)]
        subquestions = [
            {
                "code": s.get("title", ""),
                "label": q_l10ns.get(s["qid"]) or _clean_html(s.get("question", "")),
                "order": int(s.get("question_order", "0") or 0),
            }
            for s in sorted(
                subs_by_parent.get(qid, []),
                key=lambda s: int(s.get("question_order", "0") or 0),
            )
        ]
        relevance = (row.get("relevance") or "1").strip()
        questions.append({
            "qid": int(qid),
            "code": row.get("title", ""),
            "gid": int(row.get("gid", "0") or 0),
            "order": int(row.get("question_order", "0") or 0),
            "lss_type": lss_type,
            "type": norm_type,
            "mandatory": (row.get("mandatory", "N") or "N").upper() == "Y",
            "text": q_l10ns.get(qid) or _clean_html(row.get("question", "")),
            "options": options,
            "subquestions": subquestions,
            "relevance": relevance if relevance != "1" else None,
        })

    # --- Métadonnées du questionnaire ----------------------------------------
    surveys = _rows(root, "surveys")
    survey_id = surveys[0].get("sid") if surveys else None
    title = ""
    for row in _rows(root, "surveys_languagesettings"):
        title = _clean_html(row.get("surveyls_title", ""))
        if title:
            break

    return {
        "survey_id": survey_id,
        "title": title or "Questionnaire sans titre",
        "language": base_lang,
        "languages": languages,
        "groups": groups,
        "questions": questions,
    }


# --------------------------------------------------------------------------- #
# Évaluation des équations de pertinence (routage / skip logic)
# --------------------------------------------------------------------------- #
# Grammaire couverte : identifiants CODE.NAOK / CODE_SQxxx.NAOK / SGQA.NAOK,
# littéraux "..." / '...' / nombres, opérateurs ==, !=, >=, <=, >, <,
# and/or/not (&& || !), parenthèses, is_empty(x) / !is_empty(x).
_TOKEN_RE = re.compile(
    r"\s*(?:(?P<lparen>\()|(?P<rparen>\))|(?P<op>==|!=|>=|<=|>|<)"
    r"|(?P<and>&&|\band\b)|(?P<or>\|\||\bor\b)|(?P<not>!(?!=)|\bnot\b)"
    r"|(?P<func>is_empty)|(?P<comma>,)"
    r"|(?P<str>\"[^\"]*\"|'[^']*')|(?P<num>-?\d+(?:\.\d+)?)"
    r"|(?P<ident>[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z]+)?))",
    re.IGNORECASE,
)


class RelevanceError(Exception):
    """Équation de pertinence non prise en charge par l'évaluateur."""


def _tokenize(expr: str) -> list[tuple[str, str]]:
    tokens, pos = [], 0
    while pos < len(expr):
        m = _TOKEN_RE.match(expr, pos)
        if not m or m.end() == pos:
            if expr[pos:].strip():
                raise RelevanceError(f"Token inconnu près de : {expr[pos:pos+20]!r}")
            break
        pos = m.end()
        for kind in ("lparen", "rparen", "op", "and", "or", "not", "func", "comma", "str", "num", "ident"):
            val = m.group(kind)
            if val is not None:
                tokens.append((kind, val))
                break
    return tokens


class _Parser:
    """Descente récursive : or -> and -> not -> comparaison -> atome."""

    def __init__(self, tokens: list[tuple[str, str]], resolve):
        self.tokens = tokens
        self.pos = 0
        self.resolve = resolve  # code -> valeur enregistrée (str|None)

    def _peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else (None, None)

    def _next(self):
        tok = self._peek()
        self.pos += 1
        return tok

    def parse(self) -> bool:
        result = self._or()
        if self.pos != len(self.tokens):
            raise RelevanceError("Expression incomplète")
        return result

    def _or(self) -> bool:
        left = self._and()
        while self._peek()[0] == "or":
            self._next()
            right = self._and()
            left = left or right
        return left

    def _and(self) -> bool:
        left = self._not()
        while self._peek()[0] == "and":
            self._next()
            right = self._not()
            left = left and right
        return left

    def _not(self) -> bool:
        if self._peek()[0] == "not":
            self._next()
            return not self._not()
        return self._comparison()

    def _value(self):
        kind, val = self._peek()
        if kind == "str":
            self._next()
            return val[1:-1]
        if kind == "num":
            self._next()
            return float(val)
        if kind == "func":  # is_empty(X)
            self._next()
            if self._next()[0] != "lparen":
                raise RelevanceError("is_empty sans parenthèse")
            inner = self._value()
            if self._next()[0] != "rparen":
                raise RelevanceError("is_empty non fermé")
            return inner in (None, "", "N/A")
        if kind == "ident":
            self._next()
            name = val.split(".")[0]  # retire .NAOK / .shown etc.
            return self.resolve(name)
        if kind == "lparen":
            self._next()
            result = self._or()
            if self._next()[0] != "rparen":
                raise RelevanceError("Parenthèse non fermée")
            return result
        raise RelevanceError(f"Valeur inattendue : {kind}")

    def _comparison(self) -> bool:
        left = self._value()
        kind, op = self._peek()
        if kind != "op":
            # Valeur seule : véracité (booléen déjà évalué, ou non-vide).
            if isinstance(left, bool):
                return left
            return left not in (None, "", "N/A", 0)
        self._next()
        right = self._value()

        def as_num(v):
            try:
                return float(v)
            except (TypeError, ValueError):
                return None

        ln, rn = as_num(left), as_num(right)
        if ln is not None and rn is not None:
            left_c, right_c = ln, rn
        else:
            left_c, right_c = ("" if left is None else str(left)), ("" if right is None else str(right))
        if op == "==":
            return left_c == right_c
        if op == "!=":
            return left_c != right_c
        if ln is None or rn is None:
            # Comparaison d'ordre sur non-numériques : lexicographique.
            left_c, right_c = str(left_c), str(right_c)
        if op == ">":
            return left_c > right_c
        if op == "<":
            return left_c < right_c
        if op == ">=":
            return left_c >= right_c
        return left_c <= right_c


def evaluate_relevance(expr: str | None, resolve) -> bool | None:
    """Évalue une équation de pertinence.

    `resolve(code)` retourne la valeur enregistrée pour un code de question
    (code d'option de préférence, sinon libellé). Retourne None si
    l'expression n'est pas prise en charge (le contrôle passe alors en mode
    « assisté LLM »).
    """
    if not expr or expr.strip() == "1":
        return True
    try:
        return bool(_Parser(_tokenize(expr), resolve).parse())
    except (RelevanceError, Exception):
        return None
