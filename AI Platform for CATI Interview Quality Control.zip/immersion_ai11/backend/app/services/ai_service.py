"""Service IA réutilisable — Ollama (LLM 100 % LOCAL, aucun cloud).

L'application ne dépend d'AUCUN fournisseur d'IA en ligne : ni clé API, ni
crédits, ni facturation, ni connexion internet. Toute l'analyse sémantique
passe par l'API REST d'Ollama (http://localhost:11434 par défaut).

Responsabilités :
    - configuration lue depuis backend/.env (`OLLAMA_MODEL`,
      `OLLAMA_BASE_URL`, `OLLAMA_NUM_CTX`) : changer de modèle = modifier
      UNE ligne de .env, aucun changement de code ;
    - détection automatique : si `OLLAMA_MODEL` est vide, le meilleur modèle
      INSTALLÉ est choisi selon la priorité deepseek-r1 > qwen3 > llama3.1 >
      mistral (puis n'importe quel modèle disponible) ;
    - messages d'erreur CLAIRS, jamais de faux résultats :
        * Ollama arrêté  -> « Ollama n'est pas lancé. Démarrez Ollama … » ;
        * modèle absent  -> « Le modèle configuré n'est pas installé »
          + la commande exacte `ollama pull <modèle>` ;
    - sorties STRUCTURÉES : `generate_json` transmet le schéma JSON via le
      paramètre `format` d'Ollama et nettoie les balises de raisonnement
      (<think>…</think> de deepseek-r1/qwen3) avant parsing ;
    - nouvelles tentatives avec backoff sur les erreurs transitoires
      (timeouts, 5xx) ; récupération des réponses tronquées.

Le moteur d'évaluation (`evaluation.py`) consomme ce service ; il ne contient
aucune logique Ollama directe.
"""
from __future__ import annotations

import json
import logging
import random
import re
import threading
import time
from typing import Any

import httpx

from ..config import settings

logger = logging.getLogger("immerssion.ai")

MAX_RETRIES = 2          # tentatives supplémentaires après le 1er essai
BACKOFF_BASE_SECONDS = 2.0
# Les modèles locaux « reasoning » (deepseek-r1, qwen3) peuvent être lents,
# surtout sur CPU : timeout généreux.
DEFAULT_TIMEOUT = 600.0

# Priorité de sélection automatique quand OLLAMA_MODEL n'est pas renseigné.
MODEL_PRIORITY = ("deepseek-r1", "qwen3", "llama3.1", "mistral")


class AIError(RuntimeError):
    """Échec d'un appel IA après épuisement des tentatives."""


class AIUnavailable(AIError):
    """Ollama n'est pas lancé (connexion impossible à OLLAMA_BASE_URL)."""


class AIModelUnavailable(AIError):
    """Le modèle configuré n'est pas installé dans Ollama."""


def is_configured() -> bool:
    """True : l'IA locale est toujours « configurée » (aucune clé requise).

    La disponibilité réelle (service lancé, modèle installé) est vérifiée par
    `healthcheck()` et à chaque appel — avec des erreurs claires, jamais de
    faux résultats.
    """
    return bool(settings.ollama_base_url)


def _unavailable_message() -> str:
    return (
        "Ollama n'est pas lancé. Démarrez Ollama (commande « ollama serve », "
        "ou l'application Ollama) avant de lancer l'analyse — "
        f"URL attendue : {settings.ollama_base_url}"
    )


def _model_missing_message(model: str) -> str:
    return (
        f"Le modèle configuré « {model} » n'est pas installé dans Ollama. "
        f"Installez-le avec :  ollama pull {model}  — puis relancez l'analyse. "
        "(Modèles installés visibles avec « ollama list ».)"
    )


# Client HTTP partagé (pool de connexions) — créé paresseusement.
_client_lock = threading.Lock()
_client: httpx.Client | None = None


def _http_client() -> httpx.Client:
    global _client
    if _client is None:
        with _client_lock:
            if _client is None:
                _client = httpx.Client(timeout=DEFAULT_TIMEOUT)
    return _client


# --------------------------------------------------------------------------- #
# Disjoncteur : quand Ollama est constaté ARRÊTÉ, les entretiens suivants du
# lot échouent immédiatement (message clair) au lieu d'attendre un timeout
# chacun. TTL court : relancer Ollama suffit à réarmer.
# --------------------------------------------------------------------------- #
_block_lock = threading.Lock()
_blocked_until: float = 0.0
_blocked_reason: str | None = None
_BLOCK_TTL_SECONDS = 30.0


def quota_blocked() -> str | None:
    """Nom historique (compatibilité moteur) : indisponibilité durable de l'IA
    locale — Ollama arrêté — constatée il y a moins de _BLOCK_TTL_SECONDS."""
    with _block_lock:
        if _blocked_reason and time.monotonic() < _blocked_until:
            return _blocked_reason
        return None


def _block(reason: str) -> None:
    global _blocked_until, _blocked_reason
    with _block_lock:
        _blocked_reason = reason
        _blocked_until = time.monotonic() + _BLOCK_TTL_SECONDS


def _unblock() -> None:
    global _blocked_until, _blocked_reason
    with _block_lock:
        _blocked_reason = None
        _blocked_until = 0.0


# --------------------------------------------------------------------------- #
# Modèle actif : OLLAMA_MODEL de .env, ou détection automatique du meilleur
# modèle installé (deepseek-r1 > qwen3 > llama3.1 > mistral > premier trouvé).
# --------------------------------------------------------------------------- #
_model_lock = threading.Lock()
_detected_model: str | None = None


def _installed_models() -> list[str]:
    """Noms des modèles installés (GET /api/tags). Lève AIUnavailable si arrêté."""
    try:
        resp = _http_client().get(
            f"{settings.ollama_base_url.rstrip('/')}/api/tags", timeout=10.0
        )
    except (httpx.TimeoutException, httpx.TransportError) as exc:
        reason = _unavailable_message()
        _block(reason)
        raise AIUnavailable(reason) from exc
    if resp.status_code != 200:
        raise AIError(f"Ollama /api/tags -> HTTP {resp.status_code} : {resp.text[:200]}")
    _unblock()
    return [m.get("name", "") for m in (resp.json().get("models") or [])]


def _pick_best(installed: list[str]) -> str | None:
    for family in MODEL_PRIORITY:
        for name in installed:
            if name.lower().startswith(family):
                return name
    return installed[0] if installed else None


def _resolve_model() -> str:
    """Modèle effectif, avec détection automatique si OLLAMA_MODEL est vide."""
    global _detected_model
    if settings.ollama_model:
        return settings.ollama_model
    with _model_lock:
        if _detected_model:
            return _detected_model
    installed = _installed_models()
    best = _pick_best(installed)
    if not best:
        raise AIModelUnavailable(
            "Aucun modèle n'est installé dans Ollama. Installez-en un, par "
            "exemple :  ollama pull qwen3:8b  (ou deepseek-r1, llama3.1, mistral)."
        )
    with _model_lock:
        _detected_model = best
    logger.info(
        "OLLAMA_MODEL non renseigné : sélection automatique du meilleur modèle "
        "installé -> %s (priorité : %s).", best, " > ".join(MODEL_PRIORITY),
    )
    return best


def active_model() -> str:
    """Le modèle utilisé : OLLAMA_MODEL, sinon le meilleur modèle détecté."""
    if settings.ollama_model:
        return settings.ollama_model
    with _model_lock:
        if _detected_model:
            return _detected_model
    try:
        return _resolve_model()
    except AIError:
        return "(auto — détecté au premier appel)"


_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)


def _strip_reasoning(text: str) -> str:
    """Retire les balises de raisonnement (<think>…</think>) et les clôtures
    Markdown ```json … ``` que les modèles locaux ajoutent parfois."""
    t = _THINK_RE.sub("", text)
    # Balise <think> ouverte mais jamais fermée (réponse coupée en plein
    # raisonnement) : rien d'exploitable après l'ouverture.
    t = re.sub(r"<think>.*$", "", t, flags=re.DOTALL | re.IGNORECASE)
    t = t.strip()
    m = re.match(r"^```(?:json)?\s*(.*?)\s*```$", t, re.DOTALL)
    return m.group(1) if m else t


def _salvage_truncated_json(text: str) -> dict | None:
    """Récupère le plus grand préfixe JSON exploitable d'une sortie tronquée."""
    positions = [i for i, ch in enumerate(text) if ch == "}"]
    for pos in reversed(positions[-80:]):
        prefix = text[: pos + 1]
        stack: list[str] = []
        in_str = escaped = False
        for ch in prefix:
            if in_str:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
            elif ch in "{[":
                stack.append("}" if ch == "{" else "]")
            elif ch in "}]" and stack:
                stack.pop()
        if in_str:
            continue
        try:
            out = json.loads(prefix + "".join(reversed(stack)))
        except json.JSONDecodeError:
            continue
        if isinstance(out, dict):
            return out
    return None


def generate_json(
    prompt: str,
    *,
    system: str | None = None,
    schema: dict | None = None,
    model: str | None = None,
    temperature: float = 0.0,
    max_output_tokens: int = 8192,
    timeout: float = DEFAULT_TIMEOUT,
) -> dict:
    """Appelle le modèle Ollama configuré et retourne un objet JSON.

    `schema` (JSON Schema) est transmis via le paramètre `format` d'Ollama :
    la génération est contrainte au schéma PAR LE SERVEUR LOCAL. Les balises
    de raisonnement des modèles « thinking » sont nettoyées avant parsing.
    """
    blocked = quota_blocked()
    if blocked:
        raise AIUnavailable(blocked)
    model_name = model or _resolve_model()
    messages = []
    if system:
        # Instruction système STATIQUE d'un appel à l'autre : Ollama garde le
        # modèle et le préfixe de prompt en mémoire (keep_alive), les appels
        # suivants du lot sont plus rapides.
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    payload: dict[str, Any] = {
        "model": model_name,
        "messages": messages,
        "stream": False,
        "format": schema if schema is not None else "json",
        "options": {
            "temperature": temperature,
            "num_predict": max_output_tokens,
            # Fenêtre de contexte : un entretien complet (transcription +
            # questions + réponses) doit tenir en ENTRÉE.
            "num_ctx": settings.ollama_num_ctx,
        },
    }
    url = f"{settings.ollama_base_url.rstrip('/')}/api/chat"
    last_error: Exception | None = None
    data: dict | None = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            resp = _http_client().post(url, json=payload, timeout=timeout)
        except httpx.ConnectError as exc:
            reason = _unavailable_message()
            _block(reason)
            raise AIUnavailable(reason) from exc
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            last_error = exc
            if attempt < MAX_RETRIES:
                delay = BACKOFF_BASE_SECONDS * (2 ** attempt) + random.uniform(0, 1)
                logger.warning(
                    "Ollama -> erreur réseau (%s), nouvelle tentative dans %.1fs (%d/%d)",
                    exc.__class__.__name__, delay, attempt + 1, MAX_RETRIES,
                )
                time.sleep(delay)
                continue
            raise AIError(
                f"Ollama injoignable après {MAX_RETRIES + 1} tentatives : {exc}"
            ) from exc
        if resp.status_code == 200:
            _unblock()
            data = resp.json()
            break
        body = resp.text[:300]
        if resp.status_code == 404 or "not found" in body.lower():
            raise AIModelUnavailable(_model_missing_message(model_name))
        if resp.status_code >= 500 and attempt < MAX_RETRIES:
            delay = BACKOFF_BASE_SECONDS * (2 ** attempt) + random.uniform(0, 1)
            logger.warning(
                "Ollama -> HTTP %s, nouvelle tentative dans %.1fs (%d/%d) : %s",
                resp.status_code, delay, attempt + 1, MAX_RETRIES, body,
            )
            time.sleep(delay)
            continue
        raise AIError(f"Ollama /api/chat -> HTTP {resp.status_code} : {body}")
    if data is None:
        raise AIError(f"Ollama injoignable : {last_error}")

    text = ((data.get("message") or {}).get("content") or "").strip()
    done_reason = str(data.get("done_reason") or "?")
    text = _strip_reasoning(text)
    if not text:
        raise AIError(
            f"Réponse Ollama vide (done_reason={done_reason}) — le modèle a "
            "peut-être épuisé num_predict en raisonnement interne : relancez, "
            "augmentez max_output_tokens ou choisissez un modèle non-reasoning."
        )
    try:
        out = json.loads(text)
    except json.JSONDecodeError as exc:
        if done_reason == "length":
            out = _salvage_truncated_json(text)
            if out is not None:
                logger.warning(
                    "Modèle %s : réponse tronquée (done_reason=length, %d caractères) "
                    "— %d vérification(s) récupérée(s) du préfixe JSON valide.",
                    model_name, len(text), len(out.get("verifications") or []),
                )
                out["_ai_truncated"] = True
            else:
                raise AIError(
                    f"Réponse tronquée (done_reason=length après {len(text)} "
                    "caractères) et irrécupérable : augmentez max_output_tokens "
                    "ou réduisez la taille du lot."
                ) from exc
        else:
            m = re.search(r"\{.*\}", text, re.DOTALL)
            try:
                out = json.loads(m.group(0)) if m else None
            except json.JSONDecodeError:
                out = None
            if out is None:
                raise AIError(
                    f"Sortie non-JSON du modèle {model_name} "
                    f"(done_reason={done_reason}) : {text[:300]}"
                ) from exc
    if isinstance(out, dict):
        out["_ai_model"] = data.get("model") or model_name
    return out


def healthcheck() -> tuple[bool, str]:
    """Vérifie qu'Ollama tourne ET que le modèle configuré est installé.

    N'utilise que /api/tags — aucune génération, instantané, 100 % hors ligne.
    """
    try:
        installed = _installed_models()
    except AIError as exc:
        return False, str(exc)
    if settings.ollama_model:
        wanted = settings.ollama_model
        # « qwen3:8b » exact, ou famille « qwen3 » installée sous un autre tag.
        if not any(
            name == wanted or name.split(":")[0] == wanted for name in installed
        ):
            return False, _model_missing_message(wanted)
        return True, f"Ollama actif, modèle {wanted} installé."
    try:
        best = _resolve_model()
    except AIError as exc:
        return False, str(exc)
    return True, (
        f"Ollama actif — OLLAMA_MODEL non renseigné, sélection automatique : "
        f"{best} (priorité {' > '.join(MODEL_PRIORITY)})."
    )
