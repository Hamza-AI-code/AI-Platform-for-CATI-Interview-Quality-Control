"""Import des fichiers Excel : entretiens (réponses) et transcriptions.

Fichier « entretiens » : export LimeSurvey, une ligne = un entretien.
    - Les en-têtes peuvent être des codes de question, des identifiants SGQA
      ou le texte complet de la question (cas réel) — on mappe dans cet ordre.
    - Les valeurs sont des libellés d'options (« Satisfait ») ou des codes ;
      « N/A » signifie que la question n'a pas été affichée par le routage.
    - Le numéro de poste (« Num Poste ») identifie l'enquêteur CATI : les
      enquêteurs sont créés automatiquement, jamais saisis à la main.

Fichier « transcriptions » : colonnes SessionCode | Original Name | Transcript.
    - Chaque ligne est la transcription texte d'une question enregistrée.
    - La liaison se fait par Session Code (colonne « session code » du fichier
      entretiens).
"""
from __future__ import annotations

import io
import re
import unicodedata
from datetime import datetime
from typing import Any

from openpyxl import load_workbook
from sqlalchemy.orm import Session

from .. import models

# ---------------------------------------------------------------------------
# Aides de normalisation
# ---------------------------------------------------------------------------


def _norm(text: Any) -> str:
    """Normalise un texte pour la comparaison (accents, espaces, casse)."""
    s = str(text or "")
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"\s+", " ", s).strip().lower()
    return s


def _norm_key(text: Any, length: int = 80) -> str:
    """Clé de comparaison agressive : alphanumériques uniquement."""
    return re.sub(r"[^a-z0-9؀-ۿ]+", "", _norm(text))[:length]


# Colonnes techniques à ignorer silencieusement (chronométrage LimeSurvey…).
_IGNORE_RE = re.compile(
    r"duree pour (la question|le groupe)|question time|group time|total time", re.I
)


_META_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("external_id", re.compile(r"^id de la reponse|^response id|^id$", re.I)),
    ("submitted_at", re.compile(r"date de soumission|submitdate", re.I)),
    ("started_at", re.compile(r"date de lancement|startdate", re.I)),
    ("last_action_at", re.compile(r"date de la derniere action|datestamp", re.I)),
    ("last_page", re.compile(r"derniere page|last page", re.I)),
    ("language", re.compile(r"langue de depart|start language", re.I)),
    ("seed", re.compile(r"tete de serie|seed", re.I)),
    ("ip", re.compile(r"adresse ip|ip address", re.I)),
    ("post_number", re.compile(r"num poste|poste|post number|interviewer", re.I)),
    ("session_code", re.compile(r"session ?code|code de session", re.I)),
    ("interview_time", re.compile(r"duree totale|interviewtime|temps total", re.I)),
]


def _parse_dt(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    s = str(value or "").strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


# ---------------------------------------------------------------------------
# Mappage des colonnes du fichier entretiens
# ---------------------------------------------------------------------------


def build_column_map(headers: list[str], definition: dict) -> dict[str, Any]:
    """Associe chaque colonne Excel à une méta-donnée ou à une question.

    Retour :
        {"meta": {index: meta_key}, "questions": {index: (code, sub_code|None)},
         "unmatched": [headers...]}
    """
    questions = definition.get("questions", [])
    by_code = {q["code"]: q for q in questions}
    # Indexe le texte normalisé -> file de questions dans l'ordre du
    # questionnaire (les en-têtes de sous-questions dupliquent le texte parent).
    text_index: dict[str, list[dict]] = {}
    for q in questions:
        text_index.setdefault(_norm_key(q["text"]), []).append(q)

    # Curseur par texte normalisé : les colonnes d'un même texte sont
    # allouées dans l'ordre à TOUTES les questions partageant ce texte
    # (cas réel : deux matrices « site » / « application » au libellé identique),
    # puis à leurs sous-questions dans l'ordre du questionnaire.
    text_cursor: dict[str, int] = {}

    def alloc(key: str, candidates: list[dict]) -> tuple[str, str | None]:
        pos = text_cursor.get(key, 0)
        text_cursor[key] = pos + 1
        for q in candidates:
            subs = q.get("subquestions") or []
            size = len(subs) if subs else 1
            if pos < size:
                if subs:
                    return q["code"], subs[pos]["code"]
                return q["code"], None
            pos -= size
        # Colonnes excédentaires (« Autre », commentaires…) : rattachées à la
        # dernière question du texte, marquées _extra (non bloquant).
        return candidates[-1]["code"], f"_extra{pos}"

    meta: dict[int, str] = {}
    qmap: dict[int, tuple[str, str | None]] = {}
    unmatched: list[str] = []
    seen_meta: set[str] = set()

    for idx, header in enumerate(headers):
        h = str(header or "").strip()
        if not h:
            continue
        nh = _norm(h)
        if _IGNORE_RE.search(nh):
            continue  # colonnes de chronométrage : ignorées silencieusement

        # 1. Méta-données (une seule fois chacune — la 1re colonne gagne).
        matched_meta = None
        for key, pat in _META_PATTERNS:
            if key not in seen_meta and pat.search(nh):
                matched_meta = key
                break
        if matched_meta:
            meta[idx] = matched_meta
            seen_meta.add(matched_meta)
            continue

        # 2. Code exact (ex. « SatisGlobale » ou « NomBanque[SQ010] »).
        m = re.match(r"^([A-Za-z0-9_]+)(?:\[([A-Za-z0-9_]+)\])?$", h)
        if m and m.group(1) in by_code:
            qmap[idx] = (m.group(1), m.group(2))
            continue

        # 3. Texte complet de la question (cas de l'export réel).
        key = _norm_key(h)
        candidates = text_index.get(key)
        if candidates:
            qmap[idx] = alloc(key, candidates)
            continue

        # 4. Préfixe du texte (l'export tronque parfois les en-têtes).
        prefix = _norm_key(h, 60)
        hit_key = None
        for k in text_index:
            if k.startswith(prefix) or prefix.startswith(k[:60]):
                hit_key = k
                break
        if hit_key:
            qmap[idx] = alloc(hit_key, text_index[hit_key])
            continue

        unmatched.append(h)

    return {"meta": meta, "questions": qmap, "unmatched": unmatched}


def _match_option(raw: str, options: list[dict]) -> tuple[str | None, str | None]:
    """Retrouve (code, label) d'une option depuis un libellé ou un code brut."""
    n = _norm(raw)
    for opt in options:
        if n == _norm(opt.get("code")):
            return opt.get("code"), opt.get("label")
    for opt in options:
        if n == _norm(opt.get("label")):
            return opt.get("code"), opt.get("label")
    # Libellés bilingues : le début du libellé suffit (FR avant darija).
    for opt in options:
        lbl = _norm(opt.get("label"))
        if lbl and (lbl.startswith(n) or n.startswith(lbl[: max(len(lbl) // 2, 8)])):
            return opt.get("code"), opt.get("label")
    return None, None


NA_VALUES = {"n/a", "na", "-oth-", ""}


def import_interviews(
    db: Session,
    questionnaire: models.Questionnaire,
    content: bytes,
) -> dict[str, Any]:
    """Importe le fichier Excel des entretiens. Idempotent par (questionnaire,
    ID de réponse) : les lignes déjà importées sont mises à jour."""
    wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows_iter = ws.iter_rows(values_only=True)
    try:
        headers = [str(h) if h is not None else "" for h in next(rows_iter)]
    except StopIteration:
        raise ValueError("Le fichier Excel est vide.")

    definition = questionnaire.definition or {}
    cmap = build_column_map(headers, definition)
    by_code = {q["code"]: q for q in definition.get("questions", [])}
    mapped_codes = {code for code, _sub in cmap["questions"].values()}
    # Questions du LSS sans colonne correspondante : marquées « unmapped »
    # pour ne pas générer de fausses anomalies « question sautée ».
    unmapped_codes = [
        q["code"]
        for q in definition.get("questions", [])
        if q["code"] not in mapped_codes and q.get("type") not in ("display_only", "computed")
    ]

    created = updated = 0
    posts_seen: set[str] = set()
    interviewer_cache: dict[str, models.Interviewer] = {
        i.post_number: i for i in db.query(models.Interviewer).all()
    }

    for row_num, row in enumerate(rows_iter, start=2):
        if row is None or all(v is None for v in row):
            continue
        meta_values: dict[str, Any] = {}
        answers: dict[str, dict] = {}
        multi_parts: dict[str, list[str]] = {}

        for idx, key in cmap["meta"].items():
            if idx < len(row):
                meta_values[key] = row[idx]

        for idx, (code, sub) in cmap["questions"].items():
            if idx >= len(row):
                continue
            raw = row[idx]
            raw_s = str(raw).strip() if raw is not None else ""
            q = by_code.get(code)
            if q is None:
                continue
            shown = _norm(raw_s) not in NA_VALUES
            entry = answers.setdefault(
                code,
                {"raw": None, "code": None, "label": None, "shown": False, "subs": {}},
            )
            if sub and not str(sub).startswith("_extra"):
                if shown:
                    entry["subs"][sub] = raw_s
                    entry["shown"] = True
                    multi_parts.setdefault(code, []).append(raw_s)
            else:
                if shown:
                    entry["raw"] = raw_s
                    entry["shown"] = True
                    opt_code, opt_label = _match_option(raw_s, q.get("options") or [])
                    entry["code"], entry["label"] = opt_code, opt_label or (raw_s if opt_code else None)

        # Reconstruit une valeur lisible pour les questions à sous-items.
        for code, parts in multi_parts.items():
            entry = answers.get(code)
            if entry is not None and entry.get("raw") is None and parts:
                # Choix multiples : liste des sous-items sélectionnés (Oui/valeur).
                selected = []
                q = by_code.get(code) or {}
                sub_labels = {s["code"]: s["label"] for s in q.get("subquestions") or []}
                for sub_code, val in entry["subs"].items():
                    if _norm(val) in ("oui", "yes", "y", "true", "1") or (
                        q.get("type") == "matrix"
                    ):
                        label = sub_labels.get(sub_code, sub_code)
                        selected.append(f"{label}: {val}" if q.get("type") == "matrix" else label)
                entry["raw"] = " | ".join(selected) if selected else " | ".join(parts)

        for code in unmapped_codes:
            answers.setdefault(
                code,
                {"raw": None, "code": None, "label": None, "shown": False,
                 "subs": {}, "unmapped": True},
            )

        external_id = str(meta_values.get("external_id") or f"row{row_num}").strip()
        post_raw = meta_values.get("post_number")
        post_number = (
            str(int(post_raw)) if isinstance(post_raw, float) and post_raw.is_integer()
            else str(post_raw).strip() if post_raw is not None else None
        )

        interviewer = None
        if post_number:
            posts_seen.add(post_number)
            interviewer = interviewer_cache.get(post_number)
            if interviewer is None:
                interviewer = models.Interviewer(post_number=post_number)
                db.add(interviewer)
                db.flush()
                interviewer_cache[post_number] = interviewer

        started = _parse_dt(meta_values.get("started_at"))
        submitted = _parse_dt(meta_values.get("submitted_at"))
        duration = None
        if started and submitted and submitted >= started:
            duration = int((submitted - started).total_seconds())

        session_code = str(meta_values.get("session_code") or "").strip() or None

        respondent_meta = {
            k: (str(v) if v is not None else None)
            for k, v in meta_values.items()
            if k in ("language", "ip", "last_page")
        }

        interview = (
            db.query(models.Interview)
            .filter_by(questionnaire_id=questionnaire.id, external_id=external_id)
            .one_or_none()
        )
        if interview is None:
            interview = models.Interview(
                questionnaire_id=questionnaire.id, external_id=external_id
            )
            db.add(interview)
            created += 1
        else:
            updated += 1
        interview.interviewer_id = interviewer.id if interviewer else None
        interview.session_code = session_code
        interview.answers = answers
        interview.respondent_meta = respondent_meta
        interview.started_at = started
        interview.submitted_at = submitted
        interview.duration_sec = duration
        interview.source_row = row_num

    db.flush()
    # Tente de lier les transcriptions orphelines importées avant les entretiens.
    relinked = _relink_orphans(db, questionnaire.id)
    db.commit()
    wb.close()

    return {
        "created": created,
        "updated": updated,
        "posts": sorted(posts_seen),
        "unmatched_columns": cmap["unmatched"],
        "relinked_transcripts": relinked,
    }


# ---------------------------------------------------------------------------
# Transcriptions
# ---------------------------------------------------------------------------

_SPEAKER_RE = re.compile(r"^\s*(?:SPEAKER\s+)?([A-D])\s*:\s*(.*)$", re.I)


def parse_turns(raw: str) -> list[dict]:
    """Découpe « SPEAKER A: ... » en tours de parole."""
    turns: list[dict] = []
    current: dict | None = None
    for line in (raw or "").splitlines():
        m = _SPEAKER_RE.match(line)
        if m:
            if current:
                turns.append(current)
            current = {"i": len(turns), "speaker": m.group(1).upper(), "text": m.group(2).strip()}
        elif current is not None and line.strip():
            current["text"] = (current["text"] + " " + line.strip()).strip()
        elif line.strip():
            current = {"i": len(turns), "speaker": "?", "text": line.strip()}
    if current:
        turns.append(current)
    return turns


def guess_question_code(original_name: str | None, definition: dict) -> str | None:
    """Fait correspondre « Original Name » à un code de question du LSS."""
    if not original_name:
        return None
    n = _norm(original_name).replace(" ", "").replace("-", "_")
    best = None
    for q in definition.get("questions", []):
        c = _norm(q["code"]).replace(" ", "").replace("-", "_")
        if n == c:
            return q["code"]
        if n.replace("_", "") == c.replace("_", ""):
            best = best or q["code"]
    return best


def import_transcripts(
    db: Session,
    questionnaire: models.Questionnaire,
    content: bytes,
) -> dict[str, Any]:
    """Importe le fichier Excel des transcriptions et les lie par Session Code."""
    wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows_iter = ws.iter_rows(values_only=True)
    try:
        headers = [_norm(h) for h in next(rows_iter)]
    except StopIteration:
        raise ValueError("Le fichier Excel est vide.")

    def find_col(*names: str) -> int | None:
        for i, h in enumerate(headers):
            for n in names:
                if n in h:
                    return i
        return None

    col_code = find_col("sessioncode", "session code", "code de session")
    col_name = find_col("original name", "name", "question")
    col_text = find_col("transcript", "transcription", "texte")
    if col_code is None or col_text is None:
        raise ValueError(
            "Colonnes attendues introuvables : le fichier doit contenir "
            "« SessionCode » et « Transcript »."
        )

    interviews_by_code = {
        (i.session_code or "").upper(): i
        for i in db.query(models.Interview)
        .filter(models.Interview.questionnaire_id == questionnaire.id)
        .all()
        if i.session_code
    }

    linked = orphaned = 0
    take_counter: dict[tuple[int, str], int] = {}

    for row in rows_iter:
        if row is None or all(v is None for v in row):
            continue
        session_code = str(row[col_code] or "").strip()
        raw_text = str(row[col_text] or "").strip()
        original_name = (
            str(row[col_name]).strip() if col_name is not None and row[col_name] else None
        )
        if not session_code:
            continue

        interview = interviews_by_code.get(session_code.upper())
        if interview is None:
            db.add(
                models.UnlinkedTranscript(
                    session_code=session_code,
                    original_name=original_name,
                    raw_text=raw_text,
                )
            )
            orphaned += 1
            continue

        q_code = guess_question_code(original_name, questionnaire.definition or {})
        key = (interview.id, original_name or "")
        take_counter[key] = take_counter.get(key, 0) + 1

        # Idempotence : remplace la même prise si ré-importée.
        existing = (
            db.query(models.Transcript)
            .filter_by(
                interview_id=interview.id,
                original_name=original_name,
                take_number=take_counter[key],
            )
            .one_or_none()
        )
        if existing is None:
            existing = models.Transcript(
                interview_id=interview.id,
                original_name=original_name,
                take_number=take_counter[key],
            )
            db.add(existing)
        existing.scope = "segment"
        existing.question_code = q_code
        existing.raw_text = raw_text
        existing.turns = parse_turns(raw_text)
        existing.link_method = "session_code"
        linked += 1

    db.commit()
    wb.close()
    return {"linked": linked, "orphaned": orphaned}


def _relink_orphans(db: Session, questionnaire_id: int) -> int:
    """Rattache les transcriptions orphelines après un import d'entretiens."""
    orphans = db.query(models.UnlinkedTranscript).all()
    if not orphans:
        return 0
    questionnaire = db.get(models.Questionnaire, questionnaire_id)
    interviews_by_code = {
        (i.session_code or "").upper(): i
        for i in db.query(models.Interview)
        .filter(models.Interview.questionnaire_id == questionnaire_id)
        .all()
        if i.session_code
    }
    relinked = 0
    for orphan in orphans:
        interview = interviews_by_code.get(orphan.session_code.upper())
        if interview is None:
            continue
        db.add(
            models.Transcript(
                interview_id=interview.id,
                scope="segment",
                question_code=guess_question_code(
                    orphan.original_name, questionnaire.definition or {}
                ),
                original_name=orphan.original_name,
                raw_text=orphan.raw_text,
                turns=parse_turns(orphan.raw_text),
                link_method="session_code",
            )
        )
        db.delete(orphan)
        relinked += 1
    return relinked
