"""Configuration de la base de données SQLAlchemy."""
from __future__ import annotations

from collections.abc import Generator

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from .config import settings

_IS_SQLITE = settings.database_url.startswith("sqlite")

# timeout=30 : une écriture concurrente attend jusqu'à 30 s que le verrou se
# libère au lieu d'échouer immédiatement avec « database is locked ».
connect_args = (
    {"check_same_thread": False, "timeout": 30} if _IS_SQLITE else {}
)

engine = create_engine(
    settings.database_url,
    connect_args=connect_args,
    pool_pre_ping=True,
)

if _IS_SQLITE:

    @event.listens_for(engine, "connect")
    def _set_sqlite_pragmas(dbapi_connection, _connection_record) -> None:
        # WAL : les lectures ne bloquent plus les écritures (et inversement),
        # indispensable quand une évaluation tourne en arrière-plan pendant
        # que l'API continue de servir le tableau de bord.
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.close()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    """Base déclarative pour les modèles ORM."""


def get_db() -> Generator[Session, None, None]:
    """Dépendance FastAPI fournissant une session de base de données."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Crée les tables si elles n'existent pas."""
    from . import models  # noqa: F401  (import pour enregistrer les modèles)

    Base.metadata.create_all(bind=engine)
