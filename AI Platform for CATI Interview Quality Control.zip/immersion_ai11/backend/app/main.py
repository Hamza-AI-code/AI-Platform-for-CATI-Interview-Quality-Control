"""Point d'entrée de l'API FastAPI — Immersion AI, contrôle qualité CATI."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .database import SessionLocal, init_db
from .deps import get_current_user
from .routers import (
    admin,
    auth,
    dashboard,
    interviewers,
    interviews,
    questionnaires,
    reports,
)


def seed_super_admin() -> None:
    """Crée le compte super administrateur initial si aucun utilisateur n'existe."""
    from . import models
    from .security import hash_password

    db = SessionLocal()
    try:
        if db.query(models.User).count() == 0:
            db.add(
                models.User(
                    name=settings.seed_admin_name,
                    email=settings.seed_admin_email.lower(),
                    role="super_admin",
                    status="active",
                    permissions=["all"],
                    password_hash=hash_password(settings.seed_admin_password),
                )
            )
            db.commit()
    finally:
        db.close()


logger = logging.getLogger("immerssion.startup")


def _log_ai_status() -> None:
    """Affiche au démarrage si l'IA locale (Ollama) est réellement utilisable.

    Jamais de repli silencieux : Ollama arrêté ou modèle non installé ->
    message d'erreur EXACT dans les logs, avec la commande à exécuter
    (le moteur déterministe continue seul en attendant).
    """
    from .config import BASE_DIR
    from .services import ai_service

    env_path = BASE_DIR / ".env"
    ok, detail = ai_service.healthcheck()
    if ok:
        logger.info(
            "IA locale OPÉRATIONNELLE — %s (configuration lue depuis %s, "
            "aucune clé API ni connexion internet requise).",
            detail, env_path,
        )
        if settings.ai_debug:
            logger.info(
                "AI_DEBUG actif : trace par question dans les logs et dans "
                "data/ai_debug.jsonl."
            )
    else:
        logger.error("IA locale INDISPONIBLE : %s", detail)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Garantit que les logs applicatifs (immerssion.*) sont visibles même si
    # aucun handler racine n'est configuré par le serveur.
    if not logging.getLogger().handlers:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        )
    init_db()
    seed_super_admin()
    _log_ai_status()
    yield


app = FastAPI(
    title=settings.app_name,
    version=settings.api_version,
    description=(
        "API de contrôle qualité des enquêteurs CATI : questionnaire .LSS, "
        "entretiens Excel, transcriptions liées par Session Code, évaluation IA."
    ),
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_origin_regex=r"https?://localhost(:\d+)?|https?://127\.0\.0\.1(:\d+)?",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Public : authentification.
app.include_router(auth.router)

# Protégé : toute action métier nécessite un jeton d'accès valide.
protected = [Depends(get_current_user)]
app.include_router(dashboard.router, dependencies=protected)
app.include_router(questionnaires.router, dependencies=protected)
app.include_router(interviews.router, dependencies=protected)
app.include_router(interviewers.router, dependencies=protected)
app.include_router(reports.router)  # protection par endpoint (download public)
app.include_router(admin.router, dependencies=protected)


@app.get("/")
def root():
    return {
        "name": settings.app_name,
        "version": settings.api_version,
        "status": "online",
        "docs": "/docs",
    }


@app.get("/api/health")
def health():
    return {"status": "ok"}
