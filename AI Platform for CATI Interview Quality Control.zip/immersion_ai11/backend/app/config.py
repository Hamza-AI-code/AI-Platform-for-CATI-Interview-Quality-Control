"""Configuration applicative chargée depuis l'environnement."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = BASE_DIR / "uploads"


class Settings(BaseSettings):
    """Paramètres de l'application."""

    # IMPORTANT : chemin ABSOLU vers backend/.env — la clé se charge quel que
    # soit le répertoire de lancement (uvicorn depuis backend/, la racine du
    # projet, un IDE, Docker…). Un chemin relatif dépendait du CWD et faisait
    # silencieusement perdre la configuration OLLAMA_*.
    model_config = SettingsConfigDict(env_file=str(BASE_DIR / ".env"), extra="ignore")

    app_name: str = "Immersion AI"
    api_version: str = "1.0.0"
    database_url: str = f"sqlite:///{DATA_DIR / 'immerssion.db'}"

    # CORS — origines autorisées (séparées par des virgules).
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000"

    # Intégration IA : Ollama — LLM 100 % LOCAL (aucun cloud, aucune clé API,
    # aucun crédit, aucune facturation ; fonctionne entièrement hors ligne).
    # URL du serveur Ollama local.
    ollama_base_url: str = "http://localhost:11434"
    # Modèle utilisé pour TOUTE l'analyse sémantique. Changer de modèle =
    # modifier UNIQUEMENT backend/.env (OLLAMA_MODEL), aucun changement de
    # code. VIDE = détection automatique du meilleur modèle installé
    # (priorité : deepseek-r1 > qwen3 > llama3.1 > mistral).
    ollama_model: str = ""
    # Fenêtre de contexte demandée à Ollama : un entretien complet
    # (transcription + questions + réponses) doit tenir en entrée.
    ollama_num_ctx: int = 16384
    # Évaluations exécutées en parallèle (lots de questions, par entretien).
    # 1 par défaut : un LLM local sature vite la RAM/GPU ; Ollama met de
    # toute façon les requêtes en file.
    ai_max_concurrency: int = 1
    # Nombre maximal de questions traitées dans UN appel IA. Avec la valeur
    # par défaut, un entretien complet (questions + analyse de conduite)
    # tient dans UN SEUL appel. Les modèles locaux 8B tiennent mieux les
    # longues listes en 2 lots : baissez à 20 si les réponses se dégradent.
    ai_questions_per_call: int = 40
    # Mode debug : trace par question (extraits choisis, prompt, réponse JSON
    # du modèle, résultat final) dans les logs + data/ai_debug.jsonl.
    ai_debug: bool = False

    # Authentification (JWT).
    jwt_secret: str = "change-me-immerssion-ai-secret-key-2026"
    access_token_minutes: int = 60
    refresh_token_days: int = 7

    # Compte super administrateur créé au premier démarrage.
    seed_admin_email: str = "admin@immerssion.ai"
    seed_admin_password: str = "Admin123!"
    seed_admin_name: str = "Super Admin"

    # Limites d'upload (octets) — 200 Mo par défaut.
    max_upload_size: int = 200 * 1024 * 1024

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    return Settings()


settings = get_settings()
