"""Immerssion AI — backend FastAPI pour le contrôle qualité des enquêtes."""

__version__ = "1.0.0"
