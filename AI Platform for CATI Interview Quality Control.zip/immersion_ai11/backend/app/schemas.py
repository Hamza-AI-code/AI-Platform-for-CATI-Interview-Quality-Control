"""Schémas Pydantic (validation entrée/sortie) — plateforme QA CATI."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Annotated, Any

from pydantic import AfterValidator, BaseModel, ConfigDict, Field

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _validate_email(value: str | None) -> str | None:
    """Validation d'email légère, sans dépendance externe."""
    if value is None:
        return None
    value = value.strip()
    if not value:
        return None
    if not _EMAIL_RE.match(value):
        raise ValueError("Adresse email invalide")
    return value


Email = Annotated[str | None, AfterValidator(_validate_email)]


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# --------------------------------------------------------------------------- #
# Questionnaires
# --------------------------------------------------------------------------- #
class QuestionnaireOut(ORMModel):
    id: int
    title: str
    original_filename: str | None
    survey_id: str | None
    language: str
    question_count: int
    created_at: datetime


class QuestionnaireDetail(QuestionnaireOut):
    definition: dict[str, Any]


class ImportResult(BaseModel):
    questionnaire_id: int
    created: int = 0
    updated: int = 0
    linked: int = 0
    orphaned: int = 0
    relinked_transcripts: int = 0
    posts: list[str] = Field(default_factory=list)
    unmatched_columns: list[str] = Field(default_factory=list)


# --------------------------------------------------------------------------- #
# Entretiens & transcriptions
# --------------------------------------------------------------------------- #
class TranscriptOut(ORMModel):
    id: int
    scope: str
    question_code: str | None
    original_name: str | None
    take_number: int
    raw_text: str
    turns: list[dict[str, Any]]
    link_method: str


class FindingOut(ORMModel):
    id: int
    question_code: str | None
    category: str
    severity: str
    confidence: float
    source: str
    recorded_value: str | None
    expected_value: str | None
    evidence: str | None
    explanation: str
    recommendation: str | None


class EvaluationOut(ORMModel):
    id: int
    status: str
    mode: str
    engine: str
    quality_score: float | None
    verdict: str | None
    fraud_risk: float | None
    summary: str | None
    coverage: dict[str, Any]
    error: str | None = None
    created_at: datetime
    completed_at: datetime | None


class EvaluationDetail(EvaluationOut):
    findings: list[FindingOut]


class InterviewListItem(ORMModel):
    id: int
    external_id: str
    session_code: str | None
    post_number: str | None = None
    duration_sec: int | None
    submitted_at: datetime | None
    transcript_count: int = 0
    quality_score: float | None = None
    verdict: str | None = None
    fraud_risk: float | None = None
    evaluation_status: str | None = None


class InterviewDetail(ORMModel):
    id: int
    external_id: str
    session_code: str | None
    post_number: str | None = None
    questionnaire_id: int
    respondent_meta: dict[str, Any]
    answers: dict[str, Any]
    started_at: datetime | None
    submitted_at: datetime | None
    duration_sec: int | None
    transcripts: list[TranscriptOut]
    evaluation: EvaluationDetail | None = None


class EvaluateRequest(BaseModel):
    interview_ids: list[int] | None = None


# --------------------------------------------------------------------------- #
# Enquêteurs CATI (Post) — détectés automatiquement, aucune saisie manuelle
# --------------------------------------------------------------------------- #
class InterviewerSummary(BaseModel):
    post_number: str
    interviews: int
    evaluated: int
    avg_score: float | None
    critical_errors: int
    minor_errors: int
    accuracy_pct: float | None
    fraud_risk: float | None
    fail_count: int
    needs_review_count: int
    rank: int | None = None


class InterviewerDetail(InterviewerSummary):
    recommendations: list[str] = Field(default_factory=list)
    recommendations_at: datetime | None = None
    error_distribution: list[dict[str, Any]] = Field(default_factory=list)
    trend: list[dict[str, Any]] = Field(default_factory=list)
    worst_interviews: list[InterviewListItem] = Field(default_factory=list)


# --------------------------------------------------------------------------- #
# Dashboard direction
# --------------------------------------------------------------------------- #
class DashboardData(BaseModel):
    total_interviews: int
    evaluated_interviews: int
    total_interviewers: int
    avg_score: float | None
    pass_rate: float | None
    critical_findings: int
    transcripts_linked: int
    transcripts_orphaned: int
    interviewers: list[InterviewerSummary]
    error_distribution: list[dict[str, Any]]
    problem_questions: list[dict[str, Any]]
    management_recommendations: list[dict[str, Any]] = Field(default_factory=list)
    score_histogram: list[dict[str, Any]]
    recent_activity: list["ActivityOut"]
    questionnaire: QuestionnaireOut | None = None


# --------------------------------------------------------------------------- #
# Rapports
# --------------------------------------------------------------------------- #
class ReportCreate(BaseModel):
    scope: str = "interview"  # interview|interviewer|global
    format: str = "pdf"  # pdf|excel
    interview_id: int | None = None
    post_number: str | None = None


class ReportOut(ORMModel):
    id: int
    title: str
    scope: str
    format: str
    interview_id: int | None
    post_number: str | None
    stored_name: str
    size: int
    created_at: datetime


# --------------------------------------------------------------------------- #
# Auth
# --------------------------------------------------------------------------- #
class LoginRequest(BaseModel):
    email: str
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: "UserOut"


# --------------------------------------------------------------------------- #
# Users / Admin
# --------------------------------------------------------------------------- #
class UserCreate(BaseModel):
    name: str
    email: Email
    role: str = "viewer"
    password: str | None = None
    permissions: list[str] = Field(default_factory=list)


class UserUpdate(BaseModel):
    name: str | None = None
    role: str | None = None
    status: str | None = None
    permissions: list[str] | None = None


class PasswordReset(BaseModel):
    password: str = Field(..., min_length=6)


class UserOut(ORMModel):
    id: int
    name: str
    email: str
    role: str
    status: str
    permissions: list[str]
    last_login: datetime | None
    created_at: datetime


class SettingOut(BaseModel):
    key: str
    value: dict[str, Any]


class SettingUpdate(BaseModel):
    value: dict[str, Any]


# --------------------------------------------------------------------------- #
# Activités
# --------------------------------------------------------------------------- #
class ActivityOut(ORMModel):
    id: int
    type: str
    message: str
    severity: str
    entity_id: int | None
    created_at: datetime


DashboardData.model_rebuild()
TokenResponse.model_rebuild()
