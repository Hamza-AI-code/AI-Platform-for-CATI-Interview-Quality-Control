"""Modèles ORM SQLAlchemy — plateforme de contrôle qualité CATI.

Concepts clés :
    - L'enquêteur CATI est identifié UNIQUEMENT par son numéro de poste
      (« Post »). Il est créé automatiquement lors de l'import du fichier
      Excel des entretiens — aucune saisie manuelle.
    - Aucun fichier audio : les transcriptions arrivent déjà en texte
      (fichier Excel), liées aux entretiens par le Session Code.
"""
from __future__ import annotations

import enum
from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


def utcnow() -> datetime:
    # Naïf (UTC) pour rester cohérent avec le stockage SQLite sans fuseau.
    return datetime.now(timezone.utc).replace(tzinfo=None)


class EvaluationStatus(str, enum.Enum):
    queued = "queued"
    running = "running"
    completed = "completed"
    failed = "failed"


class Severity(str, enum.Enum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class Interviewer(Base):
    """Enquêteur CATI — détecté automatiquement depuis le fichier Excel.

    Identifié uniquement par le numéro de poste (ex. « 164 »).
    """

    __tablename__ = "interviewers"

    id: Mapped[int] = mapped_column(primary_key=True)
    post_number: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    first_seen_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    # Recommandations IA agrégées (liste de chaînes) + date de génération.
    recommendations: Mapped[list] = mapped_column(JSON, default=list)
    recommendations_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    interviews: Mapped[list["Interview"]] = relationship(back_populates="interviewer")


class Questionnaire(Base):
    """Questionnaire de référence importé depuis un fichier .LSS LimeSurvey."""

    __tablename__ = "questionnaires"

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(255))
    original_filename: Mapped[str | None] = mapped_column(String(500), nullable=True)
    survey_id: Mapped[str | None] = mapped_column(String(40), nullable=True)
    language: Mapped[str] = mapped_column(String(10), default="fr")
    lss_sha256: Mapped[str] = mapped_column(String(64), unique=True)
    # Structure normalisée : {groups: [...], questions: [{code, type, text,
    # options, subquestions, relevance, mandatory, order}, ...]}
    definition: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    interviews: Mapped[list["Interview"]] = relationship(back_populates="questionnaire")

    @property
    def question_count(self) -> int:
        return len((self.definition or {}).get("questions", []))


class Interview(Base):
    """Un entretien CATI = une ligne du fichier Excel des réponses."""

    __tablename__ = "interviews"
    __table_args__ = (
        UniqueConstraint("questionnaire_id", "external_id", name="uq_interview_ext"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    questionnaire_id: Mapped[int] = mapped_column(
        ForeignKey("questionnaires.id", ondelete="CASCADE")
    )
    interviewer_id: Mapped[int | None] = mapped_column(
        ForeignKey("interviewers.id", ondelete="SET NULL"), nullable=True
    )
    external_id: Mapped[str] = mapped_column(String(64))  # « ID de la réponse »
    session_code: Mapped[str | None] = mapped_column(String(64), index=True)
    respondent_meta: Mapped[dict] = mapped_column(JSON, default=dict)
    # {question_code: {"raw": str, "code": str|None, "label": str|None,
    #                  "shown": bool}}
    answers: Mapped[dict] = mapped_column(JSON, default=dict)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    duration_sec: Mapped[int | None] = mapped_column(Integer, nullable=True)
    source_row: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    questionnaire: Mapped["Questionnaire"] = relationship(back_populates="interviews")
    interviewer: Mapped["Interviewer | None"] = relationship(back_populates="interviews")
    transcripts: Mapped[list["Transcript"]] = relationship(
        back_populates="interview", cascade="all, delete-orphan"
    )
    evaluations: Mapped[list["Evaluation"]] = relationship(
        back_populates="interview", cascade="all, delete-orphan"
    )


class Transcript(Base):
    """Transcription texte d'un segment enregistré, liée par Session Code.

    scope='segment' : transcription d'une question ouverte enregistrée
    (données actuelles). scope='call' : transcription d'appel complet.
    """

    __tablename__ = "transcripts"

    id: Mapped[int] = mapped_column(primary_key=True)
    interview_id: Mapped[int] = mapped_column(
        ForeignKey("interviews.id", ondelete="CASCADE"), index=True
    )
    scope: Mapped[str] = mapped_column(String(10), default="segment")  # segment|call
    question_code: Mapped[str | None] = mapped_column(String(80), nullable=True)
    original_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    take_number: Mapped[int] = mapped_column(Integer, default=1)
    raw_text: Mapped[str] = mapped_column(Text, default="")
    # [{"i": int, "speaker": "A"|"B", "text": str}]
    turns: Mapped[list] = mapped_column(JSON, default=list)
    link_method: Mapped[str] = mapped_column(String(20), default="session_code")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    interview: Mapped["Interview"] = relationship(back_populates="transcripts")


class UnlinkedTranscript(Base):
    """Transcription dont le Session Code ne correspond à aucun entretien."""

    __tablename__ = "unlinked_transcripts"

    id: Mapped[int] = mapped_column(primary_key=True)
    session_code: Mapped[str] = mapped_column(String(64))
    original_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    raw_text: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Evaluation(Base):
    """Résultat de l'évaluation qualité d'un entretien."""

    __tablename__ = "evaluations"

    id: Mapped[int] = mapped_column(primary_key=True)
    interview_id: Mapped[int] = mapped_column(
        ForeignKey("interviews.id", ondelete="CASCADE"), index=True
    )
    status: Mapped[EvaluationStatus] = mapped_column(
        Enum(EvaluationStatus), default=EvaluationStatus.queued
    )
    mode: Mapped[str] = mapped_column(String(12), default="segment")  # segment|full_call
    engine: Mapped[str] = mapped_column(String(20), default="heuristic")  # heuristic|ollama
    quality_score: Mapped[float | None] = mapped_column(Float, nullable=True)  # 0-100
    verdict: Mapped[str | None] = mapped_column(String(16), nullable=True)  # pass|needs_review|fail
    fraud_risk: Mapped[float | None] = mapped_column(Float, nullable=True)  # 0-100
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    # Couverture : questions attendues / posées / transcrites…
    coverage: Mapped[dict] = mapped_column(JSON, default=dict)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    interview: Mapped["Interview"] = relationship(back_populates="evaluations")
    findings: Mapped[list["Finding"]] = relationship(
        back_populates="evaluation", cascade="all, delete-orphan"
    )


class Finding(Base):
    """Une anomalie détectée (par règle déterministe ou par l'IA)."""

    __tablename__ = "findings"

    id: Mapped[int] = mapped_column(primary_key=True)
    evaluation_id: Mapped[int] = mapped_column(
        ForeignKey("evaluations.id", ondelete="CASCADE"), index=True
    )
    question_code: Mapped[str | None] = mapped_column(String(80), nullable=True)
    category: Mapped[str] = mapped_column(String(50), index=True)
    severity: Mapped[Severity] = mapped_column(Enum(Severity), default=Severity.medium)
    confidence: Mapped[float] = mapped_column(Float, default=1.0)  # 0-1
    source: Mapped[str] = mapped_column(String(20), default="deterministic")  # deterministic|llm
    recorded_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    expected_value: Mapped[str | None] = mapped_column(Text, nullable=True)
    evidence: Mapped[str | None] = mapped_column(Text, nullable=True)  # citation transcript
    explanation: Mapped[str] = mapped_column(Text, default="")
    recommendation: Mapped[str | None] = mapped_column(Text, nullable=True)

    evaluation: Mapped["Evaluation"] = relationship(back_populates="findings")


class Report(Base):
    __tablename__ = "reports"

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(255))
    scope: Mapped[str] = mapped_column(String(20), default="interview")  # interview|interviewer|global
    format: Mapped[str] = mapped_column(String(10), default="pdf")  # pdf|excel
    interview_id: Mapped[int | None] = mapped_column(
        ForeignKey("interviews.id", ondelete="SET NULL"), nullable=True
    )
    post_number: Mapped[str | None] = mapped_column(String(40), nullable=True)
    stored_name: Mapped[str] = mapped_column(String(500))
    file_path: Mapped[str] = mapped_column(String(1000))
    size: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


#: Rôles applicatifs (du plus puissant au plus restreint).
ROLES = ("super_admin", "admin", "quality_manager", "supervisor", "viewer")


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160))
    email: Mapped[str] = mapped_column(String(255), unique=True)
    role: Mapped[str] = mapped_column(String(40), default="viewer")
    status: Mapped[str] = mapped_column(String(20), default="active")  # active/disabled
    permissions: Mapped[list] = mapped_column(JSON, default=list)
    password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_login: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Activity(Base):
    __tablename__ = "activities"

    id: Mapped[int] = mapped_column(primary_key=True)
    type: Mapped[str] = mapped_column(String(40))  # import/evaluation/report/alert
    message: Mapped[str] = mapped_column(String(500))
    severity: Mapped[Severity] = mapped_column(Enum(Severity), default=Severity.low)
    entity_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AppSetting(Base):
    __tablename__ = "app_settings"

    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)
