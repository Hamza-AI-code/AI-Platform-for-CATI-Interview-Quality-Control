"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { api } from "@/lib/api";
import type { User } from "@/lib/types";

export function useUsers(enabled = true) {
  return useQuery({ queryKey: ["users"], queryFn: api.listUsers, enabled });
}

export function useCreateUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { name: string; email: string; role: string; password: string }) =>
      api.createUserFull(body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["users"] });
      toast.success("Utilisateur créé");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useResetPassword() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, password }: { id: number; password: string }) =>
      api.resetPassword(id, password),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["users"] });
      toast.success("Mot de passe réinitialisé");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useToggleUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, enable }: { id: number; enable: boolean }) =>
      enable ? api.enableUser(id) : api.disableUser(id),
    onSuccess: (_, { enable }) => {
      qc.invalidateQueries({ queryKey: ["users"] });
      toast.success(enable ? "Utilisateur réactivé" : "Utilisateur désactivé");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useRoles(enabled = true) {
  return useQuery({ queryKey: ["roles"], queryFn: api.listRoles, enabled });
}

export function useUpdateUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: number; body: Partial<User> }) =>
      api.updateUser(id, body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["users"] });
      toast.success("Utilisateur mis à jour");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useDeleteUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => api.deleteUser(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["users"] });
      toast.success("Utilisateur supprimé");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useSettings() {
  return useQuery({ queryKey: ["settings"], queryFn: api.getSettings });
}

export function useUpdateSettings() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (value: Record<string, unknown>) => api.updateSettings(value),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["settings"] });
      toast.success("Paramètres enregistrés");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useSystemInfo() {
  return useQuery({ queryKey: ["system"], queryFn: api.systemInfo });
}
