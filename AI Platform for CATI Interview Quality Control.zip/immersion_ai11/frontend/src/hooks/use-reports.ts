"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { api } from "@/lib/api";
import type { ReportScope } from "@/lib/types";

export function useReports() {
  return useQuery({ queryKey: ["reports"], queryFn: api.listReports });
}

export function useCreateReport() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: {
      scope: ReportScope;
      format: "pdf" | "excel";
      interview_id?: number;
      post_number?: string;
    }) => api.createReport(payload),
    onSuccess: (report) => {
      qc.invalidateQueries({ queryKey: ["reports"] });
      toast.success(`Rapport généré : ${report.title}`);
      window.open(api.reportDownloadUrl(report.id), "_blank");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useDeleteReport() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => api.deleteReport(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["reports"] });
      toast.success("Rapport supprimé");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}
