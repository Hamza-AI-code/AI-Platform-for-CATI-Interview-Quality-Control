"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { api } from "@/lib/api";

// ------------------------------- Questionnaires --------------------------- #
export function useQuestionnaires() {
  return useQuery({ queryKey: ["questionnaires"], queryFn: api.listQuestionnaires });
}

export function useQuestionnaire(id: number | undefined) {
  return useQuery({
    queryKey: ["questionnaire", id],
    queryFn: () => api.getQuestionnaire(id as number),
    enabled: Number.isFinite(id),
  });
}

export function useImportLss() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (file: File) => api.importLss(file),
    onSuccess: (q) => {
      qc.invalidateQueries();
      toast.success(`Questionnaire « ${q.title} » importé (${q.question_count} questions)`);
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useImportInterviews() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ questionnaireId, file }: { questionnaireId: number; file: File }) =>
      api.importInterviews(questionnaireId, file),
    onSuccess: (r) => {
      qc.invalidateQueries();
      toast.success(
        `${r.created + r.updated} entretien(s) importé(s) — postes détectés : ${r.posts.join(", ") || "aucun"}`,
      );
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useImportTranscripts() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ questionnaireId, file }: { questionnaireId: number; file: File }) =>
      api.importTranscripts(questionnaireId, file),
    onSuccess: (r) => {
      qc.invalidateQueries();
      toast.success(
        `${r.linked} transcription(s) liée(s) par Session Code (${r.orphaned} orpheline(s))`,
      );
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

// --------------------------------- Entretiens ----------------------------- #
export function useInterviews(params?: {
  post_number?: string;
  verdict?: string;
  search?: string;
}) {
  return useQuery({
    queryKey: ["interviews", params],
    queryFn: () => api.listInterviews(params),
  });
}

export function useInterview(id: number) {
  return useQuery({
    queryKey: ["interview", id],
    queryFn: () => api.getInterview(id),
    enabled: Number.isFinite(id),
  });
}

export function useEvaluateInterview() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => api.evaluateInterview(id),
    onSuccess: () => {
      qc.invalidateQueries();
      toast.success("Entretien évalué");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useDeleteInterview() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => api.deleteInterview(id),
    onSuccess: () => {
      qc.invalidateQueries();
      toast.success("Entretien supprimé");
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useEvaluateAll() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (questionnaireId?: number) => api.evaluateAll(questionnaireId),
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ["evaluation-progress"] });
      toast.success(`Évaluation de ${r.interviews} entretien(s) lancée`);
    },
    onError: (e: Error) => toast.error(e.message),
  });
}

export function useEvaluationProgress(enabled = true) {
  return useQuery({
    queryKey: ["evaluation-progress"],
    queryFn: api.evaluationProgress,
    refetchInterval: (query) => {
      const d = query.state.data;
      return d && d.running > 0 ? 2000 : 8000;
    },
    enabled,
  });
}

// ------------------------------ Enquêteurs CATI --------------------------- #
export function useInterviewers() {
  return useQuery({ queryKey: ["interviewers"], queryFn: api.listInterviewers });
}

export function useInterviewer(postNumber: string) {
  return useQuery({
    queryKey: ["interviewer", postNumber],
    queryFn: () => api.getInterviewer(postNumber),
    enabled: Boolean(postNumber),
  });
}
