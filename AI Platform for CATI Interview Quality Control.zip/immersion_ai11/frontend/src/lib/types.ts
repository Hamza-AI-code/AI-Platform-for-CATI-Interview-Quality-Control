// Types de l'API — plateforme de contrôle qualité CATI.

// --------------------------------------------------------------------------
// Questionnaire (.LSS)
// --------------------------------------------------------------------------
export interface QuestionOption {
  code: string;
  label: string;
  order: number;
}

export interface SubQuestion {
  code: string;
  label: string;
  order: number;
}

export interface Question {
  qid: number;
  code: string;
  gid: number;
  order: number;
  lss_type: string;
  type: string;
  mandatory: boolean;
  text: string;
  options: QuestionOption[];
  subquestions: SubQuestion[];
  relevance: string | null;
}

export interface QuestionnaireDefinition {
  survey_id: string | null;
  title: string;
  language: string;
  languages: string[];
  groups: { gid: number; title: string; order: number }[];
  questions: Question[];
}

export interface Questionnaire {
  id: number;
  title: string;
  original_filename: string | null;
  survey_id: string | null;
  language: string;
  question_count: number;
  created_at: string;
}

export interface QuestionnaireDetail extends Questionnaire {
  definition: QuestionnaireDefinition;
}

export interface ImportResult {
  questionnaire_id: number;
  created: number;
  updated: number;
  linked: number;
  orphaned: number;
  relinked_transcripts: number;
  posts: string[];
  unmatched_columns: string[];
}

// --------------------------------------------------------------------------
// Entretiens & évaluations
// --------------------------------------------------------------------------
export interface AnswerEntry {
  raw: string | null;
  code: string | null;
  label: string | null;
  shown: boolean;
  unmapped?: boolean;
  subs?: Record<string, string>;
}

export interface TranscriptTurn {
  i: number;
  speaker: string;
  text: string;
}

export interface Transcript {
  id: number;
  scope: string;
  question_code: string | null;
  original_name: string | null;
  take_number: number;
  raw_text: string;
  turns: TranscriptTurn[];
  link_method: string;
}

export type Severity = "low" | "medium" | "high" | "critical";
export type Verdict = "pass" | "needs_review" | "fail";
export type EvaluationStatus = "queued" | "running" | "completed" | "failed";

export interface Finding {
  id: number;
  question_code: string | null;
  category: string;
  severity: Severity;
  confidence: number;
  source: "deterministic" | "llm";
  recorded_value: string | null;
  expected_value: string | null;
  evidence: string | null;
  explanation: string;
  recommendation: string | null;
}

// Statut de vérification d'une réponse enregistrée face à la transcription
// (partielle) : jamais « correcte par défaut ».
export type VerificationStatus =
  | "verified"
  | "contradicted"
  | "not_enough_evidence";

export interface AnswerVerification {
  question_code: string;
  status: VerificationStatus;
  confidence: number;
  evidence: string | null;
  explanation: string;
}

export interface EvaluationCoverage {
  expected_questions?: number;
  correctly_skipped?: number;
  routing_unknown?: number;
  transcribed_segments?: number;
  transcribed_questions?: string[];
  answered_questions?: number;
  verified?: number;
  contradicted?: number;
  insufficient_evidence?: number;
  evaluable_questions?: number;
  coverage_pct?: number;
  verifications?: AnswerVerification[];
}

export interface Evaluation {
  id: number;
  status: EvaluationStatus;
  mode: string;
  engine: string;
  quality_score: number | null;
  verdict: Verdict | null;
  fraud_risk: number | null;
  summary: string | null;
  coverage: EvaluationCoverage;
  error?: string | null;
  created_at: string;
  completed_at: string | null;
}

export interface EvaluationDetail extends Evaluation {
  findings: Finding[];
}

export interface InterviewListItem {
  id: number;
  external_id: string;
  session_code: string | null;
  post_number: string | null;
  duration_sec: number | null;
  submitted_at: string | null;
  transcript_count: number;
  quality_score: number | null;
  verdict: Verdict | null;
  fraud_risk: number | null;
  evaluation_status: EvaluationStatus | null;
}

export interface InterviewDetail {
  id: number;
  external_id: string;
  session_code: string | null;
  post_number: string | null;
  questionnaire_id: number;
  respondent_meta: Record<string, string | null>;
  answers: Record<string, AnswerEntry>;
  started_at: string | null;
  submitted_at: string | null;
  duration_sec: number | null;
  transcripts: Transcript[];
  evaluation: EvaluationDetail | null;
}

export interface EvaluationProgress {
  total: number;
  evaluated: number;
  running: number;
}

// --------------------------------------------------------------------------
// Enquêteurs CATI (Post) — détectés automatiquement
// --------------------------------------------------------------------------
export interface InterviewerSummary {
  post_number: string;
  interviews: number;
  evaluated: number;
  avg_score: number | null;
  critical_errors: number;
  minor_errors: number;
  accuracy_pct: number | null;
  fraud_risk: number | null;
  fail_count: number;
  needs_review_count: number;
  rank: number | null;
}

export interface InterviewerDetail extends InterviewerSummary {
  recommendations: string[];
  recommendations_at: string | null;
  error_distribution: { category: string; count: number; grave: number }[];
  trend: { date: string; score: number; interviews: number }[];
  worst_interviews: InterviewListItem[];
}

// --------------------------------------------------------------------------
// Dashboard direction
// --------------------------------------------------------------------------
export interface Activity {
  id: number;
  type: string;
  message: string;
  severity: string;
  entity_id: number | null;
  created_at: string;
}

export interface DashboardData {
  total_interviews: number;
  evaluated_interviews: number;
  total_interviewers: number;
  avg_score: number | null;
  pass_rate: number | null;
  critical_findings: number;
  transcripts_linked: number;
  transcripts_orphaned: number;
  interviewers: InterviewerSummary[];
  error_distribution: { category: string; count: number }[];
  problem_questions: {
    question_code: string;
    count: number;
    interviews?: number;
    grave?: number;
    top_category?: string;
  }[];
  score_histogram: { bucket: string; count: number }[];
  recent_activity: Activity[];
  questionnaire: Questionnaire | null;
  management_recommendations?: ManagementRecommendation[];
}

// Recommandation agrégée pour la direction : question récurrente à revoir.
export interface ManagementRecommendation {
  question_code: string;
  question_text: string;
  occurrences: number;
  interviews: number;
  grave: number;
  common_issue: string;
  recommendations: string[];
}

// --------------------------------------------------------------------------
// Rapports
// --------------------------------------------------------------------------
export type ReportScope = "interview" | "interviewer" | "global";

export interface Report {
  id: number;
  title: string;
  scope: ReportScope;
  format: "pdf" | "excel";
  interview_id: number | null;
  post_number: string | null;
  stored_name: string;
  size: number;
  created_at: string;
}

// --------------------------------------------------------------------------
// Auth & admin
// --------------------------------------------------------------------------
export type Role =
  | "super_admin"
  | "admin"
  | "quality_manager"
  | "supervisor"
  | "viewer";

export interface User {
  id: number;
  name: string;
  email: string;
  role: Role | string;
  status: string;
  permissions: string[];
  last_login: string | null;
  created_at: string;
}

export interface TokenResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  user: User;
}

// Libellés français des catégories d'anomalies.
export const CATEGORY_LABELS: Record<string, string> = {
  question_skipped: "Question sautée",
  question_not_asked_but_answered: "Réponse sans question posée",
  wrong_recording: "Mauvais enregistrement",
  answer_mismatch: "Réponse ≠ propos du répondant",
  missing_mandatory: "Obligatoire manquante",
  routing_violation: "Routage non respecté",
  wording_deviation: "Question reformulée",
  leading_question: "Question orientée",
  respondent_influence: "Influence sur le répondant",
  misinterpretation: "Mauvaise interprétation",
  inconsistent_answers: "Réponses incohérentes",
  data_entry_error: "Erreur de saisie",
  timing_anomaly: "Durée anormale",
  suspected_fabrication: "Suspicion de fabrication",
  duplicate_verbatim: "Verbatim dupliqué",
  unprofessional_conduct: "Conduite non professionnelle",
  transcript_missing: "Transcription absente",
  inadequate_probing: "Relance insuffisante",
};

// Recommandations pour la direction, par type d'anomalie (miroir backend).
const MANAGER_ADVICE: Record<string, string[]> = {
  answer_mismatch: [
    "Réexaminer la formulation de la question {code} : des réponses enregistrées contredisent les propos réels des répondants.",
    "Vérifier que les options de réponse de {code} représentent correctement les opinions exprimées.",
    "Renforcer la formation des enquêteurs sur la saisie fidèle des réponses à cette question.",
  ],
  inconsistent_answers: [
    "Contrôler la cohérence des questions liées à {code} (filtres, échelles, questions miroirs).",
  ],
  wrong_recording: [
    "Vérifier la clarté des options de la question {code} : les enquêteurs saisissent des réponses déformées.",
    "Ajouter une consigne enquêteur expliquant comment enregistrer les réponses ambiguës.",
  ],
  misinterpretation: [
    "La question {code} est interprétée différemment de l'intention : envisager de simplifier la formulation.",
    "Ajouter une consigne enquêteur expliquant comment poser et coder cette question.",
  ],
  data_entry_error: [
    "Contrôler le masque de saisie de la question {code} et prévoir un contrôle de cohérence.",
  ],
  routing_violation: [
    "Vérifier la condition de routage de la question {code} dans le questionnaire .LSS.",
    "Des répondants atteignent cette question sans satisfaire les critères prévus : revoir la logique de saut.",
  ],
  question_skipped: [
    "Vérifier pourquoi la question {code} n'est pas posée : routage trop restrictif ou consigne manquante.",
    "Revoir la logique de saut qui précède cette question dans le .LSS.",
  ],
  missing_mandatory: [
    "La question obligatoire {code} reste sans réponse : vérifier sa formulation et sa position dans le parcours.",
  ],
  leading_question: [
    "Revoir la formulation de la question {code} : les enquêteurs tendent à suggérer la réponse.",
    "Ajouter une consigne enquêteur expliquant comment poser cette question de façon neutre.",
  ],
  wording_deviation: [
    "Les enquêteurs reformulent la question {code} : envisager de simplifier sa formulation.",
    "Ajouter une consigne de lecture exacte pour cette question.",
  ],
  respondent_influence: [
    "Renforcer la formation à la neutralité des enquêteurs concernés (question {code}).",
  ],
  inadequate_probing: [
    "Ajouter des consignes de relance standardisées pour la question ouverte {code}.",
  ],
  unprofessional_conduct: [
    "Prévoir un coaching du poste concerné : ton non professionnel pendant la passation.",
  ],
  timing_anomaly: [
    "Contrôler les entretiens du poste concerné : durées de passation anormales.",
  ],
  duplicate_verbatim: [
    "Déclencher un contrôle qualité renforcé : verbatims identiques entre entretiens (fabrication possible).",
  ],
  suspected_fabrication: [
    "Déclencher un contrôle qualité renforcé sur les postes concernés (entretiens potentiellement fabriqués).",
  ],
  question_not_asked_but_answered: [
    "Une réponse est saisie sans que la question {code} ait été posée : contrôler la passation et le routage.",
  ],
  transcript_missing: [
    "Vérifier l'export des enregistrements et transcriptions pour couvrir davantage d'entretiens.",
  ],
};

export function managerAdvice(category: string, questionCode?: string | null): string[] {
  const code = questionCode ?? "concernée";
  return (MANAGER_ADVICE[category] ?? []).map((t) => t.replaceAll("{code}", code));
}

export const SEVERITY_LABELS: Record<Severity, string> = {
  low: "Mineure",
  medium: "Moyenne",
  high: "Grave",
  critical: "Critique",
};

export const VERIFICATION_STATUS_LABELS: Record<VerificationStatus, string> = {
  verified: "Vérifiée",
  contradicted: "Contredite",
  not_enough_evidence: "Preuve insuffisante",
};

export const VERDICT_LABELS: Record<Verdict, string> = {
  pass: "Conforme",
  needs_review: "À contrôler",
  fail: "Non conforme",
};
