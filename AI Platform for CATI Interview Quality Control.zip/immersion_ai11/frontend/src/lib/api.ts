import type {
  DashboardData,
  EvaluationDetail,
  EvaluationProgress,
  ImportResult,
  InterviewDetail,
  InterviewerDetail,
  InterviewerSummary,
  InterviewListItem,
  Questionnaire,
  QuestionnaireDetail,
  Report,
  ReportScope,
  TokenResponse,
  User,
} from "./types";

/**
 * Base de l'API.
 *
 * Par défaut : chaîne vide → appels relatifs `/api/*` servis sur la même origine
 * que le frontend et proxyfiés vers le backend par Next.js (voir next.config.mjs).
 * Cela élimine les problèmes de CORS, de mixed-content et d'URL mal configurée.
 *
 * `NEXT_PUBLIC_API_URL` reste possible pour pointer vers un backend distinct ;
 * on neutralise alors les erreurs classiques : slash final et `/api` en trop
 * (qui produisaient des appels `/api/api/...` → 404 « Not Found »).
 */
function resolveApiBase(): string {
  const raw = process.env.NEXT_PUBLIC_API_URL;
  if (!raw) return ""; // même origine + proxy Next.js
  return raw.replace(/\/+$/, "").replace(/\/api$/i, "");
}

export const API_URL = resolveApiBase();

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

// --------------------------------------------------------------------------- #
// Gestion des jetons (localStorage)
// --------------------------------------------------------------------------- #
const ACCESS_KEY = "imm_access_token";
const REFRESH_KEY = "imm_refresh_token";

export const tokenStore = {
  access: () => (typeof window === "undefined" ? null : localStorage.getItem(ACCESS_KEY)),
  refresh: () =>
    typeof window === "undefined" ? null : localStorage.getItem(REFRESH_KEY),
  set: (access: string, refresh: string) => {
    localStorage.setItem(ACCESS_KEY, access);
    localStorage.setItem(REFRESH_KEY, refresh);
  },
  clear: () => {
    localStorage.removeItem(ACCESS_KEY);
    localStorage.removeItem(REFRESH_KEY);
  },
};

/** Callback déclenché quand la session expire définitivement (→ redirection login). */
let onSessionExpired: (() => void) | null = null;
export function setOnSessionExpired(cb: () => void) {
  onSessionExpired = cb;
}

async function tryRefresh(): Promise<boolean> {
  const refresh = tokenStore.refresh();
  if (!refresh) return false;
  try {
    const res = await fetch(`${API_URL}/api/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: refresh }),
    });
    if (!res.ok) return false;
    const data = await res.json();
    tokenStore.set(data.access_token, data.refresh_token);
    return true;
  } catch {
    return false;
  }
}

/** Transforme le `detail` d'une erreur FastAPI en message lisible. */
function parseDetail(data: unknown, fallback: string): string {
  if (!data || typeof data !== "object") return fallback;
  const detail = (data as { detail?: unknown }).detail;
  if (typeof detail === "string") return detail;
  // Erreurs de validation 422 → liste d'objets {loc, msg}
  if (Array.isArray(detail)) {
    const msgs = detail
      .map((d) => {
        if (d && typeof d === "object" && "msg" in d) {
          const loc = Array.isArray((d as any).loc)
            ? (d as any).loc.filter((x: unknown) => x !== "body").join(".")
            : "";
          return loc ? `${loc} : ${(d as any).msg}` : String((d as any).msg);
        }
        return String(d);
      })
      .filter(Boolean);
    if (msgs.length) return msgs.join(" · ");
  }
  return fallback;
}

function buildHeaders(options: RequestInit): HeadersInit {
  const isForm = options.body instanceof FormData;
  const headers: Record<string, string> = isForm
    ? {}
    : { "Content-Type": "application/json" };
  const token = tokenStore.access();
  if (token) headers["Authorization"] = `Bearer ${token}`;
  return { ...headers, ...((options.headers as Record<string, string>) || {}) };
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  isRetry = false,
): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_URL}${path}`, { ...options, headers: buildHeaders(options) });
  } catch {
    // fetch ne rejette que sur erreur réseau (backend injoignable, CORS, DNS…)
    throw new ApiError(
      `Impossible de joindre l'API${API_URL ? ` à ${API_URL}` : ""}. Vérifiez que le backend FastAPI est démarré et accessible.`,
      0,
    );
  }

  // Jeton expiré → tentative de rafraîchissement unique, puis rejeu.
  if (res.status === 401 && !isRetry && !path.startsWith("/api/auth/")) {
    if (await tryRefresh()) {
      return request<T>(path, options, true);
    }
    tokenStore.clear();
    onSessionExpired?.();
    throw new ApiError("Session expirée. Veuillez vous reconnecter.", 401);
  }

  if (!res.ok) {
    let detail = `Erreur ${res.status}`;
    try {
      detail = parseDetail(await res.json(), detail);
    } catch {
      /* corps non-JSON */
    }
    throw new ApiError(detail, res.status);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export const api = {
  // Auth
  login: (email: string, password: string) =>
    request<TokenResponse>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),
  me: () => request<User>("/api/auth/me"),
  logout: () => request<{ status: string }>("/api/auth/logout", { method: "POST" }),

  // Dashboard direction
  dashboard: () => request<DashboardData>("/api/dashboard"),

  // Questionnaires (.LSS) & imports de données
  listQuestionnaires: () => request<Questionnaire[]>("/api/questionnaires"),
  getQuestionnaire: (id: number) =>
    request<QuestionnaireDetail>(`/api/questionnaires/${id}`),
  importLss: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<QuestionnaireDetail>("/api/questionnaires/import-lss", {
      method: "POST",
      body: form,
    });
  },
  importInterviews: (questionnaireId: number, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<ImportResult>(
      `/api/questionnaires/${questionnaireId}/import-interviews`,
      { method: "POST", body: form },
    );
  },
  importTranscripts: (questionnaireId: number, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<ImportResult>(
      `/api/questionnaires/${questionnaireId}/import-transcripts`,
      { method: "POST", body: form },
    );
  },
  deleteQuestionnaire: (id: number) =>
    request<void>(`/api/questionnaires/${id}`, { method: "DELETE" }),

  // Entretiens
  listInterviews: (params?: {
    questionnaire_id?: number;
    post_number?: string;
    verdict?: string;
    search?: string;
  }) => {
    const q = new URLSearchParams();
    if (params?.questionnaire_id) q.set("questionnaire_id", String(params.questionnaire_id));
    if (params?.post_number) q.set("post_number", params.post_number);
    if (params?.verdict) q.set("verdict", params.verdict);
    if (params?.search) q.set("search", params.search);
    const qs = q.toString();
    return request<InterviewListItem[]>(`/api/interviews${qs ? `?${qs}` : ""}`);
  },
  getInterview: (id: number) => request<InterviewDetail>(`/api/interviews/${id}`),
  deleteInterview: (id: number) =>
    request<void>(`/api/interviews/${id}`, { method: "DELETE" }),
  evaluateInterview: (id: number) =>
    request<EvaluationDetail>(`/api/interviews/${id}/evaluate`, { method: "POST" }),
  evaluateAll: (questionnaireId?: number) =>
    request<{ status: string; interviews: number }>(
      `/api/interviews/evaluate-all${questionnaireId ? `?questionnaire_id=${questionnaireId}` : ""}`,
      { method: "POST", body: JSON.stringify({}) },
    ),
  evaluationProgress: () =>
    request<EvaluationProgress>("/api/interviews/evaluations/progress"),

  // Enquêteurs CATI (Post) — lecture seule, détectés automatiquement
  listInterviewers: () => request<InterviewerSummary[]>("/api/interviewers"),
  getInterviewer: (postNumber: string) =>
    request<InterviewerDetail>(`/api/interviewers/${encodeURIComponent(postNumber)}`),

  // Rapports
  listReports: () => request<Report[]>("/api/reports"),
  createReport: (payload: {
    scope: ReportScope;
    format: "pdf" | "excel";
    interview_id?: number;
    post_number?: string;
  }) =>
    request<Report>("/api/reports", { method: "POST", body: JSON.stringify(payload) }),
  deleteReport: (id: number) => request<void>(`/api/reports/${id}`, { method: "DELETE" }),
  reportDownloadUrl: (id: number) => `${API_URL}/api/reports/${id}/download`,

  // Admin
  listUsers: () => request<User[]>("/api/admin/users"),
  createUser: (body: { name: string; email: string; role: string }) =>
    request<User>("/api/admin/users", { method: "POST", body: JSON.stringify(body) }),
  updateUser: (id: number, body: Partial<User>) =>
    request<User>(`/api/admin/users/${id}`, { method: "PATCH", body: JSON.stringify(body) }),
  deleteUser: (id: number) => request<void>(`/api/admin/users/${id}`, { method: "DELETE" }),
  createUserFull: (body: { name: string; email: string; role: string; password: string }) =>
    request<User>("/api/admin/users", { method: "POST", body: JSON.stringify(body) }),
  resetPassword: (id: number, password: string) =>
    request<User>(`/api/admin/users/${id}/reset-password`, {
      method: "POST",
      body: JSON.stringify({ password }),
    }),
  disableUser: (id: number) =>
    request<User>(`/api/admin/users/${id}/disable`, { method: "POST" }),
  enableUser: (id: number) =>
    request<User>(`/api/admin/users/${id}/enable`, { method: "POST" }),
  listRoles: () =>
    request<{ role: string; label: string; permissions: string[] }[]>("/api/admin/roles"),
  getSettings: () =>
    request<{ key: string; value: Record<string, unknown> }>("/api/admin/settings"),
  updateSettings: (value: Record<string, unknown>) =>
    request<{ key: string; value: Record<string, unknown> }>("/api/admin/settings", {
      method: "PUT",
      body: JSON.stringify({ value }),
    }),
  systemInfo: () =>
    request<{ ai_engine: string; model: string; version: string }>("/api/admin/system"),
};
