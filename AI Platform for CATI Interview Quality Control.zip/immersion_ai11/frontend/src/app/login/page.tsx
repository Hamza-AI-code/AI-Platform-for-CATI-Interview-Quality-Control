"use client";

import { motion } from "framer-motion";
import {
  ArrowRight,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  Mail,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";

const highlights = [
  "Analyse IA questionnaire ↔ réponses ↔ transcription",
  "Détection de fraude en temps réel",
  "Reporting professionnel PDF & Excel",
];

export default function LoginPage() {
  const { login, user, loading } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Déjà connecté → dashboard.
  useEffect(() => {
    if (!loading && user) router.replace("/");
  }, [user, loading, router]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await login(email, password);
      toast.success("Connexion réussie");
      router.replace("/");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Échec de la connexion");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background p-4">
      {/* Fond animé */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -left-20 -top-20 h-[34rem] w-[34rem] rounded-full bg-primary/25 blur-[120px]" />
        <div className="absolute -bottom-32 -right-20 h-[34rem] w-[34rem] rounded-full bg-fuchsia-500/20 blur-[120px]" />
        <div className="absolute inset-0 bg-grid-pattern bg-[size:36px_36px] opacity-[0.15]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative grid w-full max-w-4xl overflow-hidden rounded-3xl border border-border/60 bg-card/70 shadow-2xl backdrop-blur-2xl lg:grid-cols-2"
      >
        {/* Panneau gauche — branding */}
        <div className="relative hidden flex-col justify-between gradient-brand p-10 text-white lg:flex">
          <div className="absolute inset-0 bg-grid-pattern bg-[size:28px_28px] opacity-10" />
          <div className="relative">
            <div className="flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15 backdrop-blur">
                <Sparkles className="h-6 w-6" />
              </span>
              <div>
                <p className="text-lg font-bold leading-tight">Immersion AI</p>
                <p className="text-xs text-white/70">Quality Control Suite</p>
              </div>
            </div>
            <h2 className="mt-12 text-3xl font-bold leading-tight">
              La plateforme de contrôle qualité des enquêteurs CATI.
            </h2>
            <p className="mt-3 text-sm text-white/80">
              Comparez questionnaire, réponses enregistrées et transcriptions
              d'appels grâce à l'intelligence artificielle.
            </p>
          </div>
          <div className="relative space-y-3">
            {highlights.map((h, i) => (
              <motion.div
                key={h}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + i * 0.12 }}
                className="flex items-center gap-2.5 text-sm text-white/90"
              >
                <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-300" />
                {h}
              </motion.div>
            ))}
          </div>
        </div>

        {/* Panneau droit — formulaire */}
        <div className="flex flex-col justify-center p-8 sm:p-10">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl gradient-brand">
              <Sparkles className="h-5 w-5 text-white" />
            </span>
            <p className="text-lg font-bold">
              Immerssion <span className="gradient-text">AI</span>
            </p>
          </div>

          <h1 className="text-2xl font-bold tracking-tight">Bienvenue 👋</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Connectez-vous à votre espace de contrôle qualité.
          </p>

          <form onSubmit={handleSubmit} className="mt-7 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="vous@entreprise.com"
                  className="pl-9"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="password">Mot de passe</Label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="password"
                  type={show ? "text" : "password"}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="px-9"
                />
                <button
                  type="button"
                  onClick={() => setShow((s) => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={show ? "Masquer" : "Afficher"}
                >
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Button type="submit" size="lg" className="w-full" disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Connexion…
                </>
              ) : (
                <>
                  Se connecter <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </form>

          <div className="mt-6 rounded-xl border border-border/60 bg-muted/40 p-3.5 text-xs text-muted-foreground">
            <p className="font-medium text-foreground/80">Compte de démonstration</p>
            <p className="mt-1">
              Email : <code className="text-foreground">admin@immerssion.ai</code> ·
              Mot de passe : <code className="text-foreground">Admin123!</code>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
