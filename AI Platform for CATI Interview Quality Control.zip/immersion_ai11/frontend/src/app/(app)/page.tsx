"use client";

import Link from "next/link";
import {
  AlertTriangle,
  BrainCircuit,
  ClipboardList,
  FileSpreadsheet,
  Headset,
  Link2,
  ShieldCheck,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ActivityFeed } from "@/components/dashboard/activity-feed";
import {
  ErrorDistributionChart,
  ProblemQuestionsChart,
  ScoreHistogramChart,
} from "@/components/dashboard/charts";
import { StatCard } from "@/components/dashboard/stat-card";
import { PageHeader } from "@/components/shared/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { useDashboard } from "@/hooks/use-dashboard";

export default function DashboardPage() {
  const { data, isLoading } = useDashboard();

  if (isLoading || !data) {
    return (
      <div className="space-y-6">
        <PageHeader title="Tableau de bord" description="Qualité des enquêteurs CATI" />
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-2xl" />
          ))}
        </div>
        <Skeleton className="h-96 rounded-2xl" />
      </div>
    );
  }

  const noData = data.total_interviews === 0;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Tableau de bord"
        description={
          data.questionnaire
            ? `Projet : ${data.questionnaire.title}`
            : "Importez vos données pour démarrer l'analyse"
        }
      />

      {noData ? (
        <EmptyState
          icon={FileSpreadsheet}
          title="Aucune donnée importée"
          description="Importez le questionnaire .LSS, le fichier Excel des entretiens puis les transcriptions."
          action={
            <Link
              href="/upload"
              className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
            >
              Importer les données
            </Link>
          }
        />
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <StatCard
              index={0}
              label="Entretiens"
              value={String(data.total_interviews)}
              hint={`${data.evaluated_interviews} évalué(s)`}
              icon={BrainCircuit}
            />
            <StatCard
              index={1}
              label="Enquêteurs CATI"
              value={String(data.total_interviewers)}
              hint="Postes détectés automatiquement"
              icon={Headset}
              accent="sky"
            />
            <StatCard
              index={2}
              label="Score moyen"
              value={data.avg_score != null ? `${data.avg_score}/100` : "—"}
              hint={data.pass_rate != null ? `${data.pass_rate}% conformes` : undefined}
              icon={ShieldCheck}
              accent="success"
            />
            <StatCard
              index={3}
              label="Anomalies graves"
              value={String(data.critical_findings)}
              hint={`${data.transcripts_linked} transcriptions liées${data.transcripts_orphaned ? ` · ${data.transcripts_orphaned} orphelines` : ""}`}
              icon={AlertTriangle}
              accent="destructive"
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Classement des enquêteurs CATI</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rang</TableHead>
                    <TableHead>Poste</TableHead>
                    <TableHead className="text-right">Entretiens</TableHead>
                    <TableHead className="text-right">Score moyen</TableHead>
                    <TableHead className="text-right">Erreurs graves</TableHead>
                    <TableHead className="text-right">Erreurs mineures</TableHead>
                    <TableHead className="text-right">Conformité</TableHead>
                    <TableHead className="text-right">Risque fraude</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.interviewers.map((it) => (
                    <TableRow key={it.post_number}>
                      <TableCell className="font-medium">{it.rank ?? "—"}</TableCell>
                      <TableCell>
                        <Link
                          href={`/interviewers/${encodeURIComponent(it.post_number)}`}
                          className="font-semibold text-primary hover:underline"
                        >
                          Poste {it.post_number}
                        </Link>
                      </TableCell>
                      <TableCell className="text-right tabular-nums">{it.interviews}</TableCell>
                      <TableCell className="text-right font-semibold tabular-nums">
                        {it.avg_score != null ? `${it.avg_score}` : "—"}
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-destructive">
                        {it.critical_errors}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">{it.minor_errors}</TableCell>
                      <TableCell className="text-right tabular-nums">
                        {it.accuracy_pct != null ? `${it.accuracy_pct}%` : "—"}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {it.fraud_risk != null ? `${it.fraud_risk}` : "—"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <div className="grid gap-6 xl:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Distribution des scores</CardTitle>
              </CardHeader>
              <CardContent>
                <ScoreHistogramChart data={data.score_histogram} />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Anomalies par type</CardTitle>
              </CardHeader>
              <CardContent>
                {data.error_distribution.length ? (
                  <ErrorDistributionChart data={data.error_distribution} />
                ) : (
                  <p className="py-10 text-center text-sm text-muted-foreground">
                    Aucune anomalie détectée pour le moment
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 xl:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Questions les plus problématiques</CardTitle>
              </CardHeader>
              <CardContent>
                {data.problem_questions.length ? (
                  <ProblemQuestionsChart data={data.problem_questions} />
                ) : (
                  <p className="py-10 text-center text-sm text-muted-foreground">
                    Lancez l'évaluation pour identifier les questions à risque
                  </p>
                )}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Activité récente</CardTitle>
              </CardHeader>
              <CardContent>
                <ActivityFeed activities={data.recent_activity} />
              </CardContent>
            </Card>
          </div>

          {(data.management_recommendations?.length ?? 0) > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ClipboardList className="h-5 w-5 text-primary" />
                  Recommandations pour la direction
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Questions récurrentes à revoir (formulation, options, routage, formation) —
                  agrégées sur l&apos;ensemble des entretiens évalués.
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                {data.management_recommendations!.map((m) => (
                  <div
                    key={m.question_code}
                    className="rounded-2xl border border-border/70 bg-card/60 p-4"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant="outline" className="font-mono text-[11px]">
                        Question {m.question_code}
                      </Badge>
                      <span className="text-sm font-medium">
                        {m.occurrences} anomalie(s) dans {m.interviews} entretien(s)
                        {m.grave > 0 ? ` · ${m.grave} grave(s)` : ""}
                      </span>
                      <span className="ml-auto text-xs text-muted-foreground">
                        Problème dominant : {m.common_issue}
                      </span>
                    </div>
                    {m.question_text && (
                      <p className="mt-2 text-sm text-muted-foreground" dir="auto">
                        {m.question_text}
                      </p>
                    )}
                    <ul className="mt-2 list-disc space-y-0.5 pl-5 text-sm">
                      {m.recommendations.map((r) => (
                        <li key={r}>{r}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Link2 className="h-3.5 w-3.5" />
            Liaison entretiens ↔ transcriptions par Session Code ·{" "}
            {data.transcripts_linked} liée(s), {data.transcripts_orphaned} orpheline(s)
          </div>
        </>
      )}
    </div>
  );
}
