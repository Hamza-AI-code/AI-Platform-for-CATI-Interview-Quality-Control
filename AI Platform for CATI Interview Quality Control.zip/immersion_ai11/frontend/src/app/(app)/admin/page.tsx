"use client";

import {
  BadgeCheck,
  BrainCircuit,
  Cpu,
  KeyRound,
  Lock,
  MoreVertical,
  Plus,
  Power,
  Settings2,
  Shield,
  Trash2,
  UserCog,
  Users,
} from "lucide-react";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/shared/page-header";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  useCreateUser,
  useDeleteUser,
  useResetPassword,
  useRoles,
  useSettings,
  useSystemInfo,
  useToggleUser,
  useUpdateSettings,
  useUsers,
} from "@/hooks/use-admin";
import { ROLE_BADGE, ROLE_LABELS, canManageUsers, useAuth } from "@/lib/auth";
import { formatDateTime } from "@/lib/format";
import { initials } from "@/lib/utils";
import type { User } from "@/lib/types";

const ROLE_DESCRIPTIONS: Record<string, string> = {
  super_admin: "Accès total : utilisateurs, rôles, permissions, rapports, configuration.",
  admin: "Gestion opérationnelle complète + gestion des utilisateurs.",
  quality_manager: "Gestion qualité : enquêteurs, analyses, rapports.",
  supervisor: "Supervision d'équipe : création et suivi des analyses.",
  investigator: "Accès limité : consultation et création de base.",
};

export default function AdminPage() {
  const { user } = useAuth();
  const allowed = canManageUsers(user?.role);
  const { data: users, isLoading } = useUsers(allowed);
  const { data: roles } = useRoles(allowed);
  const { data: settings } = useSettings();
  const { data: system } = useSystemInfo();
  const createUser = useCreateUser();
  const deleteUser = useDeleteUser();
  const resetPw = useResetPassword();
  const toggleUser = useToggleUser();
  const updateSettings = useUpdateSettings();

  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", role: "investigator", password: "" });
  const [resetFor, setResetFor] = useState<User | null>(null);
  const [newPw, setNewPw] = useState("");
  const [aiForm, setAiForm] = useState<Record<string, unknown>>({});

  useEffect(() => {
    if (settings?.value) setAiForm(settings.value);
  }, [settings]);

  const setAi = (k: string, v: unknown) => setAiForm((p) => ({ ...p, [k]: v }));

  return (
    <div>
      <PageHeader
        title="Centre d'administration"
        description="Gérez les utilisateurs, les rôles et les paramètres de l'intelligence artificielle."
        icon={Settings2}
      />

      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users">
            <Users className="h-4 w-4" /> Utilisateurs
          </TabsTrigger>
          <TabsTrigger value="roles">
            <Shield className="h-4 w-4" /> Rôles
          </TabsTrigger>
          <TabsTrigger value="ai">
            <BrainCircuit className="h-4 w-4" /> Paramètres IA
          </TabsTrigger>
        </TabsList>

        {/* Users */}
        <TabsContent value="users">
          {!allowed ? (
            <Card>
              <CardContent className="flex flex-col items-center gap-3 py-16 text-center">
                <Lock className="h-10 w-10 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Accès réservé aux administrateurs. Votre rôle (
                  <strong>{ROLE_LABELS[user?.role ?? ""] ?? user?.role}</strong>) ne
                  permet pas la gestion des utilisateurs.
                </p>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader className="flex-row items-center justify-between">
                <div>
                  <CardTitle>Utilisateurs</CardTitle>
                  <CardDescription>{users?.length ?? 0} utilisateur(s)</CardDescription>
                </div>
                <Button onClick={() => setOpen(true)}>
                  <Plus className="h-4 w-4" /> Ajouter
                </Button>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Skeleton key={i} className="h-16" />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {users?.map((u) => (
                      <div
                        key={u.id}
                        className="flex items-center gap-4 rounded-xl border border-border/50 px-4 py-3 transition-colors hover:bg-muted/40"
                      >
                        <Avatar>
                          <AvatarFallback className="gradient-brand text-xs text-white">
                            {initials(u.name.split(" ")[0], u.name.split(" ")[1])}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium">
                            {u.name}
                            {u.id === user?.id && (
                              <span className="ml-2 text-xs text-muted-foreground">(vous)</span>
                            )}
                          </p>
                          <p className="truncate text-xs text-muted-foreground">
                            {u.email}
                            {u.last_login && ` · vu ${formatDateTime(u.last_login)}`}
                          </p>
                        </div>
                        {u.status === "disabled" && (
                          <Badge variant="destructive">Désactivé</Badge>
                        )}
                        <Badge variant={ROLE_BADGE[u.role] ?? "secondary"}>
                          {ROLE_LABELS[u.role] ?? u.role}
                        </Badge>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon-sm">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => {
                                setResetFor(u);
                                setNewPw("");
                              }}
                            >
                              <KeyRound className="h-4 w-4" /> Réinitialiser le mot de passe
                            </DropdownMenuItem>
                            {u.id !== user?.id && (
                              <DropdownMenuItem
                                onClick={() =>
                                  toggleUser.mutate({
                                    id: u.id,
                                    enable: u.status !== "active",
                                  })
                                }
                              >
                                <Power className="h-4 w-4" />
                                {u.status === "active" ? "Désactiver" : "Réactiver"}
                              </DropdownMenuItem>
                            )}
                            {u.id !== user?.id && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  className="text-destructive focus:text-destructive"
                                  onClick={() => deleteUser.mutate(u.id)}
                                >
                                  <Trash2 className="h-4 w-4" /> Supprimer
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Roles */}
        <TabsContent value="roles">
          <div className="grid gap-4 md:grid-cols-2">
            {(roles ?? []).map((r) => (
              <Card key={r.role}>
                <CardContent className="flex items-start gap-4 p-5">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <UserCog className="h-5 w-5" />
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-semibold">{r.label}</h4>
                      <Badge variant={ROLE_BADGE[r.role] ?? "secondary"}>{r.role}</Badge>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {ROLE_DESCRIPTIONS[r.role] ?? r.permissions.join(", ")}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {r.permissions.map((p) => (
                        <span
                          key={p}
                          className="rounded-md bg-muted px-1.5 py-0.5 text-[11px] text-muted-foreground"
                        >
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            {!roles?.length && (
              <Card>
                <CardContent className="py-12 text-center text-sm text-muted-foreground">
                  {allowed ? "Aucun rôle." : "Accès réservé aux administrateurs."}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* AI Settings */}
        <TabsContent value="ai">
          <div className="grid gap-5 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Paramètres du moteur d'analyse</CardTitle>
                <CardDescription>
                  Ajustez les seuils de détection et le comportement de l'IA.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label>Moteur</Label>
                    <Select
                      value={String(aiForm.engine ?? "auto")}
                      onValueChange={(v) => setAi("engine", v)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="auto">Automatique</SelectItem>
                        <SelectItem value="ollama">Ollama (local)</SelectItem>
                        <SelectItem value="heuristic">Heuristique</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Modèle</Label>
                    <Input
                      value={String(aiForm.model ?? "")}
                      onChange={(e) => setAi("model", e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Seuil de qualité ({String(aiForm.quality_threshold ?? 60)}%)</Label>
                    <Input
                      type="range"
                      min={0}
                      max={100}
                      value={Number(aiForm.quality_threshold ?? 60)}
                      onChange={(e) => setAi("quality_threshold", Number(e.target.value))}
                      className="cursor-pointer accent-primary"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Seuil de fraude ({String(aiForm.fraud_threshold ?? 45)}%)</Label>
                    <Input
                      type="range"
                      min={0}
                      max={100}
                      value={Number(aiForm.fraud_threshold ?? 45)}
                      onChange={(e) => setAi("fraud_threshold", Number(e.target.value))}
                      className="cursor-pointer accent-primary"
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between rounded-xl border border-border/60 px-4 py-3">
                  <div>
                    <p className="text-sm font-medium">Alertes automatiques</p>
                    <p className="text-xs text-muted-foreground">
                      Créer une alerte quand le score de fraude dépasse le seuil.
                    </p>
                  </div>
                  <Switch
                    checked={Boolean(aiForm.auto_alert ?? true)}
                    onCheckedChange={(v) => setAi("auto_alert", v)}
                  />
                </div>
                <Button
                  disabled={updateSettings.isPending || !allowed}
                  onClick={() => updateSettings.mutate(aiForm)}
                >
                  <BadgeCheck className="h-4 w-4" /> Enregistrer les paramètres
                </Button>
                {!allowed && (
                  <p className="text-xs text-muted-foreground">
                    Seuls les administrateurs peuvent modifier ces paramètres.
                  </p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Cpu className="h-5 w-5 text-primary" /> Système
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Moteur actif</span>
                  <Badge variant={system?.ai_engine === "ollama" ? "default" : "secondary"}>
                    {system?.ai_engine === "ollama" ? "Ollama (local)" : "Heuristique"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Modèle</span>
                  <span className="text-sm font-medium">{system?.model}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Version API</span>
                  <span className="text-sm font-medium">{system?.version}</span>
                </div>
                <div className="rounded-xl bg-primary/5 p-4 text-xs text-muted-foreground">
                  Le moteur heuristique fonctionne sans clé API. Pour activer l'analyse
                  sémantique avancée, installez Ollama et un modèle (<code>ollama pull</code>) côté
                  serveur.
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Add user dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Nouvel utilisateur</DialogTitle>
            <DialogDescription>
              Créez un compte et attribuez-lui un rôle. Un mot de passe est requis pour
              la connexion.
            </DialogDescription>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={async (e) => {
              e.preventDefault();
              await createUser.mutateAsync(form);
              setForm({ name: "", email: "", role: "investigator", password: "" });
              setOpen(false);
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="name">Nom complet</Label>
              <Input
                id="name"
                required
                value={form.name}
                onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="uemail">Email</Label>
              <Input
                id="uemail"
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="upw">Mot de passe</Label>
              <Input
                id="upw"
                type="password"
                required
                minLength={6}
                value={form.password}
                onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
                placeholder="6 caractères minimum"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Rôle</Label>
              <Select
                value={form.role}
                onValueChange={(v) => setForm((p) => ({ ...p, role: v }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(ROLE_LABELS).map(([value, label]) => (
                    <SelectItem key={value} value={value}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                Annuler
              </Button>
              <Button type="submit" disabled={createUser.isPending}>
                Créer l'utilisateur
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Reset password dialog */}
      <Dialog open={!!resetFor} onOpenChange={(v) => !v && setResetFor(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Réinitialiser le mot de passe</DialogTitle>
            <DialogDescription>
              Définissez un nouveau mot de passe pour <strong>{resetFor?.name}</strong>.
            </DialogDescription>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={async (e) => {
              e.preventDefault();
              if (resetFor) await resetPw.mutateAsync({ id: resetFor.id, password: newPw });
              setResetFor(null);
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="npw">Nouveau mot de passe</Label>
              <Input
                id="npw"
                type="password"
                required
                minLength={6}
                value={newPw}
                onChange={(e) => setNewPw(e.target.value)}
                placeholder="6 caractères minimum"
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setResetFor(null)}>
                Annuler
              </Button>
              <Button type="submit" disabled={resetPw.isPending}>
                Réinitialiser
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
