"use client";

import { Download, FileSpreadsheet, FileText, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useCreateReport, useDeleteReport, useReports } from "@/hooks/use-reports";
import { api } from "@/lib/api";
import { formatBytes, formatDateTime } from "@/lib/format";

const SCOPE_LABEL: Record<string, string> = {
  interview: "Entretien",
  interviewer: "Enquêteur",
  global: "Direction",
};

export default function ReportsPage() {
  const { data: reports, isLoading } = useReports();
  const createReport = useCreateReport();
  const deleteReport = useDeleteReport();

  return (
    <div className="space-y-6">
      <PageHeader
        title="Rapports"
        description="Exports PDF et Excel : classement des postes, rapports d'entretien et d'enquêteur"
      />

      <Card>
        <CardHeader>
          <CardTitle>Rapport de direction</CardTitle>
          <CardDescription>
            Classement des enquêteurs CATI, statistiques globales et questions les plus
            problématiques. Les rapports par entretien et par poste se génèrent depuis leurs pages
            respectives.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <Button
            onClick={() => createReport.mutate({ scope: "global", format: "pdf" })}
            disabled={createReport.isPending}
          >
            <FileText className="mr-2 h-4 w-4" />
            Générer le PDF
          </Button>
          <Button
            variant="outline"
            onClick={() => createReport.mutate({ scope: "global", format: "excel" })}
            disabled={createReport.isPending}
          >
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            Générer l'Excel
          </Button>
        </CardContent>
      </Card>

      {isLoading ? (
        <Skeleton className="h-72 rounded-2xl" />
      ) : !reports?.length ? (
        <EmptyState
          icon={FileText}
          title="Aucun rapport généré"
          description="Générez un rapport de direction ci-dessus, ou un rapport détaillé depuis un entretien ou un poste."
        />
      ) : (
        <Card>
          <CardContent className="pt-6">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Titre</TableHead>
                  <TableHead>Portée</TableHead>
                  <TableHead>Format</TableHead>
                  <TableHead className="text-right">Taille</TableHead>
                  <TableHead>Créé le</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.title}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{SCOPE_LABEL[r.scope] ?? r.scope}</Badge>
                    </TableCell>
                    <TableCell className="uppercase">{r.format}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatBytes(r.size)}</TableCell>
                    <TableCell>{formatDateTime(r.created_at)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button size="sm" variant="outline" asChild>
                          <a href={api.reportDownloadUrl(r.id)} target="_blank" rel="noreferrer">
                            <Download className="h-4 w-4" />
                          </a>
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteReport.mutate(r.id)}
                          disabled={deleteReport.isPending}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
