"use client";

import { useMemo, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  CheckCircle2,
  FileSpreadsheet,
  FileText,
  Loader2,
  MessagesSquare,
  UploadCloud,
} from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  useEvaluateAll,
  useImportInterviews,
  useImportLss,
  useImportTranscripts,
  useQuestionnaires,
} from "@/hooks/use-data";
import { useDashboard } from "@/hooks/use-dashboard";
import { cn } from "@/lib/utils";

function DropZone({
  accept,
  disabled,
  busy,
  onFile,
  label,
  hint,
}: {
  accept: string;
  disabled?: boolean;
  busy?: boolean;
  onFile: (file: File) => void;
  label: string;
  hint: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  return (
    <div
      className={cn(
        "flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-10 text-center transition-colors",
        dragging ? "border-primary bg-primary/5" : "border-border bg-card/40",
        disabled && "pointer-events-none opacity-50",
      )}
      onClick={() => inputRef.current?.click()}
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        const file = e.dataTransfer.files?.[0];
        if (file) onFile(file);
      }}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onFile(file);
          e.target.value = "";
        }}
      />
      {busy ? (
        <Loader2 className="mb-3 h-9 w-9 animate-spin text-primary" />
      ) : (
        <UploadCloud className="mb-3 h-9 w-9 text-primary" />
      )}
      <p className="text-sm font-medium">{label}</p>
      <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}

export default function UploadPage() {
  const { data: questionnaires } = useQuestionnaires();
  const { data: dashboard } = useDashboard();
  const importLss = useImportLss();
  const importInterviews = useImportInterviews();
  const importTranscripts = useImportTranscripts();
  const evaluateAll = useEvaluateAll();

  const questionnaire = questionnaires?.[0];
  const hasInterviews = (dashboard?.total_interviews ?? 0) > 0;
  const hasTranscripts = (dashboard?.transcripts_linked ?? 0) > 0;

  const steps = useMemo(
    () => [
      { done: Boolean(questionnaire), label: "Questionnaire .LSS" },
      { done: hasInterviews, label: "Entretiens (Excel)" },
      { done: hasTranscripts, label: "Transcriptions (Excel)" },
    ],
    [questionnaire, hasInterviews, hasTranscripts],
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="Import de données"
        description="Trois fichiers suffisent : le questionnaire de référence, les entretiens, les transcriptions. Les enquêteurs CATI sont détectés automatiquement par leur numéro de poste."
      />

      {/* Étapes */}
      <div className="flex flex-wrap items-center gap-3">
        {steps.map((s, i) => (
          <div key={s.label} className="flex items-center gap-3">
            <div
              className={cn(
                "flex items-center gap-2 rounded-full border px-4 py-1.5 text-sm",
                s.done
                  ? "border-success/40 bg-success/10 text-success"
                  : "border-border text-muted-foreground",
              )}
            >
              {s.done ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                <span className="flex h-4 w-4 items-center justify-center rounded-full border text-[10px]">
                  {i + 1}
                </span>
              )}
              {s.label}
            </div>
            {i < steps.length - 1 && <ArrowRight className="h-4 w-4 text-muted-foreground" />}
          </div>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        {/* Étape 1 : LSS */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              1. Questionnaire (.LSS)
            </CardTitle>
            <CardDescription>
              Structure LimeSurvey : questions, options, routage et logique de saut.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <DropZone
              accept=".lss,.xml"
              busy={importLss.isPending}
              onFile={(file) => importLss.mutate(file)}
              label="Déposer le fichier .lss"
              hint="Export LimeSurvey « Structure de questionnaire »"
            />
            {questionnaire && (
              <div className="rounded-xl border border-success/30 bg-success/5 p-3 text-sm">
                <p className="font-medium">{questionnaire.title}</p>
                <p className="text-xs text-muted-foreground">
                  {questionnaire.question_count} questions · langue {questionnaire.language}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Étape 2 : entretiens */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5 text-primary" />
              2. Entretiens (Excel)
            </CardTitle>
            <CardDescription>
              Une ligne par entretien : réponses, Num Poste, Session Code.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <DropZone
              accept=".xlsx,.xlsm"
              disabled={!questionnaire}
              busy={importInterviews.isPending}
              onFile={(file) =>
                questionnaire &&
                importInterviews.mutate({ questionnaireId: questionnaire.id, file })
              }
              label="Déposer le fichier des entretiens"
              hint={questionnaire ? "Export des réponses LimeSurvey (.xlsx)" : "Importez d'abord le .lss"}
            />
            {importInterviews.data && (
              <div className="space-y-1 rounded-xl border border-success/30 bg-success/5 p-3 text-sm">
                <p>
                  {importInterviews.data.created + importInterviews.data.updated} entretien(s)
                  importé(s)
                </p>
                <p className="text-xs text-muted-foreground">
                  Postes détectés :{" "}
                  {importInterviews.data.posts.map((p) => (
                    <Badge key={p} variant="secondary" className="mr-1">
                      Poste {p}
                    </Badge>
                  ))}
                </p>
                {importInterviews.data.unmatched_columns.length > 0 && (
                  <p className="text-xs text-warning">
                    {importInterviews.data.unmatched_columns.length} colonne(s) non reconnue(s)
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Étape 3 : transcriptions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessagesSquare className="h-5 w-5 text-primary" />
              3. Transcriptions (Excel)
            </CardTitle>
            <CardDescription>
              Colonnes SessionCode · Original Name · Transcript — liaison automatique.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <DropZone
              accept=".xlsx,.xlsm"
              disabled={!questionnaire || !hasInterviews}
              busy={importTranscripts.isPending}
              onFile={(file) =>
                questionnaire &&
                importTranscripts.mutate({ questionnaireId: questionnaire.id, file })
              }
              label="Déposer le fichier des transcriptions"
              hint={
                hasInterviews
                  ? "Chaque transcription est liée par Session Code"
                  : "Importez d'abord les entretiens"
              }
            />
            {importTranscripts.data && (
              <div className="rounded-xl border border-success/30 bg-success/5 p-3 text-sm">
                <p>{importTranscripts.data.linked} transcription(s) liée(s)</p>
                {importTranscripts.data.orphaned > 0 && (
                  <p className="text-xs text-warning">
                    {importTranscripts.data.orphaned} sans entretien correspondant
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Lancer l'analyse */}
      <Card>
        <CardContent className="flex flex-col items-start justify-between gap-4 py-6 md:flex-row md:items-center">
          <div>
            <p className="font-medium">Lancer l'analyse qualité</p>
            <p className="text-sm text-muted-foreground">
              Vérifie le routage, compare transcriptions et réponses enregistrées, détecte les
              anomalies et calcule les scores par poste.
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              size="lg"
              disabled={!hasInterviews || evaluateAll.isPending}
              onClick={() => evaluateAll.mutate(questionnaire?.id)}
            >
              {evaluateAll.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Évaluer tous les entretiens
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="/interviews">Voir les entretiens</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
