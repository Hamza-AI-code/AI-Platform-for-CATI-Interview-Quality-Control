"use client";

import { useState } from "react";
import Link from "next/link";
import { BrainCircuit, Loader2, Play, RotateCcw, Search, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { VerdictBadge } from "@/components/shared/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  useDeleteInterview,
  useEvaluateAll,
  useEvaluateInterview,
  useEvaluationProgress,
  useInterviewers,
  useInterviews,
} from "@/hooks/use-data";
import { formatDuration } from "@/lib/format";

export default function InterviewsPage() {
  const [search, setSearch] = useState("");
  const [post, setPost] = useState<string>("all");
  const [verdict, setVerdict] = useState<string>("all");

  const { data: interviews, isLoading } = useInterviews({
    search: search || undefined,
    post_number: post === "all" ? undefined : post,
    verdict: verdict === "all" ? undefined : verdict,
  });
  const { data: interviewers } = useInterviewers();
  const { data: progress } = useEvaluationProgress();
  const evaluateAll = useEvaluateAll();
  const reevaluate = useEvaluateInterview();
  const deleteInterview = useDeleteInterview();
  const [busyId, setBusyId] = useState<number | null>(null);

  const onReevaluate = (id: number, externalId: string) => {
    if (!window.confirm(`Ré-évaluer l'entretien #${externalId} ? L'IA sera appelée à nouveau pour cet entretien.`)) return;
    setBusyId(id);
    reevaluate.mutate(id, { onSettled: () => setBusyId(null) });
  };

  const onDelete = (id: number, externalId: string) => {
    if (
      !window.confirm(
        `Voulez-vous vraiment supprimer l'entretien #${externalId} ?\n\nSon évaluation, ses transcriptions et ses rapports seront également supprimés. Cette action est irréversible.`,
      )
    )
      return;
    setBusyId(id);
    deleteInterview.mutate(id, { onSettled: () => setBusyId(null) });
  };

  const running = (progress?.running ?? 0) > 0;
  const pct =
    progress && progress.total > 0
      ? Math.round((100 * progress.evaluated) / progress.total)
      : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Entretiens"
        description="Chaque ligne du fichier Excel importé, avec son score qualité"
      >
        <Button onClick={() => evaluateAll.mutate(undefined)} disabled={evaluateAll.isPending}>
          {evaluateAll.isPending || running ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Play className="mr-2 h-4 w-4" />
          )}
          Évaluer tout
        </Button>
      </PageHeader>

      {progress && progress.total > 0 && (running || progress.evaluated < progress.total) && (
        <Card>
          <CardContent className="space-y-2 py-4">
            <div className="flex justify-between text-sm">
              <span>
                Évaluation : {progress.evaluated}/{progress.total} entretien(s)
              </span>
              <span className="tabular-nums">{pct}%</span>
            </div>
            <Progress value={pct} />
          </CardContent>
        </Card>
      )}

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="ID réponse ou Session Code…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-64 pl-9"
          />
        </div>
        <Select value={post} onValueChange={setPost}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="Poste" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les postes</SelectItem>
            {interviewers?.map((it) => (
              <SelectItem key={it.post_number} value={it.post_number}>
                Poste {it.post_number}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={verdict} onValueChange={setVerdict}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="Verdict" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les verdicts</SelectItem>
            <SelectItem value="pass">Conforme</SelectItem>
            <SelectItem value="needs_review">À contrôler</SelectItem>
            <SelectItem value="fail">Non conforme</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <Skeleton className="h-96 rounded-2xl" />
      ) : !interviews?.length ? (
        <EmptyState
          icon={BrainCircuit}
          title="Aucun entretien"
          description="Importez le fichier Excel des entretiens depuis la page Import de données."
        />
      ) : (
        <Card>
          <CardContent className="pt-6">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Réponse</TableHead>
                  <TableHead>Session Code</TableHead>
                  <TableHead>Poste</TableHead>
                  <TableHead className="text-right">Durée</TableHead>
                  <TableHead className="text-right">Transcriptions</TableHead>
                  <TableHead className="text-right">Score</TableHead>
                  <TableHead className="text-right">Fraude</TableHead>
                  <TableHead>Verdict</TableHead>
                  <TableHead className="w-20 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {interviews.map((iv) => (
                  <TableRow key={iv.id}>
                    <TableCell>
                      <Link
                        href={`/interviews/${iv.id}`}
                        className="font-medium text-primary hover:underline"
                      >
                        #{iv.external_id}
                      </Link>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{iv.session_code ?? "—"}</TableCell>
                    <TableCell>{iv.post_number ? `Poste ${iv.post_number}` : "—"}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      {iv.duration_sec != null ? formatDuration(iv.duration_sec) : "—"}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{iv.transcript_count}</TableCell>
                    <TableCell className="text-right font-semibold tabular-nums">
                      {iv.quality_score != null ? iv.quality_score : "—"}
                    </TableCell>
                    <TableCell className="text-right tabular-nums">
                      {iv.fraud_risk != null ? iv.fraud_risk : "—"}
                    </TableCell>
                    <TableCell>
                      <VerdictBadge verdict={iv.verdict} />
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          title="Ré-évaluer cet entretien (nouvel appel IA)"
                          disabled={busyId === iv.id}
                          onClick={() => onReevaluate(iv.id, iv.external_id)}
                        >
                          {busyId === iv.id && reevaluate.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <RotateCcw className="h-4 w-4" />
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          title="Supprimer cet entretien"
                          disabled={busyId === iv.id}
                          onClick={() => onDelete(iv.id, iv.external_id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
