"use client";

import Link from "next/link";
import {
  ArrowLeft,
  Download,
  FileWarning,
  Loader2,
  MessagesSquare,
  RefreshCcw,
} from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { ScoreRing } from "@/components/shared/score-ring";
import { SeverityBadge, VerdictBadge } from "@/components/shared/status-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useEvaluateInterview, useInterview, useQuestionnaire } from "@/hooks/use-data";
import { useCreateReport } from "@/hooks/use-reports";
import { formatDateTime, formatDuration } from "@/lib/format";
import { CATEGORY_LABELS, managerAdvice } from "@/lib/types";

export default function InterviewPage({ params }: { params: { id: string } }) {
  const interviewId = Number(params.id);
  const { data: interview, isLoading } = useInterview(interviewId);
  const { data: questionnaire } = useQuestionnaire(interview?.questionnaire_id);
  const evaluate = useEvaluateInterview();
  const createReport = useCreateReport();
  const questionTexts = new Map(
    (questionnaire?.definition?.questions ?? []).map((q) => [q.code, q.text]),
  );

  if (isLoading || !interview) {
    return <Skeleton className="h-[70vh] rounded-2xl" />;
  }

  const ev = interview.evaluation;
  const shownAnswers = Object.entries(interview.answers).filter(([, a]) => a.shown);
  const coverage = ev?.coverage;
  const hasCoverage = coverage != null && coverage.coverage_pct !== undefined;

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Entretien #${interview.external_id}`}
        description={`Poste ${interview.post_number ?? "?"} · Session ${interview.session_code ?? "—"} · ${formatDateTime(interview.submitted_at)}`}
      >
        <Button variant="outline" size="sm" asChild>
          <Link href="/interviews">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour
          </Link>
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() =>
            createReport.mutate({ scope: "interview", format: "pdf", interview_id: interview.id })
          }
          disabled={createReport.isPending}
        >
          <Download className="mr-2 h-4 w-4" />
          PDF
        </Button>
        <Button size="sm" onClick={() => evaluate.mutate(interview.id)} disabled={evaluate.isPending}>
          {evaluate.isPending ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <RefreshCcw className="mr-2 h-4 w-4" />
          )}
          {ev ? "Réévaluer" : "Évaluer"}
        </Button>
      </PageHeader>

      {/* Synthèse */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardContent className="flex flex-col items-center gap-4 py-6">
            {ev?.quality_score != null ? (
              <>
                <ScoreRing value={ev.quality_score} label="Qualité" />
                <VerdictBadge verdict={ev.verdict} />
                <div className="text-center text-sm text-muted-foreground">
                  Risque fraude : <span className="font-semibold">{ev.fraud_risk ?? 0}/100</span>
                  <br />
                  Moteur : {ev.engine === "heuristic" ? "Règles déterministes" : "IA locale (Ollama)"}
                </div>
              </>
            ) : ev?.status === "failed" ? (
              <div className="space-y-2 py-6 text-center">
                <p className="text-sm font-semibold text-destructive">Analyse incomplète</p>
                <p className="text-xs text-muted-foreground">
                  {ev.error ??
                    "L'analyse sémantique n'a pas pu être effectuée — aucun score n'a été calculé."}
                </p>
              </div>
            ) : (
              <p className="py-10 text-sm text-muted-foreground">Pas encore évalué</p>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Synthèse</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            {ev?.summary && <p>{ev.summary}</p>}
            <div className="grid grid-cols-2 gap-3 text-muted-foreground md:grid-cols-4">
              <div>
                <p className="text-xs uppercase">Durée</p>
                <p className="font-medium text-foreground">
                  {interview.duration_sec != null ? formatDuration(interview.duration_sec) : "—"}
                </p>
              </div>
              <div>
                <p className="text-xs uppercase">Réponses saisies</p>
                <p className="font-medium text-foreground">{shownAnswers.length}</p>
              </div>
              <div>
                <p className="text-xs uppercase">Transcriptions</p>
                <p className="font-medium text-foreground">{interview.transcripts.length}</p>
              </div>
              <div>
                <p className="text-xs uppercase">Couverture transcription</p>
                <p className="font-medium text-foreground">
                  {hasCoverage
                    ? `${Math.round(coverage?.coverage_pct ?? 0)}% (${coverage?.evaluable_questions ?? 0}/${coverage?.answered_questions ?? 0} réponses évaluables)`
                    : coverage
                      ? `${coverage.transcribed_segments ?? 0} segment(s) transcrit(s)`
                      : "—"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Anomalies */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileWarning className="h-5 w-5 text-warning" />
            Anomalies détectées {ev ? `(${ev.findings.length})` : ""}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!ev || ev.findings.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              {ev ? "Aucune anomalie détectée — entretien conforme." : "Lancez l'évaluation pour détecter les anomalies."}
            </p>
          ) : (
            ev.findings.map((f) => (
              <div key={f.id} className="rounded-2xl border border-border/70 bg-card/60 p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <SeverityBadge severity={f.severity} />
                  <span className="font-medium">{CATEGORY_LABELS[f.category] ?? f.category}</span>
                  {f.question_code && (
                    <Badge variant="outline" className="font-mono text-[11px]">
                      Question {f.question_code}
                    </Badge>
                  )}
                  <span className="ml-auto text-xs text-muted-foreground">
                    {f.source === "llm" ? "Analyse IA" : "Règle déterministe"} · confiance{" "}
                    {Math.round(f.confidence * 100)}%
                  </span>
                </div>
                {f.question_code && questionTexts.get(f.question_code) && (
                  <p className="mt-2 text-sm text-muted-foreground" dir="auto">
                    {questionTexts.get(f.question_code)}
                  </p>
                )}
                <p className="mt-2 text-sm">{f.explanation}</p>
                {(f.recorded_value || f.expected_value) && (
                  <div className="mt-3 grid gap-2 md:grid-cols-2">
                    {f.recorded_value && (
                      <div className="rounded-xl bg-destructive/8 border border-destructive/20 p-3 text-sm">
                        <p className="text-xs font-semibold uppercase text-destructive">Enregistré</p>
                        <p className="mt-1">{f.recorded_value}</p>
                      </div>
                    )}
                    {f.expected_value && (
                      <div className="rounded-xl bg-success/8 border border-success/20 p-3 text-sm">
                        <p className="text-xs font-semibold uppercase text-success">Attendu</p>
                        <p className="mt-1">{f.expected_value}</p>
                      </div>
                    )}
                  </div>
                )}
                {f.evidence && (
                  <blockquote
                    dir="auto"
                    className="mt-3 rounded-xl border-l-4 border-primary/60 bg-primary/5 p-3 text-sm italic"
                  >
                    « {f.evidence} »
                  </blockquote>
                )}
                {f.recommendation && (
                  <p className="mt-3 text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">Recommandation enquêteur :</span>{" "}
                    {f.recommendation}
                  </p>
                )}
                {managerAdvice(f.category, f.question_code).length > 0 && (
                  <div className="mt-2 text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">Recommandations direction :</span>
                    <ul className="mt-1 list-disc space-y-0.5 pl-5">
                      {managerAdvice(f.category, f.question_code)
                        .slice(0, 3)
                        .map((r) => (
                          <li key={r}>{r}</li>
                        ))}
                    </ul>
                  </div>
                )}
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Transcriptions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessagesSquare className="h-5 w-5 text-primary" />
            Transcriptions ({interview.transcripts.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {interview.transcripts.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              Aucune transcription liée à ce Session Code.
            </p>
          ) : (
            interview.transcripts.map((t) => (
              <div key={t.id}>
                <div className="mb-2 flex items-center gap-2">
                  <Badge variant="secondary" className="font-mono text-[11px]">
                    {t.question_code ?? t.original_name ?? "segment"}
                  </Badge>
                  {t.take_number > 1 && (
                    <span className="text-xs text-muted-foreground">prise {t.take_number}</span>
                  )}
                </div>
                <div className="space-y-2 rounded-2xl border border-border/70 bg-card/60 p-4">
                  {t.turns.length ? (
                    t.turns.map((turn) => (
                      <div key={turn.i} className="flex gap-3 text-sm" dir="auto">
                        <span
                          className={
                            turn.speaker === "A"
                              ? "shrink-0 font-semibold text-primary"
                              : "shrink-0 font-semibold text-success"
                          }
                        >
                          {turn.speaker === "A" ? "Enquêteur" : turn.speaker === "B" ? "Répondant" : turn.speaker}
                        </span>
                        <p>{turn.text}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm" dir="auto">
                      {t.raw_text || "(vide)"}
                    </p>
                  )}
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Réponses enregistrées */}
      <Card>
        <CardHeader>
          <CardTitle>Réponses enregistrées ({shownAnswers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1">
            {shownAnswers.map(([code, a], i) => (
              <div key={code}>
                {i > 0 && <Separator className="my-1" />}
                <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 py-1.5 text-sm">
                  <span className="w-44 shrink-0 font-mono text-xs text-muted-foreground">{code}</span>
                  <span dir="auto">{a.label ?? a.raw ?? "—"}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
