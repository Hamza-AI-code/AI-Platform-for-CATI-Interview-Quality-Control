"use client";

import Link from "next/link";
import { Headset, Info } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ScoreRing } from "@/components/shared/score-ring";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useInterviewers } from "@/hooks/use-data";

export default function InterviewersPage() {
  const { data: interviewers, isLoading } = useInterviewers();

  return (
    <div className="space-y-6">
      <PageHeader
        title="Enquêteurs CATI"
        description="Détectés automatiquement depuis les données importées — identifiés par leur numéro de poste"
      />

      <div className="flex items-start gap-2 rounded-xl border border-border/60 bg-card/40 p-3 text-xs text-muted-foreground">
        <Info className="mt-0.5 h-4 w-4 shrink-0" />
        Aucune saisie manuelle : chaque poste apparaît ici dès qu'il figure dans le fichier Excel
        des entretiens (colonne « Num Poste »).
      </div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-56 rounded-2xl" />
          ))}
        </div>
      ) : !interviewers?.length ? (
        <EmptyState
          icon={Headset}
          title="Aucun enquêteur détecté"
          description="Importez le fichier Excel des entretiens : les postes seront extraits automatiquement."
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {interviewers.map((it) => (
            <Link key={it.post_number} href={`/interviewers/${encodeURIComponent(it.post_number)}`}>
              <Card className="transition-shadow hover:shadow-glow">
                <CardContent className="flex items-center gap-5 py-6">
                  <ScoreRing value={it.avg_score ?? 0} size={104} stroke={9} label="score" />
                  <div className="space-y-1">
                    <p className="text-lg font-bold">Poste {it.post_number}</p>
                    <p className="text-sm text-muted-foreground">
                      {it.interviews} entretien(s) · rang {it.rank ?? "—"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      <span className="font-medium text-destructive">{it.critical_errors}</span>{" "}
                      erreurs graves ·{" "}
                      <span className="font-medium">{it.minor_errors}</span> mineures
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Conformité {it.accuracy_pct ?? "—"}% · fraude {it.fraud_risk ?? "—"}/100
                    </p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
