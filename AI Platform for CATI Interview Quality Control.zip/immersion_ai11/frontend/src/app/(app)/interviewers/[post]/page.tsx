"use client";

import Link from "next/link";
import { ArrowLeft, Download, Lightbulb } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { ErrorDistributionChart, TrendChart } from "@/components/dashboard/charts";
import { ScoreRing } from "@/components/shared/score-ring";
import { VerdictBadge } from "@/components/shared/status-badge";
import { StatCard } from "@/components/dashboard/stat-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AlertTriangle, BrainCircuit, ShieldCheck, Target } from "lucide-react";
import { useInterviewer } from "@/hooks/use-data";
import { useCreateReport } from "@/hooks/use-reports";
import { formatDuration } from "@/lib/format";

export default function InterviewerPage({ params }: { params: { post: string } }) {
  const postNumber = decodeURIComponent(params.post);
  const { data, isLoading } = useInterviewer(postNumber);
  const createReport = useCreateReport();

  if (isLoading || !data) {
    return <Skeleton className="h-[70vh] rounded-2xl" />;
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Poste ${data.post_number}`}
        description={`Enquêteur CATI · rang ${data.rank ?? "—"} · ${data.interviews} entretien(s)`}
      >
        <Button variant="outline" size="sm" asChild>
          <Link href="/interviewers">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour
          </Link>
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() =>
            createReport.mutate({ scope: "interviewer", format: "pdf", post_number: data.post_number })
          }
          disabled={createReport.isPending}
        >
          <Download className="mr-2 h-4 w-4" />
          PDF
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() =>
            createReport.mutate({ scope: "interviewer", format: "excel", post_number: data.post_number })
          }
          disabled={createReport.isPending}
        >
          <Download className="mr-2 h-4 w-4" />
          Excel
        </Button>
      </PageHeader>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StatCard
          index={0}
          label="Entretiens"
          value={String(data.interviews)}
          hint={`${data.evaluated} évalué(s)`}
          icon={BrainCircuit}
        />
        <StatCard
          index={1}
          label="Score moyen"
          value={data.avg_score != null ? `${data.avg_score}/100` : "—"}
          icon={ShieldCheck}
          accent="success"
        />
        <StatCard
          index={2}
          label="Erreurs graves"
          value={String(data.critical_errors)}
          hint={`${data.minor_errors} mineures`}
          icon={AlertTriangle}
          accent="destructive"
        />
        <StatCard
          index={3}
          label="Conformité"
          value={data.accuracy_pct != null ? `${data.accuracy_pct}%` : "—"}
          hint={`Risque fraude ${data.fraud_risk ?? "—"}/100`}
          icon={Target}
          accent="sky"
        />
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-1">
          <CardContent className="flex flex-col items-center gap-3 py-8">
            <ScoreRing value={data.avg_score ?? 0} label="score moyen" />
            <p className="text-sm text-muted-foreground">
              {data.fail_count} non conforme(s) · {data.needs_review_count} à contrôler
            </p>
          </CardContent>
        </Card>
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle>Tendance du score</CardTitle>
          </CardHeader>
          <CardContent>
            {data.trend.length > 1 ? (
              <TrendChart data={data.trend} />
            ) : (
              <p className="py-10 text-center text-sm text-muted-foreground">
                Pas encore assez de données pour une tendance
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Erreurs fréquentes</CardTitle>
          </CardHeader>
          <CardContent>
            {data.error_distribution.length ? (
              <ErrorDistributionChart data={data.error_distribution} />
            ) : (
              <p className="py-10 text-center text-sm text-muted-foreground">Aucune anomalie</p>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-warning" />
              Recommandations IA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {data.recommendations.map((reco, i) => (
                <li key={i} className="flex gap-3 rounded-xl border border-border/60 bg-card/50 p-3 text-sm">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                    {i + 1}
                  </span>
                  {reco}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Entretiens à contrôler en priorité</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Réponse</TableHead>
                <TableHead>Session Code</TableHead>
                <TableHead className="text-right">Durée</TableHead>
                <TableHead className="text-right">Score</TableHead>
                <TableHead>Verdict</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.worst_interviews.map((iv) => (
                <TableRow key={iv.id}>
                  <TableCell>
                    <Link href={`/interviews/${iv.id}`} className="font-medium text-primary hover:underline">
                      #{iv.external_id}
                    </Link>
                  </TableCell>
                  <TableCell className="font-mono text-xs">{iv.session_code ?? "—"}</TableCell>
                  <TableCell className="text-right tabular-nums">
                    {iv.duration_sec != null ? formatDuration(iv.duration_sec) : "—"}
                  </TableCell>
                  <TableCell className="text-right font-semibold tabular-nums">
                    {iv.quality_score ?? "—"}
                  </TableCell>
                  <TableCell>
                    <VerdictBadge verdict={iv.verdict} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
