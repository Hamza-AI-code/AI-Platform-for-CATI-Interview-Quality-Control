import { Badge } from "@/components/ui/badge";
import {
  SEVERITY_LABELS,
  VERDICT_LABELS,
  type Severity,
  type Verdict,
} from "@/lib/types";

const verdictVariant: Record<Verdict, "success" | "warning" | "destructive"> = {
  pass: "success",
  needs_review: "warning",
  fail: "destructive",
};

export function VerdictBadge({ verdict }: { verdict: Verdict | null }) {
  if (!verdict) return <Badge variant="secondary">Non évalué</Badge>;
  return <Badge variant={verdictVariant[verdict]}>{VERDICT_LABELS[verdict]}</Badge>;
}

const severityVariant: Record<Severity, "secondary" | "warning" | "destructive"> = {
  low: "secondary",
  medium: "warning",
  high: "destructive",
  critical: "destructive",
};

export function SeverityBadge({ severity }: { severity: Severity }) {
  return (
    <Badge variant={severityVariant[severity] ?? "secondary"}>
      {SEVERITY_LABELS[severity] ?? severity}
    </Badge>
  );
}

const evalStatus: Record<string, { label: string; variant: "success" | "secondary" | "warning" | "destructive" }> = {
  queued: { label: "En file", variant: "secondary" },
  running: { label: "En cours", variant: "warning" },
  completed: { label: "Évalué", variant: "success" },
  failed: { label: "Échec", variant: "destructive" },
};

export function EvaluationStatusBadge({ status }: { status: string | null }) {
  if (!status) return <Badge variant="secondary">Non évalué</Badge>;
  const s = evalStatus[status] ?? evalStatus.queued;
  return <Badge variant={s.variant}>{s.label}</Badge>;
}
