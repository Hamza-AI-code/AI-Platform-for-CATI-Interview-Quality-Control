"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

type Tone = "quality" | "fraud" | "auto";

function toneColor(value: number, tone: Tone) {
  if (tone === "fraud") {
    if (value >= 70) return "hsl(0 80% 60%)";
    if (value >= 45) return "hsl(25 90% 55%)";
    if (value >= 25) return "hsl(38 92% 50%)";
    return "hsl(152 62% 45%)";
  }
  // quality / auto
  if (value >= 75) return "hsl(152 62% 45%)";
  if (value >= 50) return "hsl(38 92% 50%)";
  return "hsl(0 80% 60%)";
}

export function ScoreRing({
  value,
  tone = "auto",
  size = 132,
  stroke = 11,
  label,
  sublabel,
}: {
  value: number;
  tone?: Tone;
  size?: number;
  stroke?: number;
  label?: string;
  sublabel?: string;
}) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.max(0, Math.min(100, value));
  const offset = circumference - (clamped / 100) * circumference;
  const color = toneColor(clamped, tone);

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="hsl(var(--muted))"
          strokeWidth={stroke}
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.1, ease: "easeOut" }}
          style={{ filter: `drop-shadow(0 0 6px ${color}66)` }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span
          className={cn("text-3xl font-bold tabular-nums")}
          style={{ color }}
        >
          {Math.round(clamped)}
        </span>
        {label && (
          <span className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            {label}
          </span>
        )}
        {sublabel && <span className="text-[11px] text-muted-foreground">{sublabel}</span>}
      </div>
    </div>
  );
}
