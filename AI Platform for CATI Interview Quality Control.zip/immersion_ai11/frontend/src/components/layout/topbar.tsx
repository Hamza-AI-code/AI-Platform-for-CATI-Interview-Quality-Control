"use client";

import { Bell, LogOut, Menu, Search, Sparkles, UserCircle2 } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useDashboard } from "@/hooks/use-dashboard";
import { ROLE_LABELS, useAuth } from "@/lib/auth";
import { relativeTime } from "@/lib/format";
import { cn, initials } from "@/lib/utils";
import { navItems } from "./nav";
import { ThemeToggle } from "./theme-toggle";

const severityColor: Record<string, string> = {
  low: "bg-sky-500",
  medium: "bg-warning",
  high: "bg-orange-500",
  critical: "bg-destructive",
};

export function Topbar() {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { data } = useDashboard();
  const { user, logout } = useAuth();
  const current = navItems.find(
    (i) => i.href === pathname || (i.href !== "/" && pathname.startsWith(i.href)),
  );
  const alerts = data?.recent_activity.filter((a) =>
    ["high", "critical"].includes(a.severity),
  );

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border/60 bg-background/80 px-4 backdrop-blur-xl md:px-6">
      {/* Mobile menu */}
      <Dialog open={mobileOpen} onOpenChange={setMobileOpen}>
        <DialogTrigger asChild>
          <Button variant="ghost" size="icon" className="lg:hidden">
            <Menu className="h-5 w-5" />
          </Button>
        </DialogTrigger>
        <DialogContent className="left-0 top-0 h-full max-w-[280px] translate-x-0 translate-y-0 rounded-none rounded-r-2xl border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left">
          <DialogTitle className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl gradient-brand">
              <Sparkles className="h-5 w-5 text-white" />
            </span>
            Immersion AI
          </DialogTitle>
          <nav className="mt-4 flex flex-col gap-1">
            {navItems.map((item) => {
              const active =
                item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                    active
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-accent",
                  )}
                >
                  <item.icon className="h-5 w-5" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </DialogContent>
      </Dialog>

      <div className="flex flex-col">
        <h1 className="text-base font-semibold leading-tight md:text-lg">
          {current?.label ?? "Tableau de bord"}
        </h1>
        <p className="hidden text-xs text-muted-foreground sm:block">
          {current?.description ?? "Vue d'ensemble"}
        </p>
      </div>

      <div className="ml-auto flex items-center gap-2">
        <div className="relative hidden md:block">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            placeholder="Rechercher…"
            className="h-10 w-44 rounded-xl border border-input bg-card pl-9 pr-3 text-sm outline-none transition-all focus:w-60 focus:ring-2 focus:ring-ring lg:w-56"
          />
        </div>

        <ThemeToggle />

        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="icon" className="relative">
              <Bell className="h-[1.15rem] w-[1.15rem]" />
              {alerts && alerts.length > 0 && (
                <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-white">
                  {alerts.length}
                </span>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel className="flex items-center justify-between">
              Notifications
              <Badge variant="secondary">{data?.recent_activity.length ?? 0}</Badge>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            {data?.recent_activity.length ? (
              data.recent_activity.slice(0, 6).map((a) => (
                <DropdownMenuItem key={a.id} className="flex items-start gap-2.5">
                  <span
                    className={cn(
                      "mt-1.5 h-2 w-2 shrink-0 rounded-full",
                      severityColor[a.severity] ?? "bg-sky-500",
                    )}
                  />
                  <div className="flex flex-col gap-0.5">
                    <span className="text-xs leading-snug">{a.message}</span>
                    <span className="text-[11px] text-muted-foreground">
                      {relativeTime(a.created_at)}
                    </span>
                  </div>
                </DropdownMenuItem>
              ))
            ) : (
              <p className="px-3 py-6 text-center text-xs text-muted-foreground">
                Aucune notification
              </p>
            )}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* User */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 rounded-xl border border-border bg-card py-1 pl-1 pr-2.5 transition-colors hover:bg-accent">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="gradient-brand text-xs text-white">
                  {initials(user?.name?.split(" ")[0], user?.name?.split(" ")[1])}
                </AvatarFallback>
              </Avatar>
              <span className="hidden text-sm font-medium sm:block">
                {user?.name ?? "Utilisateur"}
              </span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-60">
            <DropdownMenuLabel>
              <div className="flex flex-col">
                <span className="text-sm font-medium text-foreground">{user?.name}</span>
                <span className="text-xs font-normal text-muted-foreground">
                  {user?.email}
                </span>
                {user?.role && (
                  <span className="mt-1.5">
                    <Badge variant="secondary">{ROLE_LABELS[user.role] ?? user.role}</Badge>
                  </span>
                )}
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/admin">
                <UserCircle2 className="h-4 w-4" /> Administration
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem
              className="text-destructive focus:text-destructive"
              onClick={() => logout()}
            >
              <LogOut className="h-4 w-4" /> Se déconnecter
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
