import {
  BrainCircuit,
  FileText,
  Headset,
  LayoutDashboard,
  Settings2,
  UploadCloud,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  description: string;
}

export const navItems: NavItem[] = [
  {
    label: "Tableau de bord",
    href: "/",
    icon: LayoutDashboard,
    description: "Vue direction",
  },
  {
    label: "Import de données",
    href: "/upload",
    icon: UploadCloud,
    description: "LSS · Entretiens · Transcriptions",
  },
  {
    label: "Entretiens",
    href: "/interviews",
    icon: BrainCircuit,
    description: "Analyse qualité IA",
  },
  {
    label: "Enquêteurs CATI",
    href: "/interviewers",
    icon: Headset,
    description: "Postes détectés automatiquement",
  },
  {
    label: "Rapports",
    href: "/reports",
    icon: FileText,
    description: "Exports PDF & Excel",
  },
  {
    label: "Administration",
    href: "/admin",
    icon: Settings2,
    description: "Utilisateurs & IA",
  },
];
