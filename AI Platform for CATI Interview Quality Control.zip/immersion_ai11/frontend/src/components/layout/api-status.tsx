"use client";

import { useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import { ServerCrash } from "lucide-react";
import { API_URL } from "@/lib/api";

/** Vérifie périodiquement que le backend FastAPI répond. */
export function ApiStatusBanner() {
  const { isError } = useQuery({
    queryKey: ["health"],
    queryFn: async () => {
      const res = await fetch(`${API_URL}/api/health`);
      if (!res.ok) throw new Error("down");
      return res.json();
    },
    refetchInterval: 15_000,
    retry: false,
  });

  return (
    <AnimatePresence>
      {isError && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className="overflow-hidden border-b border-destructive/30 bg-destructive/10"
        >
          <div className="mx-auto flex max-w-[1500px] items-center gap-3 px-4 py-2.5 md:px-6">
            <ServerCrash className="h-5 w-5 shrink-0 text-destructive" />
            <p className="text-sm text-destructive">
              <strong>Backend injoignable.</strong> L'API FastAPI ne répond pas
              {API_URL ? (
                <>
                  {" "}à{" "}
                  <code className="rounded bg-destructive/10 px-1.5 py-0.5">{API_URL}</code>
                </>
              ) : null}
              . Démarrez-la :{" "}
              <code className="rounded bg-destructive/10 px-1.5 py-0.5">
                uvicorn app.main:app --port 8000
              </code>
              .
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
