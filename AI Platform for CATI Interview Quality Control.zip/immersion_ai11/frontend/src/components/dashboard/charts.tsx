"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { CATEGORY_LABELS } from "@/lib/types";

const axis = "hsl(var(--muted-foreground))";

const tooltipStyle = {
  background: "hsl(var(--popover))",
  border: "1px solid hsl(var(--border))",
  borderRadius: "0.75rem",
  fontSize: "12px",
  boxShadow: "0 8px 30px -8px rgba(0,0,0,0.3)",
  color: "hsl(var(--popover-foreground))",
};

/** Histogramme des scores qualité (tranches de 10 points). */
export function ScoreHistogramChart({
  data,
}: {
  data: { bucket: string; count: number }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} margin={{ top: 10, right: 8, left: -18, bottom: 0 }}>
        <XAxis dataKey="bucket" stroke={axis} fontSize={10} tickLine={false} axisLine={false} />
        <YAxis stroke={axis} fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
        <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "hsl(var(--muted))" }} />
        <Bar dataKey="count" name="Entretiens" radius={[6, 6, 0, 0]}>
          {data.map((d, i) => {
            const low = parseInt(d.bucket, 10);
            const color =
              low >= 80 ? "hsl(152 62% 45%)" : low >= 60 ? "hsl(38 92% 50%)" : "hsl(0 80% 60%)";
            return <Cell key={i} fill={color} />;
          })}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

/** Distribution des anomalies par catégorie (barres horizontales). */
export function ErrorDistributionChart({
  data,
}: {
  data: { category: string; count: number }[];
}) {
  const rows = data.slice(0, 10).map((d) => ({
    ...d,
    label: CATEGORY_LABELS[d.category] ?? d.category,
  }));
  return (
    <ResponsiveContainer width="100%" height={Math.max(220, rows.length * 34)}>
      <BarChart data={rows} layout="vertical" margin={{ top: 0, right: 16, left: 8, bottom: 0 }}>
        <XAxis type="number" stroke={axis} fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
        <YAxis
          type="category"
          dataKey="label"
          stroke={axis}
          fontSize={11}
          width={190}
          tickLine={false}
          axisLine={false}
        />
        <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "hsl(var(--muted))" }} />
        <Bar dataKey="count" name="Anomalies" fill="hsl(245 75% 60%)" radius={[0, 6, 6, 0]} barSize={16} />
      </BarChart>
    </ResponsiveContainer>
  );
}

/** Questions les plus problématiques. */
export function ProblemQuestionsChart({
  data,
}: {
  data: { question_code: string; count: number }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={Math.max(220, data.length * 30)}>
      <BarChart data={data} layout="vertical" margin={{ top: 0, right: 16, left: 8, bottom: 0 }}>
        <XAxis type="number" stroke={axis} fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
        <YAxis
          type="category"
          dataKey="question_code"
          stroke={axis}
          fontSize={11}
          width={160}
          tickLine={false}
          axisLine={false}
        />
        <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "hsl(var(--muted))" }} />
        <Bar dataKey="count" name="Anomalies" fill="hsl(0 80% 60%)" radius={[0, 6, 6, 0]} barSize={14} />
      </BarChart>
    </ResponsiveContainer>
  );
}

/** Tendance du score d'un enquêteur dans le temps. */
export function TrendChart({
  data,
}: {
  data: { date: string; score: number; interviews: number }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={240}>
      <AreaChart data={data} margin={{ top: 10, right: 8, left: -18, bottom: 0 }}>
        <defs>
          <linearGradient id="gTrend" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="hsl(245 75% 60%)" stopOpacity={0.45} />
            <stop offset="100%" stopColor="hsl(245 75% 60%)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <XAxis dataKey="date" stroke={axis} fontSize={10} tickLine={false} axisLine={false} />
        <YAxis stroke={axis} fontSize={11} tickLine={false} axisLine={false} domain={[0, 100]} />
        <Tooltip contentStyle={tooltipStyle} />
        <Area
          type="monotone"
          dataKey="score"
          name="Score qualité"
          stroke="hsl(245 75% 60%)"
          strokeWidth={2.5}
          fill="url(#gTrend)"
          connectNulls
          dot={false}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
