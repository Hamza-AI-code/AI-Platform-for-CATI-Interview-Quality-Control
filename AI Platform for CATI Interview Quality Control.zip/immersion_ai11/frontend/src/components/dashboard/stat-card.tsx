"use client";

import { motion } from "framer-motion";
import { ArrowDownRight, ArrowUpRight, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export interface StatCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  delta?: number;
  deltaSuffix?: string;
  hint?: string;
  accent?: "primary" | "success" | "warning" | "destructive" | "sky";
  invertDelta?: boolean;
  index?: number;
}

const accentMap = {
  primary: "from-indigo-500/15 to-violet-500/5 text-primary",
  success: "from-emerald-500/15 to-teal-500/5 text-success",
  warning: "from-amber-500/15 to-orange-500/5 text-warning",
  destructive: "from-rose-500/15 to-red-500/5 text-destructive",
  sky: "from-sky-500/15 to-blue-500/5 text-sky-500",
};

export function StatCard({
  label,
  value,
  icon: Icon,
  delta,
  deltaSuffix = "%",
  hint,
  accent = "primary",
  invertDelta = false,
  index = 0,
}: StatCardProps) {
  const hasDelta = typeof delta === "number" && Number.isFinite(delta);
  const positive = (delta ?? 0) >= 0;
  const good = invertDelta ? !positive : positive;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.07 }}
      className="group relative overflow-hidden rounded-2xl border border-border/60 bg-card p-5 shadow-card transition-shadow hover:shadow-glow"
    >
      <div
        className={cn(
          "absolute -right-6 -top-6 h-28 w-28 rounded-full bg-gradient-to-br blur-2xl transition-opacity group-hover:opacity-100 opacity-70",
          accentMap[accent],
        )}
      />
      <div className="relative flex items-start justify-between">
        <div
          className={cn(
            "flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br",
            accentMap[accent],
          )}
        >
          <Icon className="h-[22px] w-[22px]" />
        </div>
        {hasDelta && (
          <span
            className={cn(
              "flex items-center gap-1 rounded-full px-2 py-1 text-xs font-semibold",
              good ? "bg-success/12 text-success" : "bg-destructive/12 text-destructive",
            )}
          >
            {positive ? (
              <ArrowUpRight className="h-3.5 w-3.5" />
            ) : (
              <ArrowDownRight className="h-3.5 w-3.5" />
            )}
            {Math.abs(delta!)}
            {deltaSuffix}
          </span>
        )}
      </div>
      <div className="relative mt-4">
        <p className="text-3xl font-bold tracking-tight tabular-nums">{value}</p>
        <p className="mt-1 text-sm font-medium text-muted-foreground">{label}</p>
        {hint && <p className="mt-0.5 text-xs text-muted-foreground/70">{hint}</p>}
      </div>
    </motion.div>
  );
}
