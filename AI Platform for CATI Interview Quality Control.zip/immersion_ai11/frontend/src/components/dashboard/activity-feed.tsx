"use client";

import { motion } from "framer-motion";
import {
  AlertTriangle,
  BrainCircuit,
  FileText,
  Upload,
  type LucideIcon,
} from "lucide-react";
import { relativeTime } from "@/lib/format";
import type { Activity } from "@/lib/types";
import { cn } from "@/lib/utils";

const iconMap: Record<string, LucideIcon> = {
  evaluation: BrainCircuit,
  import: Upload,
  upload: Upload,

  report: FileText,
  alert: AlertTriangle,
  questionnaire: FileText,
};

const severityStyle: Record<string, string> = {
  low: "bg-sky-500/12 text-sky-500",
  medium: "bg-warning/15 text-warning",
  high: "bg-orange-500/15 text-orange-500",
  critical: "bg-destructive/12 text-destructive",
};

export function ActivityFeed({ activities }: { activities: Activity[] }) {
  if (!activities.length) {
    return (
      <p className="py-10 text-center text-sm text-muted-foreground">
        Aucune activité récente
      </p>
    );
  }
  return (
    <div className="relative space-y-1">
      {activities.map((a, i) => {
        const Icon = iconMap[a.type] ?? BrainCircuit;
        return (
          <motion.div
            key={a.id}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="flex items-start gap-3 rounded-xl px-2 py-2.5 transition-colors hover:bg-muted/40"
          >
            <span
              className={cn(
                "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg",
                severityStyle[a.severity] ?? severityStyle.low,
              )}
            >
              <Icon className="h-[18px] w-[18px]" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm leading-snug text-foreground/90">{a.message}</p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                {relativeTime(a.created_at)}
              </p>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
