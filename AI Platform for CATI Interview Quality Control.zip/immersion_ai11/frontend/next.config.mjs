/** @type {import('next').NextConfig} */

// Cible du backend FastAPI (côté serveur Next.js, JAMAIS exposée au navigateur).
// Par défaut http://localhost:8000. Surcharger avec API_PROXY_TARGET au besoin.
const API_PROXY_TARGET = (process.env.API_PROXY_TARGET || "http://localhost:8000").replace(/\/$/, "");

const nextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "**" },
      { protocol: "http", hostname: "**" },
    ],
  },
  async rewrites() {
    // Le navigateur appelle /api/* (même origine) → Next proxyfie vers le backend.
    // Élimine CORS, mixed-content et les erreurs de configuration d'URL.
    return [
      { source: "/api/:path*", destination: `${API_PROXY_TARGET}/api/:path*` },
    ];
  },
};

export default nextConfig;
